#ifndef OFC_ROLE_H
#define OFC_ROLE_H

#include "ofchannel_utils.h"

#define OFC_ACCEPT_SLAVE_MSG 1
#define OFC_REJECT_SLAVE_MSG 0

int addToTbl(CONTROLLER_TUPLE *client, void **slvTbl) ;
int addToSalveList(CONTROLLER_TUPLE *client) ;
int addToMasterList(CONTROLLER_TUPLE *client);
int addToEqualList(CONTROLLER_TUPLE *client);

/* Check if this packet could be forwarded to the switch */
int isAllowedToSlave(char * buff);

int checkTbl(CONTROLLER_TUPLE *client, void **slvTbl) ;
int ofc_is_client_allowed(CONTROLLER_TUPLE *client,char *buff);

int delFromTbl(CONTROLLER_TUPLE *client, void **slvTbl);
int delFromsalveTbl(CONTROLLER_TUPLE *client);

int delFromEqualTbl(CONTROLLER_TUPLE *client);
int delFromMasterTbl(CONTROLLER_TUPLE *client);
void moveCtrls(void **arr1, void **arr2);
void makeMeSlave(CONTROLLER_TUPLE *client);

void makeMeMaster(CONTROLLER_TUPLE *client);

void makeMeEqual(CONTROLLER_TUPLE *client);
void setControllerTables(int i);

ofl_err ofc_process_role_request(CONTROLLER_TUPLE *client,struct ofp_role_request *role, int len);

/* Async configurations */
bool ofc_msg_is_async(enum ofp_type type);
int ofc_async_set_default(CONTROLLER_TUPLE *controller);
ofl_err ofc_process_set_async_13(CONTROLLER_TUPLE *client, struct ofp13_async_config *config);
ofl_err ofc_process_set_async_14(CONTROLLER_TUPLE *client, struct ofp14_async_config *src_config, int len);
ofl_err ofc_process_get_async_13(CONTROLLER_TUPLE *client, struct ofp_header *oh);
ofl_err ofc_process_get_async_14(CONTROLLER_TUPLE *client, struct ofp_header *oh);

bool ofc_async_msg_validate(CONTROLLER_TUPLE *client, struct ofp_header* oh);
int ofc_send_role_status(CONTROLLER_TUPLE *client,uint8_t reason);
#endif /* OFC_ROLE_H */
