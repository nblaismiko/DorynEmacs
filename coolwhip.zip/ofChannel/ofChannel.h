#ifndef _OFCHANNEL_H_
#define _OFCHANNEL_H_

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <arpa/inet.h>

#include "novi_errno.h"
#include "errno.h"
#include <netinet/in.h>
#include <sys/times.h>

#include <err.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

#include "c_config.h"
#include "cliCommon.h"
#include "ofchannel_utils.h"

int noviengine_control_socket;

#define OFCHANNEL_CONFIG_BASE_DIR "/opt/"

#define NOVIENGINE_IP "127.0.0.1"

#define OFC_ACCEPT_SLAVE_MSG 1
#define OFC_REJECT_SLAVE_MSG 0
#define DEFAULT_ECHO_VALUE 15

struct pkt_lst {
char *pkt;
int pkt_len;
struct pkt_lst *next;
struct pkt_lst  *prev;
};
typedef  struct pkt_lst PKT_LST;

extern int noviengine_control_socket;
extern CONTROLLER_TUPLE controller_clients[MAX_CLIENTS];
extern int controller_clients_num;
extern PKT_LST *head;

int addTrans(struct ofp_header *header,CONTROLLER_TUPLE *client);

int ofc_close_all_controllers();
void remove_all_trans(CONTROLLER_TUPLE *client);
int process_add_ctrl(enum ofc_cmd_src src, struct ConfigController* config);
int process_rem_ctrl(enum ofc_cmd_src src, struct ConfigController *config);
int process_get_echo(char **outbuff,int *outbuff_len);
int process_set_echo(int echo_timer);

int storeOfChannelConfig(int ip, int port, int role);
int ofc_add_controller(unsigned int ip_addr,unsigned short port,short int role,char prio,char mode,char *,char *, int version,char *profile, int inband);
int ofc_delete_controller(unsigned int *ip_addr,unsigned short *port,short int role,char prio,char mode,char *,char *);

int set_get_echo_flag (int flag, time_t val);
int process_ofchannel_controller_status(int flag);
int process_command(enum ofc_cmd_src src, TLV *tlv,int len,char **outbuff,int *outbuff_len);
void manage_controller_connection(CONTROLLER_TUPLE *client);

int ofc_del_config(int type, void* structure, int size);
int ofc_save_config(int type, void* structure, int size);
void ofc_ofconfig_controller_update(CONTROLLER_TUPLE* client);

ofl_err ofc_verify_bundle_msg(struct ofl_msg_header *ofl_msg);
int getExistbundlenum(CONTROLLER_TUPLE *client);
#endif // _OFCHANNEL_H_

