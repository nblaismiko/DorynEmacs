#include "ofChannel.h"
#include "ofchannel_role.h"
#include "ofl-utils.h"

/* OF 1.4 async configurations format */
void* slaveTbl[MAX_CLIENTS]={NULL};
void* masterTbl[MAX_CLIENTS]={NULL};
void* equalTbl[MAX_CLIENTS]={NULL};

void init_controller_tables(int i)
{
    slaveTbl[i]=masterTbl[i]=equalTbl[i]=NULL;
}

int addToTbl(CONTROLLER_TUPLE *client,void **tbl)
{
    tbl[client->fd]=client;
    return 0;
}

int addToSalveList(CONTROLLER_TUPLE *client) 
{
    return addToTbl(client,slaveTbl);
}
int addToMasterList(CONTROLLER_TUPLE *client)
{
    return addToTbl(client,masterTbl);
}

int addToEqualList(CONTROLLER_TUPLE *client)
{
    return addToTbl(client,equalTbl);
}

/* Check if this packet could be forwarded to the switch */
int isAllowedToSlave(char * buff)
{
	struct ofp_header * hdr= (struct ofp_header*) buff;
	int type = hdr->type;
	unsigned short multi_part_type=0;
	int ret=OFC_REJECT_SLAVE_MSG;
	switch(type)
	{
		/* Allowed Messages from Slave Controller */
		case OFPT_SET_ASYNC:
		case OFPT_FEATURES_REQUEST:
		case OFPT_HELLO:
		case OFPT_GET_CONFIG_REQUEST:
		case OFPT_ECHO_REQUEST:
		case OFPT_QUEUE_GET_CONFIG_REQUEST:
		//case OFPT_ROLE_REPLY:
		case OFPT_ROLE_REQUEST: // No need to forward role request to noviengine
		case OFPT_GET_ASYNC_REQUEST:
		case OFPT_BARRIER_REQUEST:
			//printf("Allowed Packet type=%d\n",type);
			ret =OFC_ACCEPT_SLAVE_MSG;
			break;

		/* Messages are not allowed for Slave Controller*/
		case OFPT_PACKET_OUT:
		case OFPT_FLOW_MOD:
		case OFPT_GROUP_MOD:
		case OFPT_TABLE_MOD:
		case OFPT_PORT_MOD:
			//printf("Rejected Packet type=%d\n",type);
			ret= OFC_REJECT_SLAVE_MSG;
			break;

		/* Allowed only if there is no payload */
		case OFPT_MULTIPART_REQUEST:
			
			memcpy(&multi_part_type,buff+sizeof(struct ofp_header),sizeof(short));
			if(ntohs(multi_part_type) == OFPMP_TABLE_FEATURES && ntohs(hdr->length) > 16)
				ret = OFC_REJECT_SLAVE_MSG;
			else
				ret = OFC_ACCEPT_SLAVE_MSG;
			break;

		default:
			break;
	}
	return ret;
}

int checkTbl(CONTROLLER_TUPLE *client,void **slvTbl)
{
    if(slvTbl[client->fd] == client)
		return 0;
	else
		return -1;
}

int ofc_is_client_allowed(CONTROLLER_TUPLE *client,char *buff)
{
	/* if client is not slave, accept */
	if(checkTbl(client,slaveTbl) != 0)
		return OFC_ACCEPT_SLAVE_MSG;

	return isAllowedToSlave(buff);
}

int delFromTbl(CONTROLLER_TUPLE *client,void **slvTbl)
{
    if(slvTbl[client->fd]== client)
	{
        slvTbl[client->fd]=NULL;
		return 0;
	}
	return -1;
}

int delFromsalveTbl(CONTROLLER_TUPLE *client)
{
	return delFromTbl(client,slaveTbl);
}

int delFromEqualTbl(CONTROLLER_TUPLE *client)
{
	return delFromTbl(client,equalTbl);
}

int delFromMasterTbl(CONTROLLER_TUPLE *client)
{
	return delFromTbl(client,masterTbl);
}

void moveCtrls(void **arr1,void **arr2)
{
	int i =0;
	for(i=0;i<MAX_CLIENTS;i++)
	{
        if(arr1[i] != NULL)
        {
            arr2[i]=arr1[i];
            arr1[i]=NULL;
            updateRole(arr2[i],OFPCR_ROLE_SLAVE);
            ofc_send_role_status(arr2[i],OFPCRR_MASTER_REQUEST);
        }
	}
}

void makeMeSlave(CONTROLLER_TUPLE *cli)
{
	CONTROLLER_TUPLE *client = NULL,*h=NULL;
	int index=0;
	if(cli->is_aux)
	{
		client=cli->head;
		client=client->current;
	}
	else
		client=cli;

	h=client;

	do
	{
		addToSalveList(client);
		delFromEqualTbl(client);
		delFromMasterTbl(client);
		updateRole(client, OFPCR_ROLE_SLAVE);
		getNextAux(h,&index,&client);
		if(client  == NULL) break;

	}while(1);
}

void makeMeMaster(CONTROLLER_TUPLE *cli)
{

	CONTROLLER_TUPLE *client = NULL,*h=NULL;
	int index=0;
	if(cli->is_aux)
	{
		client=cli->head;
		client=client->current;
	}
	else
		client=cli;

	h=client;

	moveCtrls(masterTbl,slaveTbl);
	do
	{
		addToMasterList(client);
		delFromEqualTbl(client);
		delFromsalveTbl(client);
		updateRole(client, OFPCR_ROLE_MASTER);
		getNextAux(h,&index,&client);
		if(client  == NULL) break;

	}while(1);
	 sendControllerStatus(cli,OFPCT_STATUS_UP,OFPCSR_ROLE);
}

void makeMeEqual(CONTROLLER_TUPLE *cli)
{
	CONTROLLER_TUPLE *client = NULL,*h=NULL;
	int index=0;
	if(cli->is_aux)
	{
		client=cli->head;
		client=client->current;
	}
	else
		client=cli;

	h=client;

	do
	{
		addToEqualList(client);
		delFromsalveTbl(client);
		delFromMasterTbl(client);
		updateRole(client, OFPCR_ROLE_EQUAL);
		getNextAux(h,&index,&client);
		if(client  == NULL) break;

	}while(1);
	 sendControllerStatus(cli,OFPCT_STATUS_UP,OFPCSR_ROLE);
	
}

/* Master Election Generation Id */
uint64_t generation_id_last=0;
uint64_t generation_is_defined=0;
ofl_err ofc_process_role_request(CONTROLLER_TUPLE *client,struct ofp_role_request *role, int len)
{
#define DEFINE_GEN_ID 1
	ofl_err error = 0;
	uint32_t role_swapped = ntohl(role->role);
	uint64_t gen_id_swapped = ntoh64(role->generation_id);
	int64_t distance=0;
	CONTROLLER_TUPLE* head = (CONTROLLER_TUPLE*)client->head;

	distance = gen_id_swapped-generation_id_last;

	switch(role_swapped)
	{
		case OFPCR_ROLE_SLAVE:
			if((distance < 0 ) && (generation_is_defined==DEFINE_GEN_ID))
			{
				error = ofl_error(OFPET_ROLE_REQUEST_FAILED, OFPRRFC_STALE);
				break;
			}
			else
			{
				// update role status only when request role is different from controller'role
				if(role_swapped != head->role)
					makeMeSlave(client);
				role->role=htonl(OFPCR_ROLE_SLAVE);
				generation_is_defined=DEFINE_GEN_ID;
				generation_id_last=gen_id_swapped;
				break;
			}
		case OFPCR_ROLE_MASTER:
			if((distance < 0) && (generation_is_defined==DEFINE_GEN_ID))
			{
				error = ofl_error(OFPET_ROLE_REQUEST_FAILED, OFPRRFC_STALE);
				break;
			}
			else
			{
				role->role = htonl(OFPCR_ROLE_MASTER);
				generation_is_defined=DEFINE_GEN_ID;
				generation_id_last=gen_id_swapped;
				// update role status only when request role is different from controller'role
				if(role_swapped != head->role)
					makeMeMaster(client);
				break;
			}
		case OFPCR_ROLE_EQUAL:
			// update role status only when request role is different from controller'role
			if(role_swapped != head->role)
				makeMeEqual(client);
			role->role = htonl(OFPCR_ROLE_EQUAL);
			role->generation_id=hton64(generation_id_last);
			break;
		case OFPCR_ROLE_NOCHANGE:
		{
			role->role=htonl(head->role);
			role->generation_id=hton64(generation_id_last);
			break;
		}
		default:
			error = ofl_error(OFPET_ROLE_REQUEST_FAILED, OFPRRFC_BAD_ROLE);
			break;
	}

	if(error) return error;
	role->header.type=OFPT_ROLE_REPLY;
	ofc_write(client, role, len);
	return 0;
}

ofl_err ofc_process_set_async_13(CONTROLLER_TUPLE *client, struct ofp13_async_config *src_config)
{
#define PACKET_IN_REASON_MASK 0x00000007
#define FLOW_REMOVED_MASK 0x0000000F 
#define PORT_STATUS_MASK 0x00000007

	if (src_config->header.version != OFP13_VERSION)
		return 0;

	int i = 0;
	ofl_err error = 0;
	CONTROLLER_TUPLE *head = client->head;
 	
	/* validate the entered mask */
	for (i = 0;i < 2; i++)
	{
		if ((ntohl(src_config->packet_in_mask[i]) & (~PACKET_IN_REASON_MASK)) != 0)
		{
			error = ofl_error(OFPET_SWITCH_CONFIG_FAILED, OFPSCFC_BAD_FLAGS);
			goto Err;
 		}

		if ((ntohl(src_config->flow_removed_mask[i]) & (~FLOW_REMOVED_MASK)) != 0)
		{
			error = ofl_error(OFPET_SWITCH_CONFIG_FAILED, OFPSCFC_BAD_FLAGS); 
			goto Err;
		}		

		if ((ntohl(src_config->port_status_mask[i]) & (~PORT_STATUS_MASK)) != 0)
		{
			error = ofl_error(OFPET_SWITCH_CONFIG_FAILED, OFPSCFC_BAD_FLAGS);
			goto Err;
		}	
	}

	memset(&head->async_config, 0x00, sizeof(head->async_config));
	/* ofp_async_config to ofl_async_config conversion */
	for (i = 0;i < 2; i++)
	{
		head->async_config.packet_in_mask[i] = ntohl(src_config->packet_in_mask[i]);
		head->async_config.flow_removed_mask[i] = ntohl(src_config->flow_removed_mask[i]);
		head->async_config.port_status_mask[i] = ntohl(src_config->port_status_mask[i]); 
	}

Err:
	return error;
}

ofl_err ofc_process_set_async_14(CONTROLLER_TUPLE *client, struct ofp14_async_config *src_config, int len)
{
	struct ofl_msg_async_config* conf = NULL;
	ofl_err error = 0;
	error = ofl_msg_unpack((uint8_t*) src_config, len, (struct ofl_msg_header **) &conf, NULL, NULL);
	if (error) return error;

	CONTROLLER_TUPLE* client_head = client->head;
	bool prop_exists = false;

	if (client_head->async_props)
	{
		int i = 0, j = 0;
		for (i = 0; i<conf->properties_count; i++)
		{
			prop_exists = false;
			for (j = 0; j<client_head->async_prop_count; j++)
			{
				if (client_head->async_props[j]->type == conf->properties[i]->type)
				{
					free(client_head->async_props[j]);
					client_head->async_props[j] = conf->properties[i];
					prop_exists = true;
					break;
				}
			}
			if (!prop_exists)
			{
				client_head->async_prop_count++;
				client_head->async_props = realloc(client_head->async_props, client_head->async_prop_count * sizeof(struct ofl_async_config_prop_header*));
				client_head->async_props[client_head->async_prop_count-1] = conf->properties[i];
			}
		}
	}
	else
	{
		client_head->async_prop_count = conf->properties_count;
		client_head->async_props = conf->properties;
	}

	/* free msg, but release the properties first */
	free(conf->properties);
	conf->properties = NULL;
	conf->properties_count = 0;
	ofl_msg_free((struct ofl_msg_header*) conf, NULL);
	return 0;
}

ofl_err ofc_process_get_async_13(CONTROLLER_TUPLE *client, struct ofp_header *oh)
{
	struct ofp13_async_config async_config;
	CONTROLLER_TUPLE *head=(CONTROLLER_TUPLE *)client->head;
	memset(&async_config, 0x00, sizeof(async_config));

	async_config.packet_in_mask[0] = htonl(head->async_config.packet_in_mask[0]);
	async_config.packet_in_mask[1] = htonl(head->async_config.packet_in_mask[1]);
	async_config.port_status_mask[0] = htonl(head->async_config.port_status_mask[0]);
	async_config.port_status_mask[1] = htonl(head->async_config.port_status_mask[1]);
	async_config.flow_removed_mask[0] = htonl(head->async_config.flow_removed_mask[0]);
	async_config.flow_removed_mask[1] = htonl(head->async_config.flow_removed_mask[1]);
	async_config.header.length=htons(sizeof(struct ofp13_async_config));
	async_config.header.version=OFP13_VERSION;
	async_config.header.type = OFPT_GET_ASYNC_REPLY;
	async_config.header.xid = oh->xid;
	ofc_write(client, &async_config, sizeof(struct ofp13_async_config));
	return 0;
}
ofl_err ofc_process_get_async_14(CONTROLLER_TUPLE *client, struct ofp_header *oh)
{
	struct ofl_msg_async_config conf;
	conf.header.type = OFPT_GET_ASYNC_REPLY;
	conf.header.version = OFP14_VERSION;

	conf.properties_count = ((CONTROLLER_TUPLE*)client->head)->async_prop_count;
	conf.properties = ((CONTROLLER_TUPLE*)client->head)->async_props;

	uint8_t *reply = NULL;
	size_t reply_len = 0;
	int ret = ofl_msg_pack((struct ofl_msg_header *) &conf, ntohl(oh->xid), &reply, &reply_len, NULL);
	if (ret != 0) return 0;
	ofc_write(client, reply, reply_len);
	free(reply);
	return 0;
}

ofl_err ofc_process_get_async_15(CONTROLLER_TUPLE *client, struct ofp_header *oh)
{
	struct ofl_msg_async_config conf;
	conf.header.type = OFPT_GET_ASYNC_REPLY;
	conf.header.version = OFP15_VERSION;

	conf.properties_count = ((CONTROLLER_TUPLE*)client->head)->async_prop_count;
	conf.properties = ((CONTROLLER_TUPLE*)client->head)->async_props;

	uint8_t *reply = NULL;
	size_t reply_len = 0;
	int ret = ofl_msg_pack((struct ofl_msg_header *) &conf, ntohl(oh->xid), &reply, &reply_len, NULL);
	if (ret != 0) return 0;
	ofc_write(client, reply, reply_len);
	free(reply);
	return 0;
}
bool ofc_msg_is_async(enum ofp_type type)
{
	switch(type)
	{
		case OFPT_PACKET_IN :
		case OFPT_FLOW_REMOVED :
		case OFPT_PORT_STATUS :
		case OFPT_ROLE_STATUS :
		case OFPT_REQUESTFORWARD :
		case OFPT_TABLE_STATUS:
			return true;
		default:
			return false;
	}
}

/* returns false if message is not allowed and should be dropped */
static int ofc_async_msg_validate_13(CONTROLLER_TUPLE *client, struct ofp_header* oh)
{
#define MASTER_ASYNC_CONFIG 0
#define EQUAL_ASYNC_CONFIG 0
#define SLAVE_ASYNC_CONFIG 1
	int state = 0;
	struct ofl_async_config *async_config = NULL;
	uint32_t bitmask = 0;
	uint8_t reason = 0;

	async_config = &client->async_config;

	if (client->role == OFPCR_ROLE_EQUAL)
		state = EQUAL_ASYNC_CONFIG;
	else if (client->role == OFPCR_ROLE_MASTER)
		state = MASTER_ASYNC_CONFIG;
	else if (client->role == OFPCR_ROLE_SLAVE)
		state = SLAVE_ASYNC_CONFIG;


	if (oh->type == OFPT_PACKET_IN)
	{
		struct ofp_packet_in* packet_in = (struct ofp_packet_in*) oh;
		bitmask = async_config->packet_in_mask[state];
		reason = packet_in->reason;
	}
	else if(oh->type == OFPT_PORT_STATUS)
	{
		struct ofp_port_status* port_status = (struct ofp_port_status*) oh;
		bitmask = async_config->port_status_mask[state];
		reason = port_status->reason;
	}
	else if(oh->type == OFPT_FLOW_REMOVED)
	{
		struct ofp_flow_removed* flow_removed = (struct ofp_flow_removed*) oh;
		bitmask = async_config->flow_removed_mask[state];
		reason = flow_removed->reason;
	}
	else {
		return true;
	}

	if ( (bitmask & (1<<reason)) == 0)
		return false;
	else
		return true;
}
static bool ofc_async_msg_validate_14(CONTROLLER_TUPLE *client, struct ofp_header* oh)
{
	if (client->async_prop_count == 0 || client->async_props == NULL)
		return true;

	uint8_t reason = 0;
	int prop_type = 0;
	switch(oh->type)
	{
		case OFPT_PACKET_IN:
		{
			struct ofp_packet_in* packet_in = (struct ofp_packet_in*) oh;
			prop_type = OFPACPT_PACKET_IN_SLAVE;
			reason = packet_in->reason;
			break;
		}
		case OFPT_PORT_STATUS:
		{
			struct ofp_port_status* port_status = (struct ofp_port_status*) oh;
			prop_type = OFPACPT_PORT_STATUS_SLAVE;
			reason = port_status->reason;
			break;
		}
		case OFPT_FLOW_REMOVED:
		{
			struct ofp_flow_removed* flow_removed = (struct ofp_flow_removed*) oh;
			prop_type = OFPACPT_FLOW_REMOVED_SLAVE;
			reason = flow_removed->reason;
			break;
		}
		case OFPT_TABLE_STATUS:
		{
			struct ofp_table_status* table_status = (struct ofp_table_status*)oh;
			prop_type = OFPACPT_TABLE_STATUS_SLAVE;
			reason = table_status->reason;
			break;
		}
		case OFPT_ROLE_STATUS:
		{
			struct ofp_role_status* role_status = (struct ofp_role_status*)oh;
			prop_type = OFPACPT_ROLE_STATUS_SLAVE;
			reason = role_status->reason;
			break;
		}  		
		case OFPT_REQUESTFORWARD:
 		{
 			struct ofp_requestforward_header* requestforward = (struct ofp_requestforward_header*)oh;
 			prop_type = OFPACPT_REQUESTFORWARD_SLAVE;
 			if(requestforward->request.type == OFPT_GROUP_MOD)
 			{
 				reason = OFPRFR_GROUP_MOD;
 			}
 			if(requestforward->request.type == OFPT_METER_MOD)
 			{
 				reason = OFPRFR_METER_MOD;
 			}
 		        	break;
 		}
		default:
			return false;
	}
	if (client->role == OFPCR_ROLE_EQUAL || client->role == OFPCR_ROLE_MASTER)
		prop_type += 1;

	int i = 0;
	for (i = 0; i<client->async_prop_count; i++)
	{
		if (client->async_props[i]->type == prop_type)
		{
			struct ofl_async_config_prop_reasons *prop_reason = 
				(struct ofl_async_config_prop_reasons *) client->async_props[i];
			if ( (prop_reason->mask & (1<<reason)) == 0)
				return false;
			else
				return true;
		}
	}
	return false;
}

static bool ofc_async_msg_validate_15(CONTROLLER_TUPLE *client, struct ofp_header* oh)
{
	if (client->async_prop_count == 0 || client->async_props == NULL)
		return true;

	uint8_t reason = 0;
	int prop_type = 0;
	switch(oh->type)
	{
		case OFPT_PACKET_IN:
		{
			struct ofp_packet_in* packet_in = (struct ofp_packet_in*) oh;
			prop_type = OFPACPT_PACKET_IN_SLAVE;
			reason = packet_in->reason;
			break;
		}
		case OFPT_PORT_STATUS:
		{
			struct ofp_port_status* port_status = (struct ofp_port_status*) oh;
			prop_type = OFPACPT_PORT_STATUS_SLAVE;
			reason = port_status->reason;
			break;
		}
		case OFPT_FLOW_REMOVED:
		{
			struct ofp_flow_removed* flow_removed = (struct ofp_flow_removed*) oh;
			prop_type = OFPACPT_FLOW_REMOVED_SLAVE;
			reason = flow_removed->reason;
			break;
		}
		case OFPT_TABLE_STATUS:
		{
			struct ofp_table_status* table_status = (struct ofp_table_status*)oh;
			prop_type = OFPACPT_TABLE_STATUS_SLAVE;
			reason = table_status->reason;
			break;
		}
		case OFPT_ROLE_STATUS:
		{
			struct ofp_role_status* role_status = (struct ofp_role_status*)oh;
			prop_type = OFPACPT_ROLE_STATUS_SLAVE;
			reason = role_status->reason;
			break;
		}
		case OFPT_REQUESTFORWARD:
 		{
 			struct ofp_requestforward_header* requestforward = (struct ofp_requestforward_header*)oh;
 			prop_type = OFPACPT_REQUESTFORWARD_SLAVE;
 			if(requestforward->request.type == OFPT_GROUP_MOD)
 			{
 				reason = OFPRFR_GROUP_MOD;
 			}
 			if(requestforward->request.type == OFPT_METER_MOD)
 			{
 				reason = OFPRFR_METER_MOD;
 			}
 		        	break;
 		}
		default:
			return false;
	}
	if (client->role == OFPCR_ROLE_EQUAL || client->role == OFPCR_ROLE_MASTER)
		prop_type += 1;

	int i = 0;
	for (i = 0; i<client->async_prop_count; i++)
	{
		if (client->async_props[i]->type == prop_type)
		{
			struct ofl_async_config_prop_reasons *prop_reason =
				(struct ofl_async_config_prop_reasons *) client->async_props[i];
			if ( (prop_reason->mask & (1<<reason)) == 0)
				return false;
			else
				return true;
		}
	}
	return false;
}



bool ofc_async_msg_validate(CONTROLLER_TUPLE *client, struct ofp_header* oh)
{
	if (oh->version == OFP13_VERSION)
		return ofc_async_msg_validate_13(client, oh);
	else if (oh->version == OFP14_VERSION)
		return ofc_async_msg_validate_14(client, oh);
	else if (oh->version == OFP15_VERSION)
		return ofc_async_msg_validate_15(client, oh);
	else
		return false;
}
int ofc_async_set_default(CONTROLLER_TUPLE *controller)
{
	struct ofl_async_config *config=NULL;

	config=&controller->async_config;
	memset(config, 0x00, sizeof(struct ofl_async_config));

	/* default master/equal configuration */
	config->packet_in_mask[0] = (1<<OFPR_TABLE_MISS) | 
		(1<<OFPR_APPLY_ACTION) |
//		(1<<OFPR_INVALID_TTL) |
		(1<<OFPR_ACTION_SET) |
		(1<<OFPR_GROUP) |
		(1<<OFPR_PACKET_OUT);
	config->port_status_mask[0] = 	(1<<OFPPR_ADD) | 
		(1<<OFPPR_DELETE)| 
		(1<<OFPPR_MODIFY);
	config->flow_removed_mask[0] = 	(1<<OFPRR_IDLE_TIMEOUT) | 
		(1<<OFPRR_HARD_TIMEOUT)| 
		(1<<OFPRR_DELETE)| 
		(1<<OFPRR_GROUP_DELETE)| 
		(1<<OFPRR_METER_DELETE);

	/* default slave configuration */
	config->packet_in_mask[1] = 0;
	config->port_status_mask[1] = 	(1<<OFPPR_ADD) | 
		(1<<OFPPR_DELETE)| 
		(1<<OFPPR_MODIFY);
	config->flow_removed_mask[1] = 0;

	controller->async_prop_count = OFPACPT_REQUESTFORWARD_MASTER+1; 
	controller->async_props = malloc(sizeof(struct ofl_async_config_prop_header *) * controller->async_prop_count);
	int i = 0;
	for (i = OFPACPT_PACKET_IN_SLAVE; i<=OFPACPT_REQUESTFORWARD_MASTER; i++)
	{
		struct ofl_async_config_prop_reasons* new_prop = malloc(sizeof(struct ofl_async_config_prop_reasons));
		memset(new_prop, 0x00, sizeof(struct ofl_async_config_prop_reasons));
		new_prop->header.type = i;
		controller->async_props[i] = (struct ofl_async_config_prop_header *) new_prop;
		switch(i)
		{
			case OFPACPT_PACKET_IN_SLAVE:
				// SLAVE:disable all OFPT_PACKET_IN
				new_prop->mask = 0;
				break;
			case OFPACPT_PACKET_IN_MASTER:
			    // MASTER: enable all OFPT_PACKET_IN messages, except those with reason OFPR_INVALID_TTL
				new_prop->mask = (1<<OFPR_TABLE_MISS) | (1<<OFPR_APPLY_ACTION) | (1<<OFPR_ACTION_SET) | (1<<OFPR_GROUP) | (1<<OFPR_PACKET_OUT);
				break;
			case OFPACPT_PORT_STATUS_SLAVE:
			case OFPACPT_PORT_STATUS_MASTER:
				new_prop->mask = (1<<OFPPR_ADD) | (1<<OFPPR_DELETE) | (1<<OFPPR_MODIFY);
				break;
			case OFPACPT_FLOW_REMOVED_SLAVE:
				// SLAVE:disable all OFPT_FLOW_REMOVED
				new_prop->mask = 0;
				break;				
			case OFPACPT_FLOW_REMOVED_MASTER :
				// MASTER:enable all OFPT_FLOW_REMOVED
				new_prop->mask = (1<<OFPRR_IDLE_TIMEOUT) | (1<<OFPRR_HARD_TIMEOUT) | (1<<OFPRR_DELETE) | (1<<OFPRR_GROUP_DELETE) | (1<<OFPRR_METER_DELETE) | (1<<OFPRR_EVICTION);
				break;
			case OFPACPT_ROLE_STATUS_SLAVE:
			case OFPACPT_ROLE_STATUS_MASTER:
				new_prop->mask = 0;
				break;
			case OFPACPT_TABLE_STATUS_SLAVE:
			case OFPACPT_TABLE_STATUS_MASTER :
				new_prop->mask = (1<<OFPTR_VACANCY_DOWN) | (1<<OFPTR_VACANCY_UP);
				break;
			case OFPACPT_REQUESTFORWARD_SLAVE:
			case OFPACPT_REQUESTFORWARD_MASTER:
				new_prop->mask = 0;
				break;
			default:
				continue;
		}
	}

	return 0;
}

int ofc_send_role_status(CONTROLLER_TUPLE *client,uint8_t reason)
{
	CONTROLLER_TUPLE *head = (CONTROLLER_TUPLE*)client->head;
	struct ofl_msg_role_status role_status = {{0}};
	int j = 0;
	if (head->async_prop_count == 0 || head->async_props == NULL)
        return 0;

	// validate if reason supported for async message ROLE_STATUS
	for (j = 0; j<head->async_prop_count; j++)
	{
		if ( OFPACPT_ROLE_STATUS_SLAVE == head->async_props[j]->type)
		{
			struct ofl_async_config_prop_reasons *prop_reason = 
				(struct ofl_async_config_prop_reasons *) head->async_props[j];
			if ( (prop_reason->mask & (1<<reason)) == 0)
				return 0;
			else
				break;
		}
	}
	role_status.header.version = client->ofp_version;
	role_status.header.type = OFPT_ROLE_STATUS;
	role_status.role = head->role;
	role_status.reason = reason;
	role_status.generation_id = generation_id_last;
	role_status.properties_num = 0;

	uint8_t *msg_send = NULL;
	size_t msg_len = 0;
	int ret = ofl_msg_pack((struct ofl_msg_header *) &role_status, 0, &msg_send, &msg_len, NULL);
	if (ret != 0) return 0;
	ofc_write(client, msg_send, msg_len);
	free(msg_send);
	return 0;
}


