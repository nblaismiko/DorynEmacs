
#ifndef NOVI_HW_ENTRY_H_
#define NOVI_HW_ENTRY_H_

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "novi_utils.h"

#define MIN_BITAMP_OUTPUTS_NUM  2
#define MAX_DSCP_PREC_LEVEL 7
#define DEFAULT_MIN_BAND_PER_METER 1


#define NOVI_MAX_METER_COLOR 2
#define NOVI_MAX_METER_ID 0xffff0000
#define NOVI_MIN_METER_ID 0x1
#define NOVI_DEFAULT_BANDS_PER_ENTRY 4
#define NOVI_MAX_TB_PROFILES 4096 // Max tocket bucket profiles available
#define NOVI_MAX_TB_PROFILES_PER_GROUP 1024
#define NOVI_MAX_METER_ENTRIES_PER_GROUP  (NOVI_MAX_TB_PROFILES_PER_GROUP/DEFAULT_MIN_BAND_PER_METER)
#define NOVI_METER_MAX_STATS_PER_GROUP ((DEFAULT_MIN_BAND_PER_METER+1)*NOVI_MAX_METER_ENTRIES_PER_GROUP)
#define NOVI_HW_METER_TABLE_ID 3

#define NP_METER_MAX_BAND 8
#define TB_COUNTERS_PER_MEM_INT         (NOVI_MAX_TB_PROFILES/NOVI_METER_GROUPS_COUNT)
#define DEFAULT_MAX_METER_ENTRIES	(NOVI_MAX_TB_PROFILES/NP_METER_MAX_BAND)
#define DEFAULT_MAX_METER_ENTRIES_PER_GROUP	(DEFAULT_MAX_METER_ENTRIES/NOVI_METER_GROUPS_COUNT)
#define NOVI_METER_MAX_STATS_COUNTERS_PER_METER	(NP_METER_MAX_BAND+1)

#define MAX_METER_ENTRY_BAND_DATA 24
#define NOVI_HW_MAX_BAND_PER_METER 15

#define MAX_DATAPLANE_PKT_SIZE				9216
#define MAX_HW_PACKET_HEADER_SIZE			200
#define MAX_PACKET_SIZE     				(MAX_DATAPLANE_PKT_SIZE + MAX_HW_PACKET_HEADER_SIZE)

#define NOVI_CONTROLLER_IN_PORT  			0xFD
#define NOVI_BARRIER_IN_PORT				0xFF
#define NOVI_PACKETOUT_STATS_OFF 0xFFFFFF

/*
 * Flow mod bytes (64 bytes)
 * 0-1   : Control bytes
 * 2-3  : Instr bitmap
 * 4-5  : Vlan vid
 * 6-31 : Instr data
 * 32   : Controler byte
 * 33-60: Instr data
 * 61-63: stats_offset address
 * Total instructions data 54
 */
#define MAX_INST_TOTAL_SIZE		54
#define MAX_ACTIONS_SIZE		57

struct novi_hw_match_field {
	uint8_t size;
	uint8_t hw_field_param; /*This represent the offset in case of wildcard match and the index in case of exact match*/
};

struct novi_hw_match {
	uint8_t size;
	uint8_t data[];
}PACK_STRUCT;

struct novi_hw_mask{
	uint8_t size;
	uint8_t data[];
}PACK_STRUCT;



//__________________________________________________________
//Experimenter hw actions

struct novi_hw_action_output_bmp {
#if defined(NSNP5)
	#define OUTPUTS_BITMAP_SIZE 6 /* In bytes */
#elif defined(NOVICORIANT)
	#define OUTPUTS_BITMAP_SIZE 4 /* In bytes */
#else
	#define OUTPUTS_BITMAP_SIZE 8 /* In bytes */
#endif
	// must be preceded by "struct novi_hw_action"
	uint8_t bitmap[OUTPUTS_BITMAP_SIZE];
	uint16_t max_len;
}PACK_STRUCT;

struct novi_hw_set_payload {
	uint8_t payload_size;
	uint16_t payload_offset;
	uint8_t data[];
}PACK_STRUCT;

struct novi_hw_push_tunnel {
	uint8_t flags;
	uint8_t tunnel_params[]; /* One of  novi_hw_push structures */
};

struct novi_hw_push_vxlan {
	uint8_t dst_mac[ETH_ALEN];
	uint8_t src_mac[ETH_ALEN];
	uint32_t ip_src;
	uint32_t ip_dst;
	uint16_t udp_src;
	uint32_t vni;
}PACK_STRUCT;

struct novi_hw_push_l2mpls {
	uint8_t dst_mac[ETH_ALEN];
	uint8_t src_mac[ETH_ALEN];
	uint32_t tunnel_label;
	uint32_t vc_label;
}PACK_STRUCT;

struct novi_hw_push_l2gre {
	uint8_t dst_mac[ETH_ALEN];
	uint8_t src_mac[ETH_ALEN];
	uint32_t ip_src;
	uint32_t ip_dst;
	uint32_t key;
}PACK_STRUCT;



//______________________________________________________________

struct novi_hw_action {
	uint8_t opcode;
	uint8_t data[];
}PACK_STRUCT;


struct novi_hw_action_set {
	uint8_t actions_num;
	uint8_t total_size ;
	uint8_t data[];
} PACK_STRUCT;

struct novi_hw_action_list {
	uint8_t actions_num;
	uint8_t total_size ;
	/* uin8_t number_of_outputs (first byte of data) */
	uint8_t data[];
} PACK_STRUCT;

/*
 * Metadata instruction is actually on 64 bits, but we crop the 32
 * most significant bits of the value because of the way our
 * TCAM matches on fields on the PPE side.
 */
struct novi_hw_write_metadata {
	uint32_t mask;
	uint32_t metadata;
}PACK_STRUCT;

struct novi_hw_goto {
	uint8_t hw_table_id;
    uint8_t next_match_bmp;
}PACK_STRUCT;

struct novi_hw_goto_group {
	uint8_t hw_table_id;
	uint16_t index;
}PACK_STRUCT;

struct novi_hw_goto_meter{
	uint8_t hw_table_id;
	uint16_t index;
}PACK_STRUCT;

struct novi_hw_inst{
	uint8_t size;
	uint8_t data[]; /* novi_hw_instruction_list */
}PACK_STRUCT;

struct novi_hw_instruction_list{
	uint16_t inst_bmp;
	uint16_t vlan_id; /* Used to start a lookup for VID if the entry sets a new value. */
	uint8_t data[];
}PACK_STRUCT;

struct novi_hw_set_output_inst {
	uint16_t hw_port_id;
	uint16_t max_len;
}PACK_STRUCT;

struct novi_hw_entry{
	struct novi_hw_match* hw_match;
	struct novi_hw_mask* hw_mask;
	struct novi_hw_inst* hw_inst;
};

struct novi_hw_set_bfd {
	uint32_t portno;
	uint32_t my_disc;
	int interval;
	uint8_t multiplier;
}PACK_STRUCT;

struct novi_hw_entry*
novi_hw_entry_new();


struct novi_hw_entry*
novi_hw_entry_clone(struct novi_hw_entry* hw_entry);

void
novi_hw_entry_delete(struct novi_hw_entry* hw_entry);

void
novi_hw_entry_setMask(struct novi_hw_entry* hw_entry);

#endif /* NOVI_HW_ENTRY_H_ */
