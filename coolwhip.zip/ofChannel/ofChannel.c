#include <pthread.h>
#include <sys/eventfd.h>
#include "ofChannel.h"
#include "novi_utils.h"
#include "ofl-utils.h"
#include "ofl.h"
#include "ofchannel_utils.h"
#include "ofchannel_role.h"
#include "cliLib.h"
#include "oxm-match.h"

#include "nl_lib_socket.h"
#include "noviIBSCommon.h"
#include "novi_netconf_handler.h"
#include "util.h"
#include "nl_lib_socket.h"
#include "novi_controller.h"

#define BUNDLE_OPENED 1
#define BUNDLE_CLOSED 2
#define BUNDLE_COMMITED 3




int event_fd = 0; /* Event fd that threads can write to, to wake main select() call. I.E. when adding a controller */
int novi_engine_openflow_socket=-1;
extern int noviengine_control_socket;  /* Receives command from NE on this socket */
int cli_cmd_socket = -1;
int cli_conf_socket = -1;
int netconf_server_skfd=-1;

extern int buf_out, buf_in;
int removeDbgFd(CONTROLLER_TUPLE *);
pthread_mutex_t *lock_cli;



CONTROLLER_TUPLE controller_clients[MAX_CLIENTS]={{0}};
/*
 * This is used to avoid always looping on MAX_CLIENTS for no reason.
 * It is only incremented whenever a controller is being added. Never decremented.
 * This is not optimal but it will do for now until general improvements can be made.
 */
int controller_clients_num;

PKT_LST *head=NULL;
#if defined(NOVIKIT) || defined(NOVICORIANT)
#define MAX_TRANS 500000
#else
#define MAX_TRANS 1000000
#endif
OFC_TRANS_TABLE trsTbl[MAX_TRANS];
OFC_TRANS_TABLE netConfTbl[MAX_TRANS];
#define NETCONF_TO_NOVIE 1 
#define NOVIE_TO_NETCONF 2

int ofc_close_all_controllers()
{
	int i=0;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(controller_clients[i].current)
			ofc_close_controller(controller_clients[i].current);
	}
	return OK;
}
void process_hello(CONTROLLER_TUPLE *client, struct ofp_hello *hello_msg)
{
	ofl_err error = 0;
	int len = ntohs(hello_msg->header.length);
	len -= sizeof(struct ofp_header);
	if (len <= 0)
	{
		if((hello_msg->header.version == OFP13_VERSION || 
			hello_msg->header.version == OFP14_VERSION ||
			hello_msg->header.version == OFP15_VERSION) &&
			client->version_bitmap & (1<<hello_msg->header.version)
			)
		{
			client->ofp_version = hello_msg->header.version;
		}
		else{
			error = ofl_error(OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE);
			goto Err;
		}
	}
	else
	{
		void* ptr = &hello_msg->elements[0];
		struct ofp_hello_elem_header *elem = ptr;
		while (len >= sizeof(struct ofp_hello_elem_header) && len>=ntohs(elem->length))
		{
			if (ntohs(elem->type) == OFPHET_VERSIONBITMAP)
			{
				struct ofp_hello_elem_versionbitmap *vbmp = (struct ofp_hello_elem_versionbitmap *)ptr;
				uint32_t hello_bitmap=ntohl(vbmp->bitmaps[0]);
				if ( ntohs(elem->length) <= 4 ) {
					error = ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_LEN);
					goto Err; 
				}
				if ( (hello_bitmap &  (1<<OFP15_VERSION)) &&
					 (client->version_bitmap & (1<<OFP15_VERSION)))
				{
					client->ofp_version=OFP15_VERSION;
				}

				else if ( (hello_bitmap &  (1<<OFP14_VERSION)) &&
					 (client->version_bitmap & (1<<OFP14_VERSION)))
				{
					client->ofp_version=OFP14_VERSION;
				}
				else if ( (hello_bitmap & (1<<OFP13_VERSION)) &&
					      (client->version_bitmap & (1<<OFP13_VERSION)) )
				{
					client->ofp_version=OFP13_VERSION;
				}
				else{
					error = ofl_error(OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE);
					goto Err;
				}
			} else
			{
				error = ofl_error(OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE);
				goto Err;  
			}
			/* Round up to account for possible zero padding */
			len -= ROUND_UP(ntohs(elem->length), 8);
			if (len < 0) {
				error = ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_LEN);
				goto Err;  
			}
			ptr += ROUND_UP(ntohs(elem->length), 8);
			elem = ptr;
		}
	}
Err:
	if (error)
	{
		ofChannel_sendErrorToController(client, error, (struct ofp_header *)hello_msg);
		ofc_close_controller(client);
	}
	else
	{
		ofc_ctrl_version_ref_inc(client->ofp_version);
	}
}
ofl_err openbundle(int bid,CONTROLLER_TUPLE *client, uint16_t flags)
{
	BUNDLE_NODE *bnode=NULL,**bheads=NULL;
	int i=0;
	ofl_err error = 0;

	// check existing bundle number
	int bundlenum = getExistbundlenum(client);

	bheads=client->bundle_heads;
	for(i=0;i<MAX_BUNDLE;i++)
	{
		if(bheads[i] && bheads[i]->bid == bid )
		{
			error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BUNDLE_EXIST);
			goto Err;
		}
	}

	if (MAX_BUNDLE == bundlenum)
	{
		error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_OUT_OF_BUNDLES);
		goto Err;
	}

	for(i=0;i<MAX_BUNDLE;i++)
	{
		if(bheads[i] == NULL )
		{
			bheads[i]=malloc(sizeof(BUNDLE_NODE));
			memset(bheads[i],0x0,sizeof(BUNDLE_NODE));
			bheads[i]->bid=bid;
			bheads[i]->flags = flags;
			bheads[i]->total_nodes = 0;
			bheads[i]->status=BUNDLE_OPENED;
			bheads[i]->error=OK;

			break;
		}
	}
Err:
	return error;
}

// add controller groupid and controllerid before sending to noviengine for message of type OFC_MSG 
int NoviWriteOfcmsg(int fd,void *buf, int data_len,CONTROLLER_TUPLE *client)
{
	struct novi_ofchannel_msg* ofchannel_msg=NULL;
	int msg_len = 0;
	int ret = 0;
	msg_len = sizeof(struct novi_ofchannel_msg) + data_len ;
	ofchannel_msg = malloc(msg_len);
	if( NULL == ofchannel_msg) return -1;
	memset(ofchannel_msg, 0x00, msg_len);
	snprintf(ofchannel_msg->contoller_info.controllername, CTRL_NAME_LEN+1, "%s", client->controllername);
	snprintf(ofchannel_msg->contoller_info.groupname, CTRL_NAME_LEN+1, "%s", client->groupname);
	memcpy(ofchannel_msg->ofp_message, (char*)buf, data_len);
	ret = write(fd, ofchannel_msg, msg_len);
	if (ofchannel_msg) 
	{
		free(ofchannel_msg);
		ofchannel_msg = NULL;
	}
	return ret;
}
void sendall_bundle(BUNDLE_NODE *bnode,CONTROLLER_TUPLE *client)
{
	BUNDLE_NODE *tmp=bnode;
	int ret=-1;
	while(tmp)
	{
#if 1
		if(tmp->data && tmp->data_len)
		{
			ret=NoviWriteOfcmsg(novi_engine_openflow_socket,tmp->data,tmp->data_len,client);
			ofchannel_print("Written :%d tp novi_engine_openflow_socket\n",ret);
		}
#endif
	tmp=tmp->next;
	}
}
void free_all_bundle(CONTROLLER_TUPLE *client,int index)
{
	BUNDLE_NODE *tmp,*bnode=NULL,**bheads=NULL;
	bheads=(BUNDLE_NODE**)client->bundle_heads;
	tmp=bnode=bheads[index];
	while(bnode)
	{
		tmp=bnode;
		bnode=bnode->next;
		free(tmp);
	}
	client->bundle_heads[index]=NULL;
}
ofl_err find_bundle(int bid,CONTROLLER_TUPLE *client,BUNDLE_NODE **pBnode,int *index, uint16_t flags)
{
	BUNDLE_NODE **bheads=NULL;
	int i=0;
	bheads=(BUNDLE_NODE**)client->bundle_heads;
	*pBnode=NULL;
	*index=-1;
	for(i=0;i<MAX_BUNDLE;i++)
	{
		if(bheads[i] && bheads[i]->bid == bid )
		{
			if(bheads[i]->flags != flags)
				return ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BAD_FLAGS);
			else
			{
				*pBnode=bheads[i];
				*index=i;
				return 0;
			}
		}
	}
	return ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BAD_ID);
}
ofl_err process_bundle_control(struct ofp_header* oh, struct ofl_msg_bundle_ctrl *bundle,int len,CONTROLLER_TUPLE *client)
{
	int bid=-1,index=-1;
	ofl_err error = 0;
    struct ofp_bundle_ctrl_msg b_reply;
	BUNDLE_NODE *bnode=NULL,**bheads=NULL;
	bheads=(BUNDLE_NODE**)client->bundle_heads;
	bid=bundle->bundle_id;

	b_reply.header.length = sizeof(struct ofp_bundle_ctrl_msg);
	b_reply.header.length = htons(sizeof(struct ofp_bundle_ctrl_msg));
	b_reply.header.version = bundle->header.version;
	b_reply.header.xid = oh->xid;
	b_reply.header.type = bundle->header.type;
	b_reply.bundle_id = ntohl(bundle->bundle_id);
	b_reply.flags = ntohs(bundle->flags);

	ofchannel_print("Bundle type:%d\n",bundle->type);
	if(bundle->type == OFPBCT_OPEN_REQUEST)
	{
		error=openbundle(bid,client,bundle->flags);
		if(error) goto Err;
		b_reply.type=ntohs(OFPBCT_OPEN_REPLY);
	}
	else if(bundle->type == OFPBCT_CLOSE_REQUEST)
	{
		error=find_bundle(bid,client,&bnode,&index,bundle->flags);
		if(error) goto Err;
		// if the bundle has already been closed
		if(bnode->status ==BUNDLE_CLOSED)
		{
			error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BUNDLE_CLOSED);
			free_all_bundle(client,index);
			goto Err;
		}
		bnode->status=BUNDLE_CLOSED;
		b_reply.type=ntohs(OFPBCT_CLOSE_REPLY);
	}
	else if(bundle->type == OFPBCT_COMMIT_REQUEST)
	{
		error=find_bundle(bid,client,&bnode,&index,bundle->flags);
		if(error) goto Err;
		bnode->status=BUNDLE_COMMITED;
		struct novi_ofchannel_msg* ofchannel_msg=NULL;

		struct ofp_bundle_ctrl_msg start_msg;
		struct ofp_bundle_ctrl_msg end_msg;
		memset(&start_msg, 0x00, sizeof(start_msg));
		memset(&start_msg, 0x00, sizeof(end_msg));

		/* Register xid to be able to catch the commit reply */
		addTrans(oh,client);

		/* Send message warning noviengine about the incoming bundle */
		start_msg.header.length = ntohs(sizeof(start_msg));
		start_msg.header.version = bundle->header.version;
		start_msg.header.type = OFPT_BUNDLE_CONTROL;
		start_msg.header.xid = oh->xid;
		start_msg.bundle_id = ntohl(bundle->bundle_id);
		start_msg.flags = ntohs(bundle->flags);
		start_msg.type = ntohs(OFPBCT_OPEN_REQUEST);
		NoviWriteOfcmsg(novi_engine_openflow_socket,&start_msg,sizeof(start_msg), client);

		ofchannel_print("Sending all to noviengine\n");
		/* Send bundle content */
		sendall_bundle(bnode,client);
		/* Send message telling noviengine the bundle is over */
		memcpy(&end_msg, &start_msg, sizeof(end_msg));
		end_msg.type = ntohs(OFPBCT_COMMIT_REQUEST);
		NoviWriteOfcmsg(novi_engine_openflow_socket,&end_msg,sizeof(end_msg),client);

		free_all_bundle(client,index);

		error = 0;
		goto Err;
	}
	else if(bundle->type == OFPBCT_DISCARD_REQUEST)
	{
		b_reply.type=ntohs(OFPBCT_DISCARD_REPLY);
		error=find_bundle(bid,client,&bnode,&index,bundle->flags);
		if(error) goto Err;
		free_all_bundle(client,index);
	}
	ofc_write(client,&b_reply,sizeof(b_reply));
Err:
	return error;
}
BUNDLE_NODE* ofc_find_bundle(CONTROLLER_TUPLE *client, int bundle_id)
{
	int i = 0;
	BUNDLE_NODE **bheads=NULL;
	bheads= (BUNDLE_NODE **) client->bundle_heads;
	for(i=0;i<MAX_BUNDLE;i++)
	{
		if(bheads[i] && bheads[i]->bid == bundle_id )
			return bheads[i];
	}
	return NULL;
}
ofl_err process_bundle_add(struct ofp_header* nested_msg, struct ofl_msg_bundle_add *bundle,CONTROLLER_TUPLE *client)
{
	ofl_err error = 0;
	BUNDLE_NODE *list = NULL, *new_node = NULL, *bundlelist_head=NULL;
	int xid = ntohl(nested_msg->xid);
	int index = 0;
	ofchannel_print("Bundle add\n");
	/* See if a bundle of this id already exists */
	list = ofc_find_bundle(client, bundle->bundle_id);
	if(list == NULL)
	{
		/* If it does not already exist, open a new bundle */
		error=openbundle(bundle->bundle_id,client, bundle->flags);
		if(error) goto Err;
	}

	error=find_bundle(bundle->bundle_id,client,&list,&index,bundle->flags);
	if(error) goto Err;

	if(list->flags != bundle->flags ) {
		error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BAD_FLAGS);
		goto Err;
	}

	if(list->status == BUNDLE_CLOSED ) {
		error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_BUNDLE_CLOSED);
		free_all_bundle(client, index);
		goto Err;
	}

	if(list->total_nodes == MAX_MESSAGE_PER_BUNDLE ) {
		error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_MSG_TOO_MANY);
		goto Err;
	}

	bundlelist_head = list;
	/* Go to the last message in the linked-list */
	while(list->next)
	{
		list=list->next;
		if (list->xid == xid)
		{
			error = ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_MSG_BAD_XID);
			goto Err;
		}
	}

	// allocate node and adance it to next
	if(bundle->ofl_message != NULL)
		error=ofc_verify_bundle_msg(bundle->ofl_message);
	if(error) goto Err;

	/* Changes the xid to the client index */
	addTrans(nested_msg,client);

	new_node=malloc(sizeof(BUNDLE_NODE));
	memset(new_node,0x0,sizeof(BUNDLE_NODE));
	new_node->data=malloc(ntohs(nested_msg->length));
	memcpy(new_node->data,nested_msg,ntohs(nested_msg->length));
	new_node->data_len=ntohs(nested_msg->length);
	new_node->xid = xid;
	bundlelist_head->total_nodes++;
	list->next=new_node;
Err:
	return error;
}

bool check_experimeter_in_matchfield(struct ofp_match *match)
{
	uint16_t total_length = ntohs(match->length);
	uint8_t* oxm_field = NULL;
	uint32_t header = 0, oxm_length = 0, length_add = 0, length = 0;
	length = total_length- (sizeof(struct ofp_match) -4);
	length_add = sizeof(struct ofp_match) -4;
	oxm_field = (uint8_t*)match+4;
	while (length > (sizeof(struct ofp_match)-4))
	{
		memcpy(&header, oxm_field, 4);
		header = ntohl(header);
		oxm_length = OXM_LENGTH(header);
		if(OXM_VENDOR(header) == 0xFFFF)
			return true;
		length_add =  4 + oxm_length;
		length -=length_add;
		oxm_field = oxm_field+length_add;
	}
	return false;
}

bool check_experimeter_in_action(struct ofp_action_header* data, uint16_t action_len)
{
	struct ofp14_action_header *act;
	uint8_t *action= (uint8_t *)data;
	while(action_len>= sizeof(struct ofp14_action_header))
	{
		act =  (struct ofp14_action_header *)action;
		if(ntohs(act->type) ==OFPAT_EXPERIMENTER)
			return true;
		action_len -= ntohs(act->len);
		action += ntohs(act->len);
	}
	return false;
}

bool check_experimenter_in_bundle(struct ofp_header* oh)
{
	struct ofp_bundle_add_msg *add_msg = (struct ofp_bundle_add_msg *) oh;
	struct ofp_instruction *inst;
	uint16_t inst_len = 0, bucket_len = 0;
	bool exp_exist = false;
	int message_length = 0;
	if (add_msg->message.type == OFPT_EXPERIMENTER)
	{
		exp_exist = true;
		goto End;
	}
	else if(add_msg->message.type == OFPT_FLOW_MOD)
	{
		struct ofp_flow_mod *sm = (struct ofp_flow_mod *)&add_msg->message;
		message_length = ntohs(add_msg->message.length);
		struct ofp_match *match = &(sm->match);
		uint8_t *d  = (uint8_t *)sm+ ROUND_UP(sizeof(struct ofp_flow_mod)-sizeof(struct ofp_match) + ntohs(sm->match.length), 8);
		inst_len = message_length-ROUND_UP(sizeof(struct ofp_flow_mod)-sizeof(struct ofp_match) + ntohs(sm->match.length), 8);

		// search if experimenter exists in matchfield
		if (ntohs(match->type) ==OFPMT_OXM)
			exp_exist = check_experimeter_in_matchfield(match);
		if (exp_exist == true)
			goto End;

		// search if OFPAT_EXPERIMENTER exists in instruction
		while(inst_len >= sizeof(struct ofp_instruction)- 4)
		{
			inst = (struct ofp_instruction *)d;
			if ( (ntohs(inst->type) == OFPIT_WRITE_ACTIONS) || (ntohs(inst->type) == OFPIT_APPLY_ACTIONS))
			{
				if(ntohs(inst->len) >=  sizeof(struct ofp_instruction_actions))
				{
					uint16_t action_len = ntohs(inst->len)- sizeof(struct ofp_instruction_actions);
					struct ofp_instruction_actions *si = (struct ofp_instruction_actions *)inst;
					exp_exist = check_experimeter_in_action(&si->actions, action_len);
					if (exp_exist == true)
						goto End;
				}
			}
			inst_len -= ntohs(inst->len);
			d += ntohs(inst->len);
		}
	}
	else if(add_msg->message.type == OFPT_GROUP_MOD)
	{
		// check whether OFPAT_EXPERIMENTER exists in bucket
		struct ofp_group_mod *sm = (struct ofp_group_mod *)&add_msg->message;
		message_length = ntohs(add_msg->message.length);
		bucket_len = message_length - sizeof(struct ofp_group_mod);
		struct ofp_bucket *bucket;
		uint8_t *buckets = (uint8_t *)sm->buckets;
		while(bucket_len >= sizeof(struct ofp_bucket))
		{
			bucket = (uint8_t*)buckets;
			int act_len = ntohs(bucket->len) - sizeof(struct ofp_bucket);
			exp_exist = check_experimeter_in_action(&bucket->actions, act_len);
			if (exp_exist == true)
				goto End;
			bucket_len -= ntohs(bucket->len);
			buckets += ntohs(bucket->len);
		}
	}

End:
	return exp_exist;
}
void process_bundle(struct ofp_header *oh,int len,CONTROLLER_TUPLE *client)
{
	struct ofl_msg_header* msg = NULL;
	uint32_t xid = 0;
	ofl_err error ;
	struct ofp_bundle_add_msg *add_msg = (struct ofp_bundle_add_msg *) oh;
	if(add_msg->header.type ==OFPT_BUNDLE_ADD_MESSAGE)
	{
		if(check_experimenter_in_bundle(oh))
		{
			struct ofl_msg_bundle_add* msg_experimenter = NULL;
			msg_experimenter = calloc(1, sizeof(struct ofl_msg_bundle_add));
			msg_experimenter->bundle_id = ntohl(add_msg->bundle_id);
			error=process_bundle_add(&add_msg->message, msg_experimenter,client);
			free(msg_experimenter);
			goto Err;
		}
	}
	error = ofl_msg_unpack((uint8_t*) oh, len, &msg, &xid, NULL);
	if(error) goto Err;
	if (msg->type == OFPT_BUNDLE_CONTROL)
		error=process_bundle_control(oh, (struct ofl_msg_bundle_ctrl*)msg,len,client);
	else if (msg->type == OFPT_BUNDLE_ADD_MESSAGE)
	{
		struct ofp_bundle_add_msg *add_msg = (struct ofp_bundle_add_msg *) oh;
		error=process_bundle_add(&add_msg->message, (struct ofl_msg_bundle_add*)msg,client);
	}
Err:
	if (error) ofChannel_sendErrorToController(client, error, oh);
	ofl_msg_free(msg, NULL);
}
int ofc_process_message(CONTROLLER_TUPLE *client, struct ofp_header *oh,int len)
{
#define OFC_MSG 0
#define NOVIENGINE_MSG 1

	ofl_err error = 0;
	switch(oh->type)
	{
		case OFPT_ROLE_REQUEST:
			error = ofc_process_role_request(client, (struct ofp_role_request *) oh, len);
			if (error)
				ofChannel_sendErrorToController(client, error, oh);
			return OFC_MSG;
		case OFPT_SET_ASYNC:
		{
			if (oh->version == OFP13_VERSION)
				error = ofc_process_set_async_13(client, (struct ofp13_async_config *) oh);
			else if (oh->version == OFP14_VERSION)
				error = ofc_process_set_async_14(client, (struct ofp14_async_config *) oh, len);
			else if (oh->version == OFP15_VERSION)
				error = ofc_process_set_async_14(client, (struct ofp14_async_config *) oh, len);
			else
				error = ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_VERSION);

			if (error)
				ofChannel_sendErrorToController(client, error, oh);

			return OFC_MSG;
		}
		case OFPT_HELLO:
			process_hello(client, (struct ofp_hello *)oh);
			return OFC_MSG;
		case OFPT_GET_ASYNC_REQUEST:
		{
			if (oh->version == OFP13_VERSION)
				error = ofc_process_get_async_13(client, oh);
			else if (oh->version == OFP14_VERSION)
				error = ofc_process_get_async_14(client, oh);
			else if (oh->version == OFP15_VERSION)
				error = ofc_process_get_async_15(client, oh);
			else
				error = ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_VERSION);

			if (error)
				ofChannel_sendErrorToController(client, error, oh);
			return OFC_MSG;
		}
		case OFPT_ECHO_REQUEST:
		{
			struct ofp_header *h_reply = (struct ofp_header *)oh;
			h_reply->version = client->ofp_version;
			h_reply->type = OFPT_ECHO_REPLY;
			h_reply->xid = oh->xid;
			ofc_write(client, oh, len);
			return OFC_MSG;
		}
		case OFPT_BUNDLE_CONTROL:
		case OFPT_BUNDLE_ADD_MESSAGE:
			process_bundle(oh,len,client);
			return OFC_MSG;
		default:
			return NOVIENGINE_MSG;
	}
	return OFC_MSG;
}

void send_list(int novi_engine_openflow_socket)
{
	int ret=0;
	PKT_LST *tmp,*tmp2=head;
	while(tmp2 && tmp2->pkt)
	{
		ret=nl_socket_write(novi_engine_openflow_socket,tmp2->pkt,tmp2->pkt_len);
		usleep(100);
		tmp=tmp2;
		tmp2=tmp2->next;
		free(tmp->pkt);
		tmp->pkt=NULL;
	}
}
void list_pkts()
{
	PKT_LST *tmp=head;
	while(tmp != NULL)
	{
	tmp=tmp->next;
	}
}

signed char createNode(char *buf,int pkt_len,PKT_LST **node)
{
	PKT_LST *tmp=NULL;
	signed char ret=-1;
	tmp=malloc(sizeof(PKT_LST));
	if(tmp == NULL) goto Err;
	tmp->pkt=malloc(pkt_len+1);
	if(tmp->pkt == NULL) goto Err;
	memset(tmp->pkt,0x0,pkt_len+1);
	tmp->pkt_len=pkt_len;
	memcpy(tmp->pkt,buf,pkt_len);
	tmp->next=tmp->prev=NULL;
	*node=tmp;
	ret=0;
Err:
	if(ret != 0 )
	{
		if(tmp)free(tmp);
		if(tmp && tmp->pkt ) free(tmp->pkt);
	}
	return ret;

}

void appendNode(PKT_LST *node)
{
	PKT_LST *tmp=head;
	while(tmp->next != NULL) tmp=tmp->next;
	tmp->next=node;
	node->prev=tmp;
}

signed char addPkt(char *buff,int pkt_len)
{

	PKT_LST *node=NULL;
	char ret=-1;
	ret=createNode(buff,pkt_len,&node);
	if(ret != 0 || node == NULL) goto Err;
	if(head == NULL)
	{
		ret=0;
		head=node;
		goto Err;
	}
	appendNode(node);
	ret=0;
Err:
	return ret;
}
void remove_all_trans(CONTROLLER_TUPLE *client)
{
	int i = 0;
	for(i=0;i<MAX_TRANS;i++)
	{
		if(trsTbl[i].client == client)
			memset(&trsTbl[i],0x0,sizeof(OFC_TRANS_TABLE));
	}
}
int lookupTransNetConf(TLV *header,int **netConfFd)
{
	unsigned int index = header->val_bitmap;
	if (index >= MAX_TRANS)
		return -1;
	
	ofchannel_print("rcvd bitmap:%d --> %d \n",index, netConfTbl[index].trans_id);
	header->val_bitmap= netConfTbl[index].trans_id;
	if (netConfTbl[index].client == NULL) return -1;
		
	*netConfFd=netConfTbl[index].client;
	ofchannel_print("Fd ptr:%p\n",*netConfFd);
	return 0;
}


addTransNetConf(TLV *tlv, int *netconfFd)
{
	static uint32_t index = 1;
	netConfTbl[index].trans_id=tlv->val_bitmap;
	netConfTbl[index].client=netconfFd;
	tlv->val_bitmap = index;
	ofchannel_print("bitmap to index translation :%d-->%d\n",tlv->val_bitmap,index);
	index = (index+1)%MAX_TRANS;
	return 0;

}
/*
 * Register the transaction ID of message with its source controller. It will replace the actual
 * transaction id inside the message by the index of the transaction table where the data will be stored.
 */
int addTrans(struct ofp_header *header,CONTROLLER_TUPLE *client)
{
	static uint32_t index = 0;
	trsTbl[index].trans_id=header->xid;
	trsTbl[index].client=client;
	header->xid = index;
	index = (index+1)%MAX_TRANS;
	return 0;

}

int addNetConfClients(int *arr,int fd)
{
	int i=0;
	for (i=0;i<MAX_CLIENTS;i++)
	{
		if(arr[i] == 0) { arr[i]=fd;break;}
	}

}
/*
 * Retrieve the transaction id from a message that is going to controller.
 * The ID in the message corresponds to the index in the transaction table where the real XID is found.
 * This assumes that the transaction id was registered with 'addTrans()' prior.
 * This function should not be called for async messages.
 */
int lookupTrans(struct ofp_header *header,CONTROLLER_TUPLE **client)
{
	unsigned int index = header->xid;
	if (index >= MAX_TRANS)
		return -1;
	header->xid = trsTbl[index].trans_id;
	if (trsTbl[index].client == NULL) return -1;
	*client=trsTbl[index].client;
	// change the xid for the nested message if needed
	if(header->type == OFPT_ERROR)
	{
		struct ofp_error_msg* error_msg = (struct ofp_error_msg*)header;
		struct ofp_header* nested_msg = (struct ofp_header*)error_msg->data;
		nested_msg->xid = header->xid;
	}	
	return 0;
}

void manage_connection(void *data)
{
	int reply_timeout;
	int skfd=0,i;
	CONTROLLER_TUPLE *h=NULL,*client = NULL;
	int index=0;
	while (1)
	{
		reply_timeout= set_get_echo_flag(OFC_GET_ECHO,0)  - 1;

		/* if echo value is 0, bypass the echo handling */
		if (reply_timeout >= 0)
		{
			for(i=0;i<controller_clients_num;i++)
			{
				h=client = controller_clients[i].current;
				if(client == NULL ) continue;
				index=0;
				//pthread_mutex_lock(lock_cli);

				if( client->fd > 0 && client->rcvd_bitmap > 0 && client->sent_bitmap > 0 &&
						(client->rcvd_bitmap - client->sent_bitmap) >= reply_timeout )
				{
					updateStatus(client, DISCONNECTED);
					updateRole  (client, OFPCR_ROLE_EQUAL);
					updateReason(client, ECHO_REPLIED_NOT_RECEIVD);
					close(client->fd);
					usleep(200000);
					client->fd=0;
					client->not_rcvd=client->rcvd_bitmap=client->sent_bitmap=0;
					usleep(100);
					continue;
				}
				else if( client->fd > 0 && client->not_rcvd > 0 && client->sent_bitmap > 0 &&
						client->rcvd_bitmap == 0 && (client->not_rcvd - client->sent_bitmap) >= reply_timeout )
				{
					updateStatus(client, DISCONNECTED);
					updateRole  (client, OFPCR_ROLE_EQUAL);
					updateReason(client, ECHO_REPLIED_NOT_RECEIVD);
					close(client->fd);
					usleep(200000);
					client->fd=0;
					client->not_rcvd=client->rcvd_bitmap=client->sent_bitmap=0;
					usleep(100);
					continue;
				}
				if(client->fd > 0)
					client->not_rcvd=(times(NULL)/sysconf(_SC_CLK_TCK));
			//	pthread_mutex_unlock(lock_cli);
			}
		}
		usleep(10000);
	}
}


void manage_echos(void *data)
{
	unsigned char interval;
	unsigned char delta=0;
	int now=0,i,ret;
	struct ofp_header oh ;
	int start=(times(NULL)/sysconf(_SC_CLK_TCK));
	int index=0;
	CONTROLLER_TUPLE *h,*client = NULL;
	//printf("INTERVAL :%d\n",interval);
	oh.version=OFP_VERSION;
	oh.type=OFPT_ECHO_REQUEST;
	oh.length=ntohs(sizeof(oh));
	oh.xid=rand();
	now=start;
	while(1)
	{
		interval= set_get_echo_flag(OFC_GET_ECHO,0);

		/* if echo value is 0, bypass the echo handling */
		if (interval > 0)
		{
			for(i=0;i<controller_clients_num;i++)
			{
				h=client = controller_clients[i].current;
				index=0;
				if(client == NULL ) continue;
				if(client->activity_bitmap == -1 || client->fd <= 0) continue;
				else if(client->activity_bitmap == 0) delta=now-start;
				else  delta=now-client->activity_bitmap;
				if(client->fd > 0 && delta >= interval  )
				{
					oh.version = client->ofp_version;
					ret = ofc_write(client, &oh, sizeof(oh));

					client->sent_bitmap=(times(NULL)/sysconf(_SC_CLK_TCK));
					client->rcvd_bitmap=0;
					client->not_rcvd=0;
					start=now;
					client->activity_bitmap=0;
					//ofchannel_print("Sent %d byts frm thread:\n", ret);
				}
			}
		}

		usleep(10000);
		now=(times(NULL)/sysconf(_SC_CLK_TCK));
	}
}

void sig_hdlr(int sig){}
void cleanup_and_exit(int signum)
{
	int i = 0;
	CONTROLLER_TUPLE *next=NULL;

	if (signum != SIGNAL_CLEANUP) return;

	ofchannel_print("ofChannel: Closing sockets\n");
	for (i = 0; i<MAX_CLIENTS; i++)
	{
		if(controller_clients[i].next == NULL ) continue;
		next=controller_clients[i].next;
		while(next)
		{
			ofc_close_controller(next);
			next=next->next;
		}
	}
	if (noviengine_control_socket > 0) close(noviengine_control_socket);
	if (novi_engine_openflow_socket > 0) close(novi_engine_openflow_socket);
	if (cli_cmd_socket > 0) close(cli_cmd_socket);
	if (cli_conf_socket > 0) close(cli_conf_socket);

	unlink(OFCHANNEL_PID_FILE);
	cib_destroy();

	exit(0);
}


void handle_noviengine_openflow()
{
	int pkt_len = 0, i = 0, ret = 0;
	uint16_t len_flipped = 0;
	struct ofp_header oh ;
	char *ofp_message = NULL;
	char *ptr = NULL;
	CONTROLLER_TUPLE *client = NULL;
	CONTROLLER_TUPLE *client_tmp = NULL;
	int len=0;
	/* In case if it is reply of Queued packets then receive it with same size */
	if(head)
	{
		PKT_LST *tmp=head;
		len=head->pkt_len;
		head=head->next;
		free(tmp);
	}

	memset(&oh, 0x00, sizeof(struct ofp_header));
	pkt_len=read(novi_engine_openflow_socket,&oh,sizeof(struct ofp_header));
	if(pkt_len <= 0) { close(novi_engine_openflow_socket);novi_engine_openflow_socket=0;goto Err;}
	len_flipped = ntohs(oh.length);
	ofp_message = malloc(len_flipped);
	if (ofp_message == NULL) goto Err;
	memset(ofp_message, 0x00, sizeof(struct ofp_header));
	memcpy(ofp_message,&oh,sizeof(struct ofp_header));

	int read_len = pkt_len;
	while (read_len < len_flipped)
	{
		ptr = ofp_message + read_len;
		pkt_len=read(novi_engine_openflow_socket, ptr,len_flipped - read_len);
		if(pkt_len <= 0) { close(novi_engine_openflow_socket);novi_engine_openflow_socket=0;goto Err;}
		read_len += pkt_len;
	}

	/*
	 *  If Noviengine is sending out an Async Msg, do the Async msg check and do not add
	 *  this msg into ofChannel transaction ID, and Jump to Next Socket Processing
	 */

	if (ofc_msg_is_async(oh.type))
	{
		// find the controller which sent GROUP/METER state message and replace the abstracted XID with the one from the controller 
 		if(oh.type == OFPT_REQUESTFORWARD)
 		{
			if(lookupTrans((struct ofp_header *) ofp_message,&client_tmp) < 0)
				goto End;
			// update length and xid in request 
			struct ofp_header* request = &((struct ofp_requestforward_header *) ofp_message)->request;
			request->xid = ((struct ofp_header *) ofp_message)->xid;
 		}		
		for (i = 0; i<controller_clients_num; i++)
		{
			client=controller_clients[i].current;
			if(client == NULL ) continue;
			if (client->fd <= 0)
				continue;

			/* compare the message against the async configuration of every controller */
			if (!ofc_async_msg_validate(&controller_clients[i], (struct ofp_header*) ofp_message))
				continue;

			/* forward requestforward message to other controllers*/
			if(oh.type == OFPT_REQUESTFORWARD)
			{               
				// if the controller is NOT the same one sending group/meter state message
				if(client != client_tmp)
				{
					if(oh.version == client->ofp_version)
					{
					 	ret = ofc_write(client, ofp_message, len_flipped);
					 	if (ret > 0)
					 	{
					 		/* Log message */
					 		ofc_log_msg((struct ofp_header *) ofp_message,OUTGOING);
					 	}
					}
				}
				continue;
			}
			else if(oh.version == client->ofp_version)
			{
				ret = ofc_write(client, ofp_message, len_flipped);
				if (ret > 0)
				{
					/* Log message */
					ofc_log_msg((struct ofp_header *) ofp_message,OUTGOING);
				}
			}
		}
		goto End;
	}

	/* If the message is synchronous, we need to replace the abstracted XID with the one from the controller */
	if (lookupTrans((struct ofp_header *) ofp_message,&client) < 0)
	{
		ofchannel_print("ofChannel Transaction Lookup failed:%#16"PRIx32"\n", ntohl(oh.xid));
		goto Err;
	}
	ofchannel_print("OFchannel: Received message from noviengine: read_len: %"PRIuPTR", oh.length: %"PRIu16", type: %"PRIu8"\n",
		pkt_len+sizeof(struct ofp_header), len_flipped, oh.type);

	/*
	 * TODO : This is failing in case of Queued packets need to fix Stsegment
	 *
	 * If this packet is a response to a previous message, sent it back to specific controller
	 *
	 * Log all Noviengine Reply msgs to ofl msg logfile.
	 */


	if(oh.type == OFPT_FEATURES_REPLY && client->is_aux )
	{
		struct ofp_switch_features *f_reply=ofp_message;
		f_reply->auxiliary_id=client->con_id;
	}
	/* Log message */
	ret = ofc_write(client, ofp_message, len_flipped);
	if (ret > 0)
	{
		ofc_log_msg((struct ofp_header *) ofp_message,OUTGOING);
	}

End:
Err:
	if (ofp_message) free(ofp_message);
}

/*
 * Handles control commands from noviengine, such as:
 * add controller , remove controller , show controller etc..
 */
int handle_ofc_command(int *fd, enum ofc_cmd_src src)
{
	int ret = ERROR;
	char *send_buff=NULL;
	int snd_len=0, pkt_len = 0;
	TLV *tlv = NULL;

	pkt_len=read_cli_tlv(*fd, &tlv, USE_DEFAULT_TIMEOUT);
	if(pkt_len <= 0 || tlv == NULL)
	{
		return ERROR;
	}
	ret = process_command(src,tlv,pkt_len,&send_buff,&snd_len);

	NOVI_BITMAP bmp;
	bmp.bitmap = tlv->val_bitmap;
	tlv->type = ret;

	SET_RES(&bmp, NOVISH_RESULT);
	ret = cli_cmd_to_socket(fd, tlv->type, send_buff, snd_len, &bmp);

	if (send_buff) free(send_buff);
	if (tlv) free(tlv);
	return OK;
}

int handle_controller_openflow(CONTROLLER_TUPLE *client)
{
	char *ofp_message = NULL;
	struct ofp_header oh ;
	int len = 0;
	int pkt_len = 0;
	int ret=0;
	int msg_len = 0;
	struct novi_ofchannel_msg* ofchannel_msg=NULL;

	/* little endian converted variables */
	unsigned short len_flipped = 0;

	/* Read the OpenFlow header to fetch the length of the packet */
	memset(&oh,0x0,sizeof(struct ofp_header));
	pkt_len = ofc_read(client, &oh, sizeof(struct ofp_header));
	if(pkt_len <= 0 )
	{
		ofc_close_controller(client);
		goto Err;
	}
	len_flipped = ntohs(oh.length);
	if(len_flipped < sizeof(struct ofp_header))
	{
		ofc_close_controller(client);
		goto Err;
	}

	if(oh.type == OFPT_HELLO )
		client->activity_bitmap=0;

	if(client->activity_bitmap == -1 )
		return 0;

	if(oh.type == OFPT_ECHO_REPLY )
	{
		client->rcvd_bitmap=(times(NULL)/sysconf(_SC_CLK_TCK));
		client->not_rcvd=0;
		goto Err;
	}
	else
	{
		client->activity_bitmap=(times(NULL)/sysconf(_SC_CLK_TCK));
	}
	msg_len = sizeof(struct novi_ofchannel_msg) + len_flipped ;
	ofchannel_msg = calloc(1, msg_len);
	if (ofchannel_msg == NULL) goto Err;
	snprintf(ofchannel_msg->contoller_info.controllername, CTRL_NAME_LEN+1, "%s", client->controllername);
	snprintf(ofchannel_msg->contoller_info.groupname, CTRL_NAME_LEN+1, "%s", client->groupname);
	ofp_message = ofchannel_msg->ofp_message;

	memset(ofp_message,0x0,len_flipped);
	memcpy(ofp_message,&oh,sizeof(struct ofp_header));

	while (pkt_len < len_flipped)
	{
		char *ptr=NULL;
		int read_len = 0;
		/* Read further into the socket to fetch the message following the header */
		ptr=ofp_message+pkt_len;
		read_len = ofc_read(client, ptr, len_flipped - pkt_len);
		if(read_len <= 0)
		{
			ofChannel_sendErrorToController(client, ofl_error(OFPET_BAD_REQUEST,OFPBRC_BAD_LEN), (struct ofp_header*) ofp_message);
			ofc_close_controller(client);
			goto Err;
		}
		else
			pkt_len += read_len;
	}

	if(oh.version != client->ofp_version && oh.type != OFPT_HELLO)//Verify packet version
	{
		/* Hello versions will be handled differently */
		ofChannel_sendErrorToController(client, ofl_error(OFPET_BAD_REQUEST,OFPBRC_BAD_VERSION), (struct ofp_header*) ofp_message);
		goto Err;
	}

	/* Log message */
	ofc_log_msg((struct ofp_header *) ofp_message,INCOMING);

	if(client->res != 1)
	{
		/* If controller is a normal openflow controller (i.e. not ofclient), come here */
		/* Verify if client is allowed to send message (i.e. slave vs master) */
		ret = ofc_is_client_allowed(client,ofp_message);
		if(ret == OFC_REJECT_SLAVE_MSG)
		{
			ofChannel_sendErrorToController(client, ofl_error(OFPET_BAD_REQUEST,OFPBRC_IS_SLAVE), (struct ofp_header *) ofp_message);
			goto Err;
		}

		/* Check the message type and decide if message should go to noviengine or be processed by ofChannel only */
		ret = ofc_process_message(client, (struct ofp_header*) ofp_message, len_flipped);
		if( ret == OFC_MSG ) goto Err;
	}
	else
	{
		/* If controller is an ofclient */
		if(oh.type == OFPT_HELLO && client->res == 1)
		{
			// send hello message back to ofclient
			struct ofp_hello *hello = NULL;
			struct ofp_hello_elem_versionbitmap *vbmp = NULL;
			int hello_len = 0;
			hello_len = sizeof(struct ofp_hello) + sizeof(struct ofp_hello_elem_versionbitmap) + sizeof(uint32_t);
			hello = malloc(hello_len);
			if (hello == NULL) return -1;
			memset(hello, 0x00, hello_len);
			if(client->version_bitmap & (1<<OFP15_VERSION)){
				hello->header.version = OFP15_VERSION;
			}
			else if (client->version_bitmap & (1<<OFP14_VERSION)){
				hello->header.version = OFP14_VERSION;
			}
			else {
				hello->header.version = OFP13_VERSION;
			}

			hello->header.type    = OFPT_HELLO;
			hello->header.length  = htons(hello_len);
			hello->header.xid     = htonl(rand());

			vbmp = (struct ofp_hello_elem_versionbitmap *)&hello->elements[0];
			vbmp->type = htons(OFPHET_VERSIONBITMAP);
			vbmp->length = htons(sizeof(*vbmp) + sizeof(uint32_t));
			vbmp->bitmaps[0] = htonl(client->version_bitmap);
			ofc_write(client, hello, hello_len);
			free(hello);

			process_hello(client, (struct ofp_hello*)ofp_message);
			goto Err; /* don't go to noviengine for this message */
		}
	}

	while(novi_engine_openflow_socket  <= 0)
	{
		novi_engine_openflow_socket=nl_socket_tcp4client_connect(NOVIENGINE_IP, OFC_NE_OPENFLOW_PORT);
		usleep(100);
	}


	/* Before sending to noviengine, modify the XID to our own (unique). Allows us to keep track with multiple controllers) */
	addTrans((struct ofp_header *) ofp_message,client);
	if(novi_engine_openflow_socket > 0 )
	{
		len=nl_socket_write(novi_engine_openflow_socket,ofchannel_msg,msg_len);
		if(len < 0) {ofchannel_print("Send Failed Line:%d,Function:%s\n",__LINE__,__FUNCTION__);}
		// ofchannel_print("Send to Noviengine type = %d, len=%d fd=%d\n",oh.type,len,client->fd);
	}
	else
	{
		ofchannel_print("Adding pkt to list\n");
		// Queue packet somewhere may be in linked list
		addPkt(ofchannel_msg,msg_len);
	}

	ret=0;
Err:
	if (ofchannel_msg)
	{
		free(ofchannel_msg);
		ofchannel_msg = NULL;
	}
	return ret;
}

int ofc_save_config(int type, void* structure, int size)
{
	return send_config_request(&cli_conf_socket, type, CONFIG_SET, structure, size);
}

int ofc_del_config(int type, void* structure, int size)
{
	return send_config_request(&cli_conf_socket, type, CONFIG_DELETE, structure, size);
}
int tid=0;
#include <pthread.h>
#include <asm/unistd.h>
pid_t gettid( void )
{
        tid=syscall(__NR_gettid);
	return ;
}

int handle_cli_request()
{
	fd_set rfds;
	int maxfd=0,ret=-1;
	struct timeval timeout;
	gettid();
	while(1)
	{
		timeout.tv_sec = 0;
		timeout.tv_usec = 2000;
		FD_ZERO(&rfds);

		NL_FD_SET(cli_cmd_socket, rfds, maxfd)
		NL_FD_SET(noviengine_control_socket, rfds, maxfd)

		errno = 0;
		ret = select(maxfd + 1, &rfds, NULL, NULL, &timeout);
		if (ret <= 0 || errno == EINTR)
		{
			if(cli_cmd_socket <= 0)
			{
				cli_cmd_socket=nl_socket_tcp4client_connect(LOCAL_IP, CLI_OFC_PORT);
			}
			if(noviengine_control_socket <= 0)
			{
				noviengine_control_socket=nl_socket_tcp4client_connect(NOVIENGINE_IP, OFC_NE_COMMAND_PORT);
			}
			continue;
		}
		if( NL_FD_READABLE(cli_cmd_socket, rfds))
		{
			if (handle_ofc_command(&cli_cmd_socket, OFC_CMD_CLI) != OK)
			{
				close(cli_cmd_socket);
				cli_cmd_socket = -1;
			}
		}
		/* Check for configuration/commands received from noviengine/cli */
		if( NL_FD_READABLE(noviengine_control_socket, rfds))
		{
			if (handle_ofc_command(&noviengine_control_socket, OFC_CMD_NOVI) != OK)
			{
				close(noviengine_control_socket);
				noviengine_control_socket = -1;
			}
		}
	}
}
check_thread(int tid)
{
	char buff[1024];
	memset(buff,0x0,sizeof(buff));
	snprintf(buff, sizeof(buff),"/proc/%d/task/%d",getpid(),tid);
	if(access(buff,F_OK) == 0)
		return 0;
	return 1;
}
int main(int argc,char *argv[])
{
	pthread_t echo_thread,connection_mgmt,cli_thread;
	int maxfd=-1,ret=-1,i=0;
	fd_set rfds;
	struct timeval timeout;

	/* Set rlimits */
	set_coredump();

	init_ssl();
	initBundleHooks();
	initOfcSecurityProfiles();
	lock_cli=malloc(sizeof(pthread_mutex_t));
	if(lock_cli == NULL) {exit(1);}
	pthread_mutex_init(lock_cli, NULL);
	memset(controller_clients,0,sizeof(CONTROLLER_TUPLE) * MAX_CLIENTS);
	memset(trsTbl,0x0,sizeof(OFC_TRANS_TABLE) * MAX_TRANS);
	event_fd = eventfd(0, 0);

	/* Upon receiving SIGUSR1 signal, process should cleanup and exit */
	signal(SIGNAL_CLEANUP, cleanup_and_exit);
	signal(SIGTRAP,sig_hdlr);

	generate_pid_file(OFCHANNEL_PID_FILE);

    for (i = 0; i<MAX_CLIENTS; i++)
    {
        init_controller_tables(i);
        ofc_async_set_default(&controller_clients[i]);
    }
	pthread_create (&echo_thread, NULL, (void *) manage_echos, NULL);
	pthread_create (&connection_mgmt, NULL, (void *) manage_connection, NULL);
	/* TODO : we might need to make this thread RT */
	pthread_create (&cli_thread, NULL, (void *) handle_cli_request, NULL);

	sleep(1);

	oxm_initialize_fields_hmap();
	cib_hashInit();
	novicib_del_data(NoviCIB_Major_ofChannel, NoviCIB_Minor_ofChannel_Versions, 0);
	/* Socket creation commented for NW400.1.8 only */
	//netconf_server_skfd = nl_socket_tcp4server_create(LOCAL_IP, NET_CONFIG_SERVER_PORT);

	int index=0;
	CONTROLLER_TUPLE *h=NULL,*client = NULL;
	while ( 1 )
	{
		/* Check if linked list*/
		/* This fn sends all packets from list to noviengine socket accpt reply and push it to queue till whole list is empty */
		if(novi_engine_openflow_socket > 0)
			send_list(novi_engine_openflow_socket);
		maxfd = -1;
		timeout.tv_sec = 1;
		timeout.tv_usec = 0;
		FD_ZERO(&rfds);
		NL_FD_SET(netconf_server_skfd, rfds, maxfd)
		NL_FD_SET(event_fd, rfds, maxfd)

		pthread_mutex_lock(lock_cli);
		for(i=0;i<controller_clients_num;i++)
		{
			h=client=controller_clients[i].current;
			if(client == NULL) continue;
			index=0;
			do
			{
				NL_FD_SET(client->fd, rfds, maxfd)
				getNextAux(h,&index,&client);
				if(client == NULL ) break;
			}while(1);
		}
		pthread_mutex_unlock(lock_cli);
		NL_FD_SET(novi_engine_openflow_socket, rfds, maxfd)
		NL_FD_SET(cli_conf_socket, rfds, maxfd)

		errno=0;
		ret = select(maxfd + 1, &rfds, NULL, NULL, &timeout);
		if (ret <= 0 || errno == EINTR)
		{
			/* Establish connection with noviengine sockets */
			if(novi_engine_openflow_socket <= 0)
			{
				novi_engine_openflow_socket=nl_socket_tcp4client_connect(NOVIENGINE_IP, OFC_NE_OPENFLOW_PORT);
			}
			if(cli_conf_socket <= 0)
			{
				cli_conf_socket=nl_socket_tcp4client_connect(LOCAL_IP, CLI_CONFIG_SERVER_PORT);
			}
                       //TODO : uncomment  to enable thread respwan in case thread crashed 
                       // check_thread will check if thread crashed returns 1 if crashed 
#if 0
                       if(check_thread(tid) == 1 )
                       {
                               pthread_create (&cli_thread, NULL, (void *) handle_cli_request, NULL);
                       }
#endif
			usleep(1000);
			continue;
		}
		if(NL_FD_READABLE(event_fd, rfds))
		{
			/* If something happened on event_fd, it means that select must break and start over, new controller has been added. */
			uint64_t dummy;
			ret=read(event_fd,&dummy,sizeof(dummy));
			continue;
		}
		if(NL_FD_READABLE(netconf_server_skfd, rfds))
		{
			int fd=0;
			fd = nl_socket_tcp4_accept(netconf_server_skfd);
			continue;
		}
		/* Check for Openflow messages received from noviengine to forward to controllers */
		if( NL_FD_READABLE(novi_engine_openflow_socket, rfds))
		{
			/* This sleep is required to avoid TCP RST problems! */
			handle_noviengine_openflow();
			usleep(100);
		}
		if( NL_FD_READABLE(cli_conf_socket, rfds))
		{
			/* Should never get here, this is just in case */
			char buff[1000] = "";
			ret=read(cli_conf_socket,buff,sizeof(buff));
			if(ret <= 0) { close(cli_conf_socket); cli_conf_socket=-1;}
			usleep(100);
		}
		/* Check for Openflow messages received from controllers */
		for(i=0;i<controller_clients_num;i++)
		{
			h=client=controller_clients[i].current;
			if(client  == NULL ) continue;
			index=0;
			do
			{
				//	pthread_mutex_lock(lock_cli);
				if ( NL_FD_READABLE(client->fd, rfds))
				{
					handle_controller_openflow(client);
				}
				getNextAux(h,&index,&client);
				//	pthread_mutex_unlock(lock_cli);
				if(client == NULL ) break;
			}while(1);
		}
	}
	return 0;
}

int getExistbundlenum(CONTROLLER_TUPLE *client)
{
	BUNDLE_NODE **bheads=NULL;
	int i=0;
	int bundle_num = 0;
	bheads= (BUNDLE_NODE **)client->bundle_heads;

	for(i=0;i<MAX_BUNDLE;i++)
	{
		if(bheads[i])
		{
			bundle_num++;
		}
	}
	return bundle_num;
}
