#include <pthread.h>
#include "ofChannel.h"
#include "ofchannel_utils.h"
#include "novi_utils.h"
#include "c_config.h"
#include "cli_show_structs.h"
#include "ofchannel_role.h"
#include "cliLib.h"
#include "nl_lib_socket.h"
#include "novi_netconf_handler.h"

extern int event_fd; /* From ofChannel.c. Threads can write to, to wake main select() call. I.E. when adding a controller */
extern int buf_in;
extern int buf_out;
extern int buf_in_usr;
extern int buf_out_usr;
extern pthread_mutex_t *lock_cli;

#define TOT_SUPPORTED_GRPS 16
#define MAX_CNTLGROUPS 16
int tot_grps=0;

void  find_next_redundant(CONTROLLER_TUPLE *client)
{
	CONTROLLER_TUPLE *next=NULL,*tmp;
	next=client->current;
	if(next == NULL)
	{
		client->current=client->next;
	}
	else
	{
		client->current=next->next;
	}
	tmp=client->current;
	client->operation=CONTROLLER_NONE;
	return ;
}
void manage_controller_connection_aux(CONTROLLER_TUPLE *clientHead)
{
	int new_fd = 0,i=0;
	//struct sockaddr_in *sinp;
	CONTROLLER_TUPLE *client=clientHead;
	int prio=-1;
	CONTROLLER_TUPLE **aux=client->aux_clients;

	client->thread_started=1;

	while(1)
	{
		pthread_mutex_lock(&clientHead->ctrl_lock);
		if(strlen(clientHead->groupname) == 0 || clientHead->tot_aux_connections ==0 || clientHead->used == 0 )
		{
			clientHead->thread_started=0;
			pthread_mutex_unlock(&clientHead->ctrl_lock);
			pthread_exit(NULL);
		}
		if(clientHead->activity_bitmap  == -1 )
		{
			pthread_mutex_unlock(&clientHead->ctrl_lock);
			usleep(500);
			continue;
		}
		if(aux[i] == NULL ) goto end;
		if( aux[i]->fd > 0 ) goto end;


		client = aux[i];
		client->activity_bitmap=-1;
		//sinp = (struct sockaddr_in*) mkSock4Addr2(client->ip, client->port);
		//new_fd=tcp4Connect(sinp);
		new_fd = nl_socket_tcp4client_connect2(client->ip, client->port);
		//printf("conneted aux:%d %x %x tot:%d used:%d head:%p\n",new_fd,client->ip,client->port,clientHead->tot_aux_connections,clientHead->used,clientHead);
		if(new_fd > 0)
			ofc_init_new_controller(client, new_fd);
		else
		{
			updateStatus(client, DISCONNECTED);
			updateRole  (client, OFPCR_ROLE_EQUAL);
			updateReason(client, CONNECT_FAILED);
		}
end:
		pthread_mutex_unlock(&clientHead->ctrl_lock);
		i=(i+1)%(MAX_AUX_CTRLS -1);
		sleep(1);
	}
}
#define TAP_DEV_NAME "tap0"
int addRoute(unsigned int ip_addr,short int port)
{
	// For in band we should add route like : route add -host 10.0.0.1 dev tap0
	char routeCmd[128];
	memset(routeCmd,0x0,sizeof(routeCmd));
	ip_addr=ntohl(ip_addr);
	snprintf(routeCmd, sizeof(routeCmd), "route add -host %s dev %s",inet_ntoa(*((struct in_addr *)&ip_addr)),TAP_DEV_NAME);
//	printf("route Cmd is :%s\n",routeCmd);
	system(routeCmd);
}

void manage_controller_connection(CONTROLLER_TUPLE *clientHead)
{
	int new_fd = 0;

	CONTROLLER_TUPLE *client=clientHead;

	while(1)
	{
		if(strlen(clientHead->groupname) == 0 ) { pthread_exit(NULL) ; }
		pthread_mutex_lock(&clientHead->ctrl_lock);
		if(client && client->fd > 0 )
		{
			pthread_mutex_unlock(&clientHead->ctrl_lock);
			usleep(500);
			continue;
		}

		find_next_redundant(clientHead);
		client = clientHead->current;
		if(client == NULL)
		{
			pthread_mutex_unlock(&clientHead->ctrl_lock);
			continue;
		}
		client->activity_bitmap=-1;

		new_fd = nl_socket_tcp4client_connect2(client->ip, client->port);

		if(new_fd > 0)
		{
			int ret=ofc_init_new_controller(client, new_fd);
			if(ret == -1 )
			{
				pthread_mutex_unlock(&clientHead->ctrl_lock);
				sleep(1);
				continue;
			}
			uint64_t dummy = 1;
			write(event_fd, &dummy, sizeof(dummy));
			if(clientHead->thread_started == 0)
			{
				//printf("Starting thread for aux connection");
				pthread_create (&client->connection_thread, NULL,
						(void *) manage_controller_connection_aux, client);
				/* Detach the thread so it's ressources are frees once it returns. */
				pthread_detach(client->connection_thread);
			}
		}
		else
		{
			updateStatus(client, DISCONNECTED);
			updateRole  (client, OFPCR_ROLE_EQUAL);
			updateReason(client, CONNECT_FAILED);
			client->used=0;
		}
		pthread_mutex_unlock(&clientHead->ctrl_lock);
		sleep(1);
	}
}
int ofc_aux_add_controller(unsigned int ip_addr,unsigned short port,short int role,char prio,char mode,char *grpname,char *ctrlname,uint32_t con_id,char *profileName,int inband)
{
	int ret=ERR_CONTROLLER_NOT_FOUND, index=-1,i;
	CONTROLLER_TUPLE *client=NULL;

	NOVI_SECURITY_PROFILE **prof=NULL;
	if(mode == NOVI_PROTOCOL_TLS && profileName) 
	{
		ret=get_sec_profile(profileName,&prof);
		if(prof == NULL || ret != 0 ) return ERR_SEC_PROFILE_NO_FOUND;
	}

	if (ip_addr == INADDR_NONE)
		return ERR_INVALID_IPV4;
	if(prio > MAX_AUX_CTRLS) {ret=ERR_BAD_CTRL_PRIO; goto Err;}

#if 1
	if(strlen(grpname) == 0 )
		return ERROR;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		client=controller_clients[i].current;
		if(client == NULL ) continue;
		if(strlen(client->groupname) == 0 )
			continue;


		if(strcmp(client->groupname,grpname) == 0  )
			index=i;

		// check if some duplicate things needs to be checked
	}
	if(index == -1) goto Err;

	CONTROLLER_TUPLE *tmp=controller_clients[index].next;
	client=NULL;
	while(tmp)
	{
		if(strcmp(tmp->controllername,ctrlname) == 0 )
		{
			client=tmp;
			break;
		}
		tmp=tmp->next;
	}
	if(client == NULL) goto Err;

	CONTROLLER_TUPLE **aux=client->aux_clients;
	/* Aux with same priority exists */
	if(aux[prio] && aux[prio]->is_aux) { ret=ERR_DUPLICATE_CTRL_PRIO;  goto Err ;}
	/* Check if Aux with same connection id exists */
	for(i=0;i<MAX_AUX_CTRLS;i++)
	{
		if(aux[i] && aux[i]->con_id == con_id ) {ret=ERR_DUPLICATE_CTRL_AUX;goto Err;}
	}
	if(aux[prio] == NULL )
	{
		aux[prio]=malloc(sizeof(CONTROLLER_TUPLE));
		memset(aux[prio],0x0,sizeof(CONTROLLER_TUPLE));
	}
	client->tot_aux_connections++;
	aux[prio]->head=&controller_clients[index];;
	aux[prio]->ip=ip_addr;
	aux[prio]->port=port;
	aux[prio]->role=role;
	aux[prio]->mode=mode;
	aux[prio]->prio=prio;
	aux[prio]->con_id=con_id;
	aux[prio]->is_aux=1;
	aux[prio]->aux_head=client;
	aux[prio]->role=client->role;
	aux[prio]->status=DISCONNECTED;
	snprintf(aux[prio]->controllername,(CTRL_NAME_LEN+1),"aux_%d",con_id);
	snprintf(aux[prio]->groupname, CTRL_NAME_LEN+1, "%s", grpname);
	aux[prio]->ofp_version = client->ofp_version;
	aux[prio]->version_bitmap = client->version_bitmap;
	aux[prio]->inband = inband;
	if(inband)
		addRoute(ip_addr,port);
	aux[prio]->security_profile = prof;
	if(prof && *prof && strlen((*prof)->name))
		snprintf(aux[prio]->profile_name, STRUCT_MEMBERSIZE(CONTROLLER_TUPLE, profile_name), "%s", (*prof)->name);
	sendAddControllerStatus(&aux[prio]);
	pthread_mutex_init(&(aux[prio]->ctrl_lock), NULL);
	if(client->tot_aux_connections == 1 && client->thread_started == 0)
	{
		//printf("Starting thread for aux connection");
		pthread_create (&client->connection_thread, NULL,
				(void *) manage_controller_connection_aux, client);
		/* Detach the thread so it's ressources are frees once it returns. */
		pthread_detach(client->connection_thread);
	}
#endif
	ret=0;
Err:
	return ret;

}

/* this function should only be called after reading the CLI conf file
 * to keep the ofchannel tables and the cli config data consistent
 */

int ofc_add_controller(unsigned int ip_addr,unsigned short port,short int role,char prio,char mode,char *grpname,char *ctrlname, int version,char *profileName, int inband)
{
	int i=0,ret=-1;

	ofchannel_print("Adding controller at %s:%u\n", novi_IpHexToStr(ip_addr), port);
	NOVI_SECURITY_PROFILE **prof=NULL;
	if(mode == NOVI_PROTOCOL_TLS && profileName) 
	{
		ret=get_sec_profile(profileName,&prof);
		if(prof == NULL || ret != 0 ) return ERR_SEC_PROFILE_NO_FOUND;
	}
	
	if (ip_addr == INADDR_NONE)
		return ERR_INVALID_IPV4;

	if(strlen(grpname) == 0 )
		return ERROR;

	// Don't accept 'all' as name because we need it in delete
	if((strcmp(grpname, "all") == 0) || (strcmp(ctrlname, "all") == 0))
	    return ERR_BAD_CTRL_GRP_NAME;

	//Check if controller already set up
	CONTROLLER_TUPLE *next=NULL;
	int grp_index=-1,last_index=-1;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(strlen(controller_clients[i].groupname) == 0  )
			continue;
		else
			last_index=i;
		if(strcmp(controller_clients[i].groupname,grpname) == 0 )
		{
			grp_index=i;
		}
		if(ip_addr !=0 && port != 0)
		{
			next=controller_clients[i].next;
			while( next != NULL)
			{
				if(next->ip == ip_addr && next->port == port)
				{
					return ERR_DUPLICATE_CTRL;
				}
				else if(strcmp(controller_clients[i].groupname,grpname) == 0 &&
					strcmp(next->controllername,ctrlname) == 0)
				{
					return ERR_DUPLICATE_CTRL_NAME;
				}

				next=next->next;
			}
		}
	}
	next=NULL;

	
	if(grp_index != -1)
		next=controller_clients[grp_index].next;

	 // For in band we should add route like : route add -host 10.0.0.1 dev tap0
	/* New Group needs to be added	at last_index+1 */
	if(next == NULL )
	{
		if((tot_grps ) >= MAX_CNTLGROUPS )
			return  ERR_MAX_CNTLGROUPS;
		memset(&controller_clients[last_index+1],0x0,sizeof(controller_clients[last_index+1]));
		ofc_async_set_default(&controller_clients[last_index+1]);
		snprintf(controller_clients[last_index+1].groupname, CTRL_NAME_LEN+1, "%s", grpname);
		
		if(ip_addr !=0 || port != 0)
		{
			next=malloc(sizeof(CONTROLLER_TUPLE));
			memset(next,0x0,sizeof(CONTROLLER_TUPLE));
			next->head = &controller_clients[last_index+1];
			controller_clients[last_index+1].next=next;
			controller_clients[last_index+1].operation=CONTROLLER_ADDED;
			next->ip = ip_addr;
			next->prio=prio;
			next->port=port;
			next->role=OFPCR_ROLE_EQUAL;
			next->status=DISCONNECTED;
			next->mode = mode;
			next->tot_aux_connections =0 ;
			next->activity_bitmap=-1;
			next->security_profile=prof;
			if(prof && *prof && (*prof)->errorCode == 0 && strlen((*prof)->name) > 0 )
			{
				snprintf(next->profile_name, STRUCT_MEMBERSIZE(CONTROLLER_TUPLE, profile_name), "%s", (*prof)->name);
				(*prof)->refcount++;
			}
			snprintf(next->controllername, CTRL_NAME_LEN+1, "%s", ctrlname);
			snprintf(next->groupname, CTRL_NAME_LEN+1, "%s", grpname);
			next->ofp_version = version;
			if (next->ofp_version!=CONTROLLER_VERSION_IS_ANY)
				next->version_bitmap = 1 << next->ofp_version;
			else
				next->version_bitmap = OFP_VERSION_BITMAP;
			next->inband=inband;
			if(inband == 1)
				addRoute(ip_addr,port);

			pthread_mutex_init(&(next->ctrl_lock), NULL);
			snprintf(controller_clients[last_index+1].groupname, CTRL_NAME_LEN+1, "%s", grpname);
			sendAddControllerStatus(next);
			tot_grps++;
			//printf("startign thread for %s %d\n",controller_clients[last_index+1].groupname ,last_index+1);
			pthread_create (&controller_clients[last_index+1].connection_thread, NULL,
			                (void *) manage_controller_connection, &controller_clients[last_index+1]);
			pthread_detach(&controller_clients[last_index+1].connection_thread);
		}
	}
	// Add new node in sorted order
	else if(next != NULL && (ip_addr != 0 || port != 0))
	{
		CONTROLLER_TUPLE *tmp=next,*new=NULL,*prev,*cur=next;
		controller_clients[grp_index].operation=CONTROLLER_ADDED;
		next=new=malloc(sizeof(CONTROLLER_TUPLE));
		memset(new,0x0,sizeof(CONTROLLER_TUPLE));
		next->head = &controller_clients[grp_index];
		snprintf(new->controllername, CTRL_NAME_LEN+1, "%s", ctrlname);
		snprintf(new->groupname, CTRL_NAME_LEN+1, "%s", grpname);
		new->ip=ip_addr;
		new->port=port;
		new->prio=prio;
		new->role=OFPCR_ROLE_EQUAL;
		new->status=DISCONNECTED;
		new->mode = mode;
		new->tot_aux_connections =0 ;
		new->activity_bitmap=-1;
		new->security_profile=prof;

		if(prof && *prof && strlen((*prof)->name))
		{
			snprintf(next->profile_name, STRUCT_MEMBERSIZE(CONTROLLER_TUPLE, profile_name), "%s", (*prof)->name);
			(*prof)->refcount++;
		}
		new->ofp_version = version;
		new->inband=inband;
		if(inband == 1)
			addRoute(ip_addr,port);
		
		if (new->ofp_version!=CONTROLLER_VERSION_IS_ANY)
			new->version_bitmap = 1 << new->ofp_version;
		else
			new->version_bitmap = OFP_VERSION_BITMAP;
		sendAddControllerStatus(new);
		pthread_mutex_init(&(new->ctrl_lock), NULL);
		snprintf(controller_clients[grp_index].groupname, CTRL_NAME_LEN+1, "%s", grpname);		// first node
		if(tmp->prio > prio)
		{
			new->next=tmp;
			tmp->prev=new;
			new->prev=NULL;
			controller_clients[grp_index].next=new;
			controller_clients_num++;
			if (controller_clients_num > MAX_CLIENTS) controller_clients_num = MAX_CLIENTS;
			return OK;
		}

		while(tmp != NULL && prio > tmp->prio )
		{

			cur=tmp;
			tmp=tmp->next;
			// insert after cur
			if(tmp && tmp->prio > prio )
			{

				new->next=cur->next;
				new->prev=cur;
				cur->next=new;

				break;
			}
			//last
			else if (tmp == NULL)
			{
				cur->next=new;
				new->prev=cur;
				new->next=NULL;
				break;
			}
		}
		if(tmp && tmp->prio == prio ) return ERR_DUPLICATE_CTRL_PRIO;
	}
	controller_clients_num++;
	if (controller_clients_num > MAX_CLIENTS) controller_clients_num = MAX_CLIENTS;
	return OK;
}

int sendControllerStatus(CONTROLLER_TUPLE *node,int action_status,int reason)
{
	struct ofl_controller_status*  status;
	struct ofl_msg_multipart_reply_controller_status  controller_status_msg;

	controller_status_msg.header.header.type = OFPT_MULTIPART_REPLY;
	controller_status_msg.header.header.version = OFP15_VERSION;
	controller_status_msg.header.type = OFPMP_CONTROLLER_STATUS;
	controller_status_msg.header.flags = 0; //TODO: Add 'More' flag as parameter of this function.
	controller_status_msg.controller = malloc(sizeof(struct ofl_controller_status));
	status = controller_status_msg.controller;
	memset(status,0x0,sizeof(struct ofl_controller_status));
	status->length=sizeof(struct ofl_controller_status);
	status->short_id=node->short_id;
	status->role=node->role;
	status->reason=reason;
	status->channel_status=action_status;
	status->properties_num=1;
	status->properties = (struct ofl_controller_status_prop_header **)malloc(status->properties_num * sizeof(struct ofl_controller_status_prop_header  *));
	struct ofl_controller_status_prop_uri *uri = (struct ofl_controller_status_prop_uri *)malloc(sizeof(struct ofl_controller_status_prop_uri));
	status->properties[0]=uri;
	uri->type=OFPCSPT_URI;
	uri->uri = (char *)malloc(64);
	memset(uri->uri,0x0,64);
	if(node->mode == NOVI_PROTOCOL_TLS) 
		snprintf(uri->uri, 64, "%s:%s:%d","tls",novi_IpHexToStr(node->ip),node->port);
	else
		snprintf(uri->uri, 64, "%s:%s:%d","tcp",novi_IpHexToStr(node->ip),node->port);
	int i=0;
	CONTROLLER_TUPLE *client=NULL;
	uint8_t *msg_send = NULL;
	size_t msg_len = 0;
	int ret = ofl_msg_pack((struct ofl_msg_header *) &controller_status_msg, 0, &msg_send, &msg_len, NULL);
	if (ret != 0) return 0;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		client=controller_clients[i].current;
		if(client && client != node && client->ofp_version >= OFP15_VERSION && client->status == CONNECTED)
			ofc_write(client,msg_send,msg_len);
	}
	free(uri->uri);
	free(uri);
	free(status->properties);
	free(controller_status_msg.controller);
	free(msg_send);
}
int sendAddControllerStatus(CONTROLLER_TUPLE *node)
{
	sendControllerStatus(node,OFPCT_STATUS_UP,OFPCSR_CONTROLLER_ADDED);

}

int sendDelControllerStatus(CONTROLLER_TUPLE *del)
{
	sendControllerStatus(del,OFPCT_STATUS_DOWN,OFPCSR_CONTROLLER_REMOVED);
}

int ofc_aux_delete_controller(unsigned int ip_addr,unsigned short port,short int role,char prio,char mode,char *grpname,char *ctrlname,unsigned int con_id)
{

	int ret = ERR_CONTROLLER_NOT_FOUND,foundCTRL=0;
	int i=0,index=-1;
	CONTROLLER_TUPLE *del=NULL,*next=NULL,*tmp=NULL,*prev=NULL,*client;
	bool delete_all_aux = (con_id == 0xFFFFFFFF);

	ofchannel_print("Deleting controller at %s:%u in %s:%s:%d\n", novi_IpHexToStr(ip_addr), port, grpname, ctrlname, con_id);
	for(i=0;i<MAX_CLIENTS;i++)
	{
		client=controller_clients[i].current;
		if(client == NULL ) continue;
		if(strlen(client->groupname) == 0 )
			continue;

		if(strcmp(client->groupname,grpname) == 0  )
		{
			index=i;
			break;
		}
		// check if some duplicate things needs to be checked
	}
	if(index == -1) goto Err;

	tmp=controller_clients[index].next;
	client=NULL;
	while(tmp)
	{
		if(strcmp(tmp->controllername,ctrlname) == 0 )
		{
			del=client=tmp;
			sendDelControllerStatus(del);
			break;
		}
		tmp=tmp->next;
	}
	if(client == NULL) goto Err;

	CONTROLLER_TUPLE **aux=client->aux_clients;
	if(aux[prio] && aux[prio]->is_aux) { ret=ERR_DUPLICATE_CTRL_AUX ;  goto Err ;}
	for(i=0;i<MAX_AUX_CTRLS;i++)
	{
		if(aux[i] && (aux[i]->con_id == con_id || delete_all_aux))
		{
			tmp=aux[i];
			aux[i]=NULL;
			pthread_mutex_destroy(&tmp->ctrl_lock);
			ofc_close_controller(tmp);
			if(tmp && tmp->security_profile && *(tmp->security_profile) && tmp->mode == NOVI_PROTOCOL_TLS ) 
				(*(tmp->security_profile))->refcount--;
			sendDelControllerStatus(tmp);
			del->tot_aux_connections--;
			free(tmp);
			ret=OK;

			/* If deletion of 1 AUX is requested, stop deletion process. Otherwise, keep deleting others AUX */
			if(!delete_all_aux)
				goto Err;
		}
	}

Err:
	return ret;
}
int ofc_delete_controller(unsigned int *ip_addr,unsigned short *port,short int role,char prio,char mode,char *grpname,char *ctrlname)
{

	int ret = ERR_CONTROLLER_NOT_FOUND,foundCTRL=0;
	int i=0;

#define ACT_NONE 0
#define DEL_GRP 1
#define DEL_CTRL_ABS 2
#define DEL_CTRL 3
	int action=ACT_NONE;
	ofchannel_print("Deleting controller at %s:%u in %s:%s\n", novi_IpHexToStr(*ip_addr), *port, grpname, ctrlname);

//  if(ctrlname != NULL || grpname != NULL) return ERROR;

	if(strlen(ctrlname) == 0 || strlen(grpname) ==0 ) goto Err;
	else if(strlen(ctrlname) ==0 && strlen(grpname) != 0 ) action=DEL_GRP;
	else if(strlen(ctrlname) !=0  ) action=DEL_CTRL;
	else { action= ACT_NONE; goto Err;}

	CONTROLLER_TUPLE *del=NULL,*next=NULL,*tmp=NULL,*prev=NULL;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(strlen(controller_clients[i].groupname) == 0  ) continue;
		if(strcmp(controller_clients[i].groupname,grpname) == 0)
		{
			controller_clients[i].operation=CONTROLLER_DEL;
			prev=next=tmp=controller_clients[i].next;
			if(action == DEL_GRP)
			{
				memset(&controller_clients[i],0x0,sizeof(CONTROLLER_TUPLE));
				ret=0;goto Err;
			}
			while(next != NULL)
			{
				tmp=next;
				if(action == DEL_CTRL && strcmp(tmp->controllername,ctrlname) == 0)
				{
					if(tmp->status == CONNECTED && tmp->fd > 0) {ofc_close_controller(tmp); }

					if(tmp->security_profile && *(tmp->security_profile) && tmp->mode == NOVI_PROTOCOL_TLS)
						(*(tmp->security_profile))->refcount--;

					sendDelControllerStatus(tmp);

					/* in the begining and the single */
					if(controller_clients[i].next == next && next->next == NULL )
					{
						/* We are also deleting the grp if no node is within*/
						*ip_addr=next->ip;*port=next->port;
						memset(&controller_clients[i],0x0,sizeof(CONTROLLER_TUPLE));
						tot_grps--;
					}
					else if(controller_clients[i].next == next && next->next != NULL )
					{
						controller_clients[i].next =next->next;
						((CONTROLLER_TUPLE *)(next->next))->prev=NULL;
					}
					/* if node is in the middle */
					else if(next->next)
					{
						((CONTROLLER_TUPLE *)next->next)->prev=next->prev;
						((CONTROLLER_TUPLE *)next->prev)->next=((CONTROLLER_TUPLE *)next->next);
					}
					/* If it is last node */
					else if(next->next == NULL)
					{
						prev=next->prev;
						prev->next=NULL;
					}
					del=tmp;
					pthread_mutex_destroy(&(del->ctrl_lock));
					if(del)
					{   CONTROLLER_TUPLE *next_aux, *aux;
						aux = del->aux_head ;
						while(aux != NULL){
							next_aux = aux->next;
							if(aux->security_profile && *(aux->security_profile) && aux->mode == NOVI_PROTOCOL_TLS)
								(*(aux->security_profile))->refcount--;
							sendDelControllerStatus(aux);
							free(aux);
							aux = next_aux;
						}
						/*
						 * Disable free, causing a Memory leak
						 * to avoid crash caused by race condition here
						 */
						//free(del);del=NULL;
					}
					ret=0;goto Err;
				}
				prev=next;
				next=next->next;
			}
		}

		/* Store it in Mongo DB now */
	}
Err:
	return ret;
}
int ofc_update_xml(enum NETCONF_COMMANDS cmd, void* structure, int size)
{
	int ret=0;
	static __thread int ofconfig_fd=-1;
	if(ofconfig_fd < 0){
		ofconfig_fd=nl_unix_connect(SOCK_SEQPACKET,NOVI_NETCONF_SERVER_SOCK);
		if(ofconfig_fd <= 0) goto Err;
	}
	ret=send_xml_request(&ofconfig_fd,cmd,0,structure,size);
	if(ret <0) goto Err;

	return ret;
Err:
	close(ofconfig_fd);
	ofconfig_fd=-1;
	return ret;
}
int process_add_ctrl(enum ofc_cmd_src src, struct ConfigController* config)
{

	if(config->mode > NOVI_PROTOCOL_TCP)
		return ERROR;
	if(strcmp(config->profile_name,"none") == 0)
		config->mode=NOVI_PROTOCOL_TCP;
	else 
		config->mode=NOVI_PROTOCOL_TLS;

	int ret=ofc_add_controller(config->ip,config->port,config->role,config->prio,config->mode,config->ctrlgrpname,config->ctrlname, config->version,config->profile_name, config->inband);
	if(ret !=OK) return ret;
	config->status = 0;

	if (src != OFC_CMD_NOVI)
	{
		ofc_update_xml(NETCONF_ENGINE_ADD_CONTROLLER, config, sizeof(struct ConfigController));
	}
	return ofc_save_config(CONFIG_CONTROLLER,config,sizeof(struct ConfigController));

}
int process_aux_add_ctrl(enum ofc_cmd_src src, struct ConfigController* config)
{
	if(config->mode > NOVI_PROTOCOL_TCP)
		return ERROR;
	if(strcmp(config->profile_name,"none") == 0)
		config->mode=NOVI_PROTOCOL_TCP;
	else 
		config->mode=NOVI_PROTOCOL_TLS;

	int ret = ofc_aux_add_controller(config->ip,config->port,config->role,config->prio,config->mode,config->ctrlgrpname,config->ctrlname,config->aux_con_id,config->profile_name, config->inband);
	if (ret != OK) return ret;

	if (src != OFC_CMD_NOVI)
	{
		ofc_update_xml(NETCONF_ENGINE_ADD_CONTROLLER, config, sizeof(struct ConfigController));
	}
	return 0;
}


/*-----------------------------------------------------------------*/
/* Functions related to set/get echo variable */
int process_get_echo(char **outbuff,int *outbuff_len)
{
	*outbuff = malloc(sizeof(unsigned char));
	*outbuff_len = sizeof(unsigned char);
	*outbuff[0] = (uint8_t)set_get_echo_flag(OFC_GET_ECHO,0);
	return OK;
}
int process_set_echo(int echo_timer)
{
	set_get_echo_flag(OFC_SET_ECHO,echo_timer);
	ofchannel_print("set the echo time %d\n", echo_timer);
	return OK;
}


/* As of now it is only static variable, but will move to storeload config data */

int set_get_echo_flag (int flag, time_t val)
{

	/* Initializing with 15 sec default value */
	static unsigned int echo_interval=DEFAULT_ECHO_VALUE;

	if (OFC_GET_ECHO == flag)
	{
		return echo_interval;
	}
	if(OFC_SET_ECHO== flag)
	{
		echo_interval = val;
		return OK;
	}
	return ERROR;
}
/*
 * Sends an update to noviengine about new controller
 * connection status/role.
 * In turn, noviengine will update the ofconfig xml from this info.
 */
void ofc_ofconfig_controller_update(CONTROLLER_TUPLE* client)
{
	struct ConfigController config;
	memset(&config, 0x00, sizeof(config));

	memcpy(&config.ctrlgrpname, client->groupname, sizeof(config.ctrlgrpname));
	memcpy(&config.ctrlname, client->controllername, sizeof(config.ctrlname));
	config.aux_con_id = client->con_id;
	config.status = client->status;
	config.version = client->ofp_version;
	config.role = client->role;

	ofc_update_xml(NETCONF_ENGINE_MOD_CONTROLLER, &config, sizeof(struct ConfigController));
}
int process_aux_rem_ctrl(enum ofc_cmd_src src, struct ConfigController *config)
{
	int ret = ofc_aux_delete_controller(config->ip,config->port,config->role, config->prio, config->mode, config->ctrlgrpname, config->ctrlname,config->aux_con_id);
	if (ret != OK) return ret;

	if (src != OFC_CMD_NOVI)
	{
		ofc_update_xml(NETCONF_ENGINE_DEL_CONTROLLER, config, sizeof(struct ConfigController));
	}
	return 0;
}
int process_rem_ctrl(enum ofc_cmd_src src, struct ConfigController *config)
{
	int ret = 0;
	CONTROLLER_TUPLE *clientHeadNode=NULL;

	if (src != OFC_CMD_NOVI)
	{
		int i;
		CONTROLLER_TUPLE *controller = NULL;
		for(i=0;i<MAX_CLIENTS;i++)
		{
			if(strlen(controller_clients[i].groupname) == 0  )
				continue;

			if((strcmp(controller_clients[i].groupname,config->ctrlgrpname) == 0) ||
			   (strcmp(config->ctrlgrpname, "all") == 0))
			{
				clientHeadNode=&controller_clients[i];
				controller = controller_clients[i].next;
				while(controller != NULL)
				{
					if((strcmp(controller->controllername,config->ctrlname) == 0) ||
					   (strcmp(config->ctrlname, "all") == 0))
					{
						if(controller->aux_clients != NULL)
						{
							struct ConfigController config_aux;
							memcpy(&config_aux, config, sizeof(struct ConfigController));
							snprintf(config_aux.ctrlgrpname, CTRL_NAME_LEN+1, "%s", controller->groupname);
							snprintf(config_aux.ctrlname, CTRL_NAME_LEN+1, "%s", controller->controllername);
							CONTROLLER_TUPLE *aux;
							int j;
							for(j=0; j<MAX_AUX_CTRLS; j++)
							{
								aux = controller->aux_clients[j];
								if(aux == NULL)
									continue;
								config_aux.aux_con_id = aux->con_id;
								config_aux.ip = aux->ip;
								config_aux.port = aux->port;
								config_aux.role = aux->role;
								config_aux.prio = aux->prio;
								config_aux.mode = aux->mode;
								ofchannel_print("process_rem_ctrl - Send DEL CONTROLLER to netconf for group: %s, ctrl: %s, auxid: %d\n",
								                controller->groupname, controller->controllername, aux->con_id);
								ofc_update_xml(NETCONF_ENGINE_DEL_CONTROLLER, &config_aux, sizeof(struct ConfigController));
							}
						}
						pthread_mutex_lock(&clientHeadNode->ctrl_lock);
						ret = ofc_delete_controller(&config->ip,&config->port,config->role, config->prio, config->mode, controller->groupname, controller->controllername);
						pthread_mutex_unlock(&clientHeadNode->ctrl_lock);
						if(ret != OK)
							return ret;

						/* Use REAL group & controller name */
						ofchannel_print("process_rem_ctrl - Send DEL CONTROLLER to netconf for group: %s ctrl: %s\n",
						                controller->groupname, controller->controllername);
						struct ConfigController config_tmp;
						memcpy(&config_tmp, config, sizeof(struct ConfigController));
						snprintf(config_tmp.ctrlgrpname, CTRL_NAME_LEN+1, "%s", controller->groupname);
						snprintf(config_tmp.ctrlname, CTRL_NAME_LEN+1, "%s", controller->controllername);
			            ofc_update_xml(NETCONF_ENGINE_DEL_CONTROLLER, &config_tmp, sizeof(struct ConfigController));
			            if(OK != (ret = ofc_del_config(CONFIG_CONTROLLER, &config_tmp, sizeof(struct ConfigController))))
			                return ret;
					}
					controller = controller->next;
				}
			}
		}
		return ret;
	}
	else
	{
        if( OK != (ret = ofc_delete_controller(&config->ip,&config->port,config->role, config->prio, config->mode, config->ctrlgrpname, config->ctrlname)))
            return ret;
        return ofc_del_config(CONFIG_CONTROLLER,config,sizeof(struct ConfigController));
	}
}


int process_get_tcp_buf(char **outbuff,int *outbuff_len)
{
	struct ShowConfigSwitchDeviceTcpBuff *tcpbuff = NULL;
	tcpbuff=malloc(sizeof(struct ShowConfigSwitchDeviceTcpBuff));
	memset(tcpbuff, 0x00, sizeof(struct ShowConfigSwitchDeviceTcpBuff));
	tcpbuff->in=buf_in;
	tcpbuff->out=buf_out;
	tcpbuff->in_usr=buf_in_usr;
	tcpbuff->out_usr=buf_out_usr;
	*outbuff_len=sizeof(struct ShowConfigSwitchDeviceTcpBuff);
	*outbuff=(char*)tcpbuff;
	return 0;
}
int process_set_tcp_buff(int type,uint8_t *buff,int len)
{

	int buf_in1,buf_out1;

	int ret=ERROR;
	int i=0;
	CONTROLLER_TUPLE *next=NULL;
	if(len < 8) return -1;
	memcpy(&buf_in1,buff,sizeof(buf_in1));
	memcpy(&buf_out1,buff+sizeof(buf_in1),sizeof(buf_out1));

	/*
	 * Set user desired tcpbuffers values here.
	 * We will try to apply them to actual and future controllers.
	 * If we fail to apply them, global variables buf_out and buf_in
	 * will be set to the current default value.
	 */
	if (buf_out1 != 0)
		buf_out_usr=buf_out1;
	if (buf_in1 != 0)
		buf_in_usr=buf_in1;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(controller_clients[i].next == NULL ) continue;
		next=controller_clients[i].next;
		while(next)
		{
			ret=set_tcp_buff(next->fd,buf_in_usr,buf_out_usr);
			if(ret != 0 ) return ret;
			next=next->next;
		}
	}
	return OK;
}
long dbg_port=-1;
pthread_t dbg_thread;
static int started=0;
#define MAX_DBG_CLI 10
int dbg_fd[MAX_DBG_CLI];
struct ConfigOfclient ofclients_array[MAX_OFCLIENTS]={{0}};
CONTROLLER_TUPLE* ofclients_connected_array[MAX_DBG_CLI]={NULL};
int removeDbgFd(CONTROLLER_TUPLE *client)
{
	int i=0;
	for(i=0;i<MAX_DBG_CLI;i++)
	{
		if(dbg_fd[i] == client->fd)
		{
			dbg_fd[i]=0; 
			remove_client_from_ofclientcontroller_list(client);
			return 0;
		}
	}
	return 0;
}
int addDbgFd(int fd)
{
	int i=0;
	for(i=0;i<MAX_DBG_CLI;i++)
	{
		if(dbg_fd[i] == 0) {dbg_fd[i]=fd; return 0;}
	}
	return 1;
}
int allow_query(struct sockaddr_in *sin)
{
	int i=0;
	for(i=0;i<MAX_OFCLIENTS;i++)
	{
		if(ofclients_array[i].ipaddr == 0 ) continue;
		if(sin->sin_addr.s_addr == ntohl(ofclients_array[i].ipaddr)  && (ofclients_array[i].port == 0 || htons(sin->sin_port) == (ofclients_array[i].port)) ) return 1;
	}
	return 0;
}

int ofclient_exists_in_ofclientcontroller_list(int address)
{
	int i = 0;
	for(i=0;i<MAX_DBG_CLI;i++)
	{
		if(ofclients_connected_array[i] && (ofclients_connected_array[i]->ip==address))
		{
			return i;
		}
	}
	return -1;
}

int add_to_ofclientcontroller_list(CONTROLLER_TUPLE* client)
{
	int i = 0;
	for(i=0;i<MAX_DBG_CLI;i++)
	{
		if(ofclients_connected_array[i] == NULL)
		{
			ofclients_connected_array[i] = client;
			return 1;
		}
	}	
	return 0;
}
int remove_client_from_ofclientcontroller_list(CONTROLLER_TUPLE* client)
{
	int i = 0;
	for(i=0;i<MAX_DBG_CLI;i++)
	{
		if(ofclients_connected_array[i]&&(ofclients_connected_array[i] == client))
		{
			ofclients_connected_array[i] = NULL;
			return 1;
		}
	}
	return 0;	
}
int manage_dbg_server(void *data)
{
	fd_set rfds;
	int i=0,maxfd=0,ret=-1;
	struct timeval timeout;
	int serFd,socklen=0,fd=0;
	struct sockaddr_in sin;
	serFd=nl_socket_tcp4server_create(0,(short)dbg_port);
	if(serFd <= 0) goto End;
	memset(dbg_fd,0x0,sizeof(dbg_fd));
	while(1)
	{
		if(dbg_port <= 0)
		{
			for(i=0;i<MAX_DBG_CLI;i++)
			{
				if(dbg_fd[i])
				{
					close(dbg_fd[i]);
					dbg_fd[i]=0;
				}
			}
			close(serFd);
			serFd=0;
			pthread_exit(NULL);
		}
		timeout.tv_sec = 0;
		timeout.tv_usec = 2000;
		FD_ZERO(&rfds);
		FD_SET(serFd, &rfds);
		if(maxfd < serFd) maxfd=serFd;

		for(i=0;i<MAX_DBG_CLI;i++)
		{
			if(dbg_fd[i])
			{
				FD_SET(dbg_fd[i],&rfds);
			}
			if(maxfd <= dbg_fd[i]) maxfd=dbg_fd[i];
		}
		errno = 0;
		ret = select(maxfd + 1, &rfds, NULL, NULL, &timeout);
		if (ret <= 0 || errno == EINTR)
		{
			continue;
		}

		if ( serFd > 0 &&
				FD_ISSET(serFd, &rfds))
		{

			socklen = sizeof(sin);
			memset(&sin,0x0,sizeof(sin));
			fd = nl_socket_tcp4_accept_addr(serFd,&sin);
			if (fd < 0) {
				continue;
			}
			int allow=allow_query(&sin);
			if(allow)
			{
				addDbgFd(fd);
			}
			else
			{
				close(fd);
			}
			continue;

		}
		for(i=0;i<MAX_DBG_CLI;i++)
		{
			if(dbg_fd[i] && FD_ISSET(dbg_fd[i],&rfds))
			{
				CONTROLLER_TUPLE *client= NULL;
				int index = -1;
				// verify whether this client existe or not
				unsigned int address = htonl(sin.sin_addr.s_addr);
				index= ofclient_exists_in_ofclientcontroller_list(address);
				if(index == -1)
				{
					client=malloc(sizeof(CONTROLLER_TUPLE));
					memset(client,0x0,sizeof(CONTROLLER_TUPLE));
					client->mode=NOVI_PROTOCOL_TCP;
					client->fd=dbg_fd[i];
					client->private_data=&(dbg_fd[i]);
					client->res=1;
					client->version_bitmap = OFP_VERSION_BITMAP;
					client->ofp_version = (OFP13_VERSION);
					client->ip = address;
				}
				else
				{
					client = ofclients_connected_array[index];
				}
				ret=handle_controller_openflow(client);
				// for the new allocated client, add to the ofclients_connected_array
				if(index == -1)
				{
					add_to_ofclientcontroller_list(client);
				}
			}
		}

	}
	ret=0;
End:
	started=0;
	return ret;
}
int process_show_config_ofclient(char **out,int *out_len)
{
	*out = malloc(sizeof(ofclients_array));
	if (*out == NULL) return ERROR;
	memcpy(*out, ofclients_array, sizeof(ofclients_array));
	*out_len = sizeof(ofclients_array);
	return OK;
}
int process_stop_ofserver_thread(char** out, int *out_len)
{
	if(started == 0 ) return ERR_DEBG_THREAD_NOT_RUNNING;
	/* Send the list of all ofclients to cliengine to clean iptables rules */
	if (process_show_config_ofclient(out, out_len) != OK) return ERROR;

	memset(ofclients_array, 0x00, sizeof(ofclients_array));
	dbg_port=0;
	started=0;
	return OK;
}

int  process_start_ofserver_thread(struct ConfigOfserver *config)
{
	if(started == 1 ) return ERR_DEBG_THREAD_EXISTS;
	started=1;
	dbg_port=config->port;
	pthread_create(&dbg_thread	,NULL , (void*) manage_dbg_server ,NULL);
	return OK;
}
/* returns the index of an instance of an ofclient in the array 
 * useful for both add/delete to verify if the entry exists */
static int ofclient_exists(struct ConfigOfclient* config)
{
	int i = 0;
	for(i=0;i<MAX_OFCLIENTS;i++)
	{
		if(ofclients_array[i].ipaddr == config->ipaddr  && 
			( config->port == ofclients_array[i].port ) )
			return i;
	}
	return -1;
}

/* Removes the ofclient from array. If successfull, returns the ID of the client to cliengine */
int process_del_config_ofclient(struct ConfigOfclient *config,int len,char **out,int *out_len)
{
	int ret= ERR_REMOTE_TUPLE_NOT_EXISTS;
	config->id = -1;
	int index = ofclient_exists(config);
	if (index >=0)
	{
		config->id=ofclients_array[index].id;
		memset(&ofclients_array[index],0x0,sizeof(struct ConfigOfclient));
		ret = OK;
	}
	*out=malloc(sizeof(struct ConfigOfclient));
	memcpy(*out, config, sizeof(struct ConfigOfclient));
	*out_len=sizeof(struct ConfigOfclient);
	return ret;
}
/* Adds the ofclient to array. If successfull, returns the ID of the client to cliengine */
int process_set_config_ofclient(struct ConfigOfclient *config,int len,char **out,int *out_len)
{
	int i=0;
	int ret= ERR_REMOTE_MAX_TUPLES;
	config->id = -1;
	if(started != 1 ){ ret = ERR_DEBG_THREAD_NOT_RUNNING; goto Err;}

	int index = ofclient_exists(config);
	if (index >= 0){ret=ERR_REMOTE_DUPLICATE_TUPLE; goto Err;}

	for(i=0;i<MAX_OFCLIENTS;i++)
	{
		if(ofclients_array[i].ipaddr == 0)
		{
			config->id = i;
			memcpy(&ofclients_array[i],config,sizeof(struct ConfigOfclient));
			ret = OK;
			break;
		}
	}
Err:
	*out=malloc(sizeof(struct ConfigOfclient));
	memcpy(*out, config, sizeof(struct ConfigOfclient));
	*out_len=sizeof(struct ConfigOfclient);
	return ret;
}

int process_load_tcp_buff(int type,uint8_t *buff,int len)
{
	int tmp_in = 0, tmp_out = 0;
	if(len < 8) return -1;
	memcpy(&tmp_in,buff,sizeof(tmp_in));
	memcpy(&tmp_out,buff+sizeof(tmp_in),sizeof(tmp_out));
	if (tmp_in > 0) buf_in_usr = tmp_in;
	if (tmp_out > 0) buf_out_usr = tmp_out;
	return OK;
}
int process_ctrl_ip(char *buff, char **outbuff, int *outbuff_len)
{
	int ret=OK;
	int i,j=1,count=0;
	CONTROLLER_TUPLE *next=NULL;
	struct ConfigPacketcapture *captureIps=NULL;
	// to make code simple allocating size of 1024 ports

	captureIps=malloc(sizeof(struct ConfigPacketcapture));
		

	/* Retrieve the total amount of controllers in the various linked list */
	for(i=0;i<sizeof(controller_clients)/sizeof(CONTROLLER_TUPLE);i++)
	{
		if(strlen(controller_clients[i].groupname) == 0 ) continue;
		next=controller_clients[i].next;
		do
		{
			if(strlen(next->controllername) == 0 )
				continue;
			captureIps->controller_ip[i]=next->ip;
			count++;

			j++;
			next=next->next;
		}while(next);
	}
	captureIps->controller_count=count;
	*outbuff=captureIps;
	*outbuff_len=sizeof(struct ConfigPacketcapture);
	ret=OK;
Err:
	novi_errno =ret;
	return ret;
}


int process_ctrl_ports(char *buff, char **outbuff, int *outbuff_len)
{
	int ret=OK;
	int *ports=NULL,i,j=1,count=0;
	CONTROLLER_TUPLE *next=NULL;
#define MAX_PORTS 1024
	// to make code simple allocating size of 1024 ports
	ports=malloc(sizeof(int)*(1+MAX_PORTS));
	memset(ports,0x0,(1+MAX_PORTS)*sizeof(int));


	/* Retrieve the total amount of controllers in the various linked list */
	for(i=0;i<sizeof(controller_clients)/sizeof(CONTROLLER_TUPLE);i++)
	{
		if(strlen(controller_clients[i].groupname) == 0 ) continue;
		next=controller_clients[i].next;
		do
		{
			if(strlen(next->controllername) == 0 )
				continue;
			ports[j]=next->port;
			count++;

			j++;
			next=next->next;
		}while(next);
	}
	ports[0]=count;
	*outbuff=ports;
	*outbuff_len=(count + 1)*sizeof(int);
	ret=OK;
Err:
	novi_errno =ret;
	return ret;
}

int process_show_ctrl(char *buff, char **outbuff, int *outbuff_len)
{
	int ret=ERROR;
	int length = 0, count = 0;
	int i = 0;
	CONTROLLER_TUPLE *next=NULL;
	CONTROLLER_TUPLE *serialized=NULL;
	char *controllergroup = "";
	char *controllername = "";
	int nb_args=0;
	bool is_ctrl_all = false;
	bool is_ctrlgrp_all = false;

	struct ConfigController *config = (struct ConfigController *) buff;
	if (config != NULL)
	{
		if (strlen(config->ctrlgrpname)>0)
		{
			nb_args++;
			controllergroup = config->ctrlgrpname;
			/* Controller name can only exist as part of a controller group */
			if (strlen(config->ctrlname)>0)
			{
				nb_args++;
				controllername = config->ctrlname;
			}
		}
	}

	/* If this check passes, we can assume the number of argument is valid */
	if(nb_args!=0 && nb_args!=1 && nb_args != 2)
		goto Err;

	if (strcmp(controllername, "all") == 0)
	{
		is_ctrl_all = true;
	}

	if (strcmp(controllergroup, "all") == 0)
	{
		is_ctrlgrp_all = true;
	}

	/* Retrieve the total amount of controllers in the various linked list */
	for(i=0;i<sizeof(controller_clients)/sizeof(CONTROLLER_TUPLE);i++)
	{
		if(strlen(controller_clients[i].groupname) == 0 ) continue;
		if(nb_args!=0 && strcmp(controller_clients[i].groupname,controllergroup) != 0 && !is_ctrlgrp_all ) continue;
		next=controller_clients[i].next;
		if (next == NULL ) continue;
		do
		{
			if(nb_args != 2)
			{
				count++;
				count+=next->tot_aux_connections;
			}
			else //nb_args == 2
			{
				if((strcmp(next->controllername,controllername) == 0) || is_ctrl_all)
				{
					count++;
					count+=next->tot_aux_connections;
				}
			}

			next=next->next;
		}while(next);
	}
	if (count <= 0){ret=OK;goto Err;}

	int ctl_cnt=count;
	length=sizeof(CONTROLLER_TUPLE)*count;
	serialized = malloc(length);
	if(serialized == NULL)
	{
		ret = NO_MEM;
		goto Err;
	}
	memset(serialized, 0x00, length);
	count=0;

	/* Add all controllers to an array in a sequential manner */
	for(i=0;i<sizeof(controller_clients)/sizeof(CONTROLLER_TUPLE);i++)
	{
		if(strlen(controller_clients[i].groupname) == 0 ) continue;
		if(nb_args!=0 && strcmp(controller_clients[i].groupname,controllergroup) != 0  && !is_ctrlgrp_all ) continue;
		next=controller_clients[i].next;
		if( next == NULL ) continue;
		int role = controller_clients[i].role,i;
		do
		{
			if(nb_args != 2)
			{
				// protecting from buffer overflow
				if(count >= ctl_cnt) { goto Err;} 
				memcpy(&serialized[count],next,sizeof(CONTROLLER_TUPLE));
				serialized[count].role = role;
				count++;
				int tot_aux=next->tot_aux_connections;
				CONTROLLER_TUPLE *tmp_cl,**tpl=next->aux_clients;
				for(i=0;i<MAX_AUX_CTRLS;i++)
				{
					if(tpl[i] == NULL)
						continue;
					if(tpl[i]->is_aux)
					{
						// protecting from buffer overflow
						if(count >= ctl_cnt) { goto Err;} 
						memcpy(&serialized[count],tpl[i],sizeof(CONTROLLER_TUPLE));
						count++;
					}
				}
			}
			else //nb_args ==2
			{
				if((strcmp(next->controllername,controllername) == 0) || is_ctrl_all)
				{
					memcpy(&serialized[count],next,sizeof(CONTROLLER_TUPLE));
					serialized[count].role = role;
					count++;
					int tot_aux=next->tot_aux_connections;
					CONTROLLER_TUPLE *tmp_cl,**tpl=next->aux_clients;
					for(i=0;i<MAX_AUX_CTRLS;i++)
					{
						if(tpl[i] == NULL)
							continue;
						if(tpl[i]->is_aux)
						{
							memcpy(&serialized[count],tpl[i],sizeof(CONTROLLER_TUPLE));
							count++;
						}
					}
				}
			}

			next=next->next;
		}while(next);
	}

	*outbuff = (char*) serialized;
	*outbuff_len = length;
	ret=OK;
Err:
	novi_errno =ret;
	return ret;
}

int process_command(enum ofc_cmd_src src, TLV *tlv,int len,char **outbuff,int *outbuff_len)
{
	int ret = ERROR;
	*outbuff = NULL;
	*outbuff_len = 0;

	if(tlv == NULL ) goto Err;

	/* Buffer len is encoded right after the TLV header, before the buffer */
	int *buff_len = NULL;
	uint8_t *buff = NULL;
	if (tlv->len > sizeof(TLV))
	{
		buff_len = (int*) ((uint8_t*) tlv + sizeof(TLV));
		if (*buff_len >= 0) buff = (uint8_t*) tlv + sizeof(TLV) + sizeof(int);
	}

	ofchannel_print("Received command type %d len:%d\n", tlv->val_bitmap,buff_len);
	switch (tlv->val_bitmap)
	{
		case OFC_CLOSE_CTRLS:
			pthread_mutex_lock(lock_cli);
			ret=ofc_close_all_controllers();
			pthread_mutex_unlock(lock_cli);
			break;
		case OFC_CTRL_PORTS:
			ret=process_ctrl_ports((char *)buff, outbuff, outbuff_len);
			break;
		case OFC_CTRL_IP:
			ret=process_ctrl_ip((char *)buff, outbuff, outbuff_len);
			break;
		case OFC_SHOW_CTRL:
			pthread_mutex_lock(lock_cli);
			ret=process_show_ctrl((char *)buff, outbuff, outbuff_len);
			pthread_mutex_unlock(lock_cli);
			break;
		case OFC_SHOW_AUX_CTRL:
			ret=process_show_ctrl((char *)buff, outbuff, outbuff_len);
			break;
		case OFC_SEC_PROFILE_ADD:
			ret=create_profile((char*)buff,sizeof(struct ConfigSecurity));
			break;
		case OFC_DEL_SECURITY_PROFILE:
			ret=delSecurityProfile((char*)buff);
			break;

		case OFC_GET_SECURITY_PROFILE:
			ret=getSecurityProfiles(outbuff,outbuff_len);
			break;
		case OFC_ADD_CTRL:
			pthread_mutex_lock(lock_cli);
			ret = process_add_ctrl(src, (struct ConfigController *) buff);
			pthread_mutex_unlock(lock_cli);
			break;
		case OFC_REM_AUX_CTRL:
			pthread_mutex_lock(lock_cli);
			ret = process_aux_rem_ctrl(src, (struct ConfigController *) buff);
			pthread_mutex_unlock(lock_cli);
			break;
		case OFC_ADD_AUX_CTRL:
			pthread_mutex_lock(lock_cli);
			ret = process_aux_add_ctrl(src, (struct ConfigController *) buff);
			pthread_mutex_unlock(lock_cli);
			break;
		case OFC_REM_CTRL:
			pthread_mutex_lock(lock_cli);
			ret = process_rem_ctrl(src, (struct ConfigController *) buff);
			pthread_mutex_unlock(lock_cli);
			break;

		case OFC_SET_ECHO:{
			int echo=0;
			memcpy(&echo,buff,sizeof(int));
			ret = process_set_echo(echo);
			}
			break;
		case OFC_GET_ECHO:
			ret = process_get_echo(outbuff, outbuff_len);
			break;
		case OFC_SET_OFL_MSG:
			set_ofl_msg();
			ret = OK;
			break;
		case OFC_UNSET_OFL_MSG:
			unset_ofl_msg();
			ret = OK;
			break;
		case OFC_SET_OFL_ERR:
			set_ofl_err();
			ret = OK;
			break;
		case OFC_UNSET_OFL_ERR:
			unset_ofl_err();
			ret = OK;
			break;
		case OFC_SET_TRACES:
			set_trace(LOG_OFC);
			ret = OK;
			break;
		case OFC_UNSET_TRACES:
			unset_trace();
			ret = OK;
			break;
		case OFC_UNSET_ALL:
			disable_all_logs();
			ret = OK;
			break;
		case OFC_SET_TCP_BUFF:
			ret=process_set_tcp_buff(tlv->type,buff,len-sizeof(TLV));
			break;
		case OFC_GET_TCP_BUFF:
			ret=process_get_tcp_buf(outbuff,outbuff_len);
			break;
		case OFC_LOAD_TCP_BUFF:
			ret=process_load_tcp_buff(tlv->type,buff,len-sizeof(TLV));
			break;
		case OFC_ADD_OFSERVER:

			ret = process_start_ofserver_thread( (struct ConfigOfserver*) buff );
			break;
		case OFC_DEL_OFSERVER:
			ret = process_stop_ofserver_thread(outbuff,outbuff_len);
			break;
		case OFC_ADD_OFCLIENT:
			ret=process_set_config_ofclient((struct ConfigOfclient*) buff,len-sizeof(TLV), outbuff,outbuff_len);
			break;
		case OFC_DEL_OFCLIENT:
			ret=process_del_config_ofclient((struct ConfigOfclient*) buff,len-sizeof(TLV),outbuff,outbuff_len);
			break;
		case OFC_SHOW_OFCLIENT:
			ret=process_show_config_ofclient(outbuff,outbuff_len);
			break;
		default:
			ret = ERROR;
			break;
	}
Err:
	return ret;
}
