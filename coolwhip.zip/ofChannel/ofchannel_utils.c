#include "ofChannel.h"
#include "ofchannel_utils.h"
#include "ofchannel_role.h"
#include "cliLib.h"
#include "c_config.h"
#include "nl_lib_socket.h"
#include "openflow.h"
#include "novi_utils.h"
#include "ofl.h"
#include "noviIBSCommon.h"
#include <netinet/tcp.h>
#include <pthread.h>

#include <dirent.h> 
#include <stdio.h> 
#ifdef NOVI_TLS
#	include <openssl/bio.h>
#	include <openssl/ssl.h>
#	include <openssl/err.h>
#	include <openssl/pem.h>
#	include <openssl/x509.h>
#	include <openssl/x509_vfy.h>
#endif

#ifdef NOVI_TLS
BIO              *certbio;
BIO               *outbio;
X509                *cert;
X509_NAME       *certname;
const SSL_METHOD *method;
SSL_CTX *ctx;
#endif

static int profile_index=0;
NOVI_SECURITY_PROFILE **controller_sec_profiles=NULL;
/* these values should be loaded from DB at the start up */
int buf_in=TCP_MEM_DEFAULT,buf_out=TCP_MEM_DEFAULT;
int buf_in_usr=TCP_MEM_DEFAULT,buf_out_usr=TCP_MEM_DEFAULT;
#ifdef NOVI_TLS
static int pem_passwd_cb(char *buf, int size, int rwflag, void *userdata)
{
#define NOVI_TLS_PASS "novipass"
   if (rwflag) {}
   strncpy(buf, NOVI_TLS_PASS, size);
   buf[size - 1] = '\0';
   return (strlen(buf));
}
#endif

int getNextAux(CONTROLLER_TUPLE *client,int *index,void **out)
{
	int i=0;
	CONTROLLER_TUPLE **tpl=client->aux_clients;

	if(client->tot_aux_connections <= 0) goto Err;

	for(i=(*index);i<MAX_AUX_CTRLS;i++)
	{
		if(tpl[i] == NULL) continue;
		*out=tpl[i];
		(*index)=i+1;
		return 0;

	}
Err:
	*out=NULL;
	return -1;
}
void ofc_close_controller(CONTROLLER_TUPLE *client)
{
	CONTROLLER_TUPLE *h=client;
	void *free_ptr=NULL;
	int index=0;

	pthread_mutex_lock(&h->ctrl_lock);
	do
	{
		/* TO-DO: should remove the client from slave/equal/master table */
		updateStatus(client, DISCONNECTED);
		updateRole(client, OFPCR_ROLE_EQUAL);
		updateRole(client, OFPCR_ROLE_EQUAL);
		if (client->fd > 0)
		{
			/* Only update active controller versions if this one has been active before. */
			if (client->ofp_version != 0)
				ofc_ctrl_version_ref_dec(client->ofp_version);
			close(client->fd);
			client->fd=0;
			remove_all_trans(client);
			if(client->res)
			{
				/* If controller is an ifclient only */
				removeDbgFd(client);
				free_ptr=client;
			}
			if(client->private_data ) *((int*)client->private_data)=0;
			sendControllerStatus(client,OFPCT_STATUS_DOWN,OFPCSR_CHANNEL_STATUS);
			NOVI_SECURITY_PROFILE **security_profile=client->security_profile,*sprofile=NULL;
			if(client->mode == NOVI_PROTOCOL_TLS && security_profile && *(security_profile))
			{
				if(client->ssl)
				{
					ofchannel_print("TLS shutdown\n");
					SSL_shutdown(client->ssl);
				}
			}
		}

		client->used=0;
		getNextAux(h,&index,&client);
		if(free_ptr){free(free_ptr);free_ptr=NULL;}
		if(client == NULL ) break;
	}while(1);
	pthread_mutex_unlock(&h->ctrl_lock);
}

void list_aux(CONTROLLER_TUPLE *client)
{
	CONTROLLER_TUPLE *c;
	int index=0;
	do
	{
	getNextAux(client,&index,&c);
	if(c == NULL) break;
	}while(1);
}
int  ofc_init_new_controller(CONTROLLER_TUPLE *client, int fd)
{
	CONTROLLER_TUPLE *h=client;
	int index=0;
	struct sockaddr_in *sinp;
	int version_bitmap = 0;
	NOVI_SECURITY_PROFILE **security_profile=client->security_profile,*sprofile=NULL;
#ifdef NOVI_TLS
		// ofchannel_print("mode = %d ptr :%p ptr:%p\n",client->mode,security_profile , *security_profile);
		if(client->mode == NOVI_PROTOCOL_TLS && security_profile && *(security_profile))
		{
			int ret=-1,r=0;
			sprofile=*security_profile;
			client->ssl=SSL_new(sprofile->ctx);
			ofchannel_print("Context:%p sprofile:%p new ssl:%p\n",sprofile->ctx,sprofile,client->ssl);
			if(client->ssl == NULL) {
				close(fd); fd=0;
				return -1;
			}
			SSL_set_fd(client->ssl, fd);
			ret=SSL_connect(client->ssl);
			if ( ret != 1 )
			{
				BIO_printf(sprofile->outbio, "Error: Could not build a SSL session to\n");
				r=SSL_get_error(client->ssl,ret);
				ofchannel_print("SSL_get_error:%d\n",r);
				ERR_print_errors(sprofile->outbio);
				close(fd);
				fd=0;
				return -1;
			} else {
				BIO_printf(sprofile->outbio, "Successfully enabled SSL/TLS session to:\n");
			}
		}
#endif
		struct ofp_hello *hello = NULL;
		struct ofp_hello_elem_versionbitmap *vbmp = NULL;
		int len = 0;

		len = sizeof(struct ofp_hello) + sizeof(struct ofp_hello_elem_versionbitmap) + sizeof(uint32_t);
		hello = malloc(len);
		if (hello == NULL) return -1;
		memset(hello, 0x00, len);
		if(client->version_bitmap & (1<<OFP15_VERSION)){
			hello->header.version = OFP15_VERSION;
		}
		else
		if (client->version_bitmap & (1<<OFP14_VERSION)){
			hello->header.version = OFP14_VERSION;
		}
		else {
			hello->header.version = OFP13_VERSION;

		}
		hello->header.type    = OFPT_HELLO;
		hello->header.length  = htons(len);
		hello->header.xid     = htonl(rand());

		vbmp = (struct ofp_hello_elem_versionbitmap *)&hello->elements[0];
		vbmp->type = htons(OFPHET_VERSIONBITMAP);
		vbmp->length = htons(sizeof(*vbmp) + sizeof(uint32_t));
		vbmp->bitmaps[0] = htonl(client->version_bitmap);

		client->rcvd_bitmap = -1;
		client->not_rcvd = -1;
		client->sent_bitmap = -1;
		client->activity_bitmap = -1;
		client->status = CONNECTED ;
		client->fd=fd;
		char flag = 1;
		setsockopt(client->fd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(int));
		client->used=1;

		nl_socket_tcp_linger_set(client->fd);

		/* set Tcp buffers to every connection */
		set_tcp_buff(client->fd,buf_in_usr,buf_out_usr);
		ofc_write(client, hello, len);
		free(hello);

		CONTROLLER_TUPLE *head = client->head;
		if (head != NULL)
		{
			if (head->role == OFPCR_ROLE_MASTER)
				makeMeMaster(client);
			else if (head->role == OFPCR_ROLE_SLAVE)
				makeMeSlave(client);
			else
				makeMeEqual(client);
		}

		struct in_addr ip_addr;
		ip_addr.s_addr = htonl(client->ip);
		ofchannel_print("Connected to controller %s:%d\n", inet_ntoa(ip_addr), client->port);
#if 0
back:
		getNextAux(h,&index,&client);
		if(client == NULL ) break;
		else
		{
			client->activity_bitmap=-1;
			sinp = (struct sockaddr_in*) mkSock4Addr2(client->ip, client->port);
			fd=tcp4Connect(sinp);
			free(sinp);
			//	printf("ip:%x port:%d fd:%d\n",client->ip,client->port,fd);
			if(fd<= 0)
			{

				updateStatus(client, DISCONNECTED);
				updateRole  (client, OFPCR_ROLE_EQUAL);
				updateReason(client, CONNECT_FAILED);
				goto back;
			}
		}
#endif
	return 0;
}
void initOfcSecurityProfiles()
{
	profile_index=0;
	controller_sec_profiles=malloc(MAX_CLIENTS * sizeof(void *));
	memset(controller_sec_profiles,0x0,MAX_CLIENTS * sizeof(void *));
	
	/* creating default tls profile */
	struct ConfigSecurity *profile=malloc(sizeof(struct ConfigSecurity));
	memset(profile,0x0,sizeof(struct ConfigSecurity));
	snprintf(profile->profile_name, SECURITY_NAME_LEN, "%s", "tls");
	snprintf(profile->profile_type, SECURITY_NAME_LEN, "%s", "tls");
	snprintf(profile->tarFilePath, FILE_PATH_MAX, "%s", NOVI_CERT_DEFAULT_PATH);
	int ret=create_profile(profile);
	if( ret != 0 ) ofchannel_print("unable to create default profile\n");
}
int get_sec_profile(char *profileName,NOVI_SECURITY_PROFILE  ***outProfile)
{
	ofchannel_print("profile name to search :%s\n",profileName);
	int i=0;
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(controller_sec_profiles[i] && strcmp(profileName,controller_sec_profiles[i]->name) == 0)
		{
			*outProfile=(controller_sec_profiles+i);	
			ofchannel_print("searched :%p\n",*outProfile);
			return 0;
		}
	}
	*outProfile=NULL;
	return -1;
} 
init_ssl()
{
	OpenSSL_add_all_algorithms();
	ERR_load_BIO_strings();
	ERR_load_crypto_strings();
	SSL_load_error_strings();
	if(SSL_library_init() < 0)
		ofchannel_print( "Could not initialize the OpenSSL library !\n");

}
int add_sec_profile(struct ConfigSecurity *profile_info)
{
	int ret=ERR_LOAD_CERT;
	NOVI_SECURITY_PROFILE *profile =NULL;
	DIR           *d=NULL;
	struct dirent *dir=NULL;
	if(profile_info == NULL ) return -1;

	if(strcmp(profile_info->profile_type,"tls") != 0) 
	{
		ret=ERR_BAD_SEC_PROFILE;
		goto Err;
	}

	profile = malloc(sizeof(NOVI_SECURITY_PROFILE));
	memset(profile,0x0,sizeof(NOVI_SECURITY_PROFILE));
	snprintf(profile->name, STRUCT_MEMBERSIZE(NOVI_SECURITY_PROFILE, name), "%s", profile_info->profile_name);
	snprintf(profile->certificate_tar, STRUCT_MEMBERSIZE(NOVI_SECURITY_PROFILE, certificate_tar), "%s", profile_info->tarFilePath);
	profile->errorCode=-1;

#ifdef NOVI_TLS
	profile->certbio = NULL;
	profile->outbio = NULL;
	profile->cert = NULL;
	profile->certname = NULL;

	profile->certbio = BIO_new(BIO_s_file());
	profile->outbio  = BIO_new(BIO_s_file());
	profile->outbio  = BIO_new_fp(stdout, BIO_NOCLOSE);
	int ssl_ret=0;
	profile->method = SSLv23_client_method();
	if ( (profile->ctx = SSL_CTX_new(profile->method)) == NULL)
		BIO_printf(profile->outbio, "Unable to create a new SSL context structure.\n");
	SSL_CTX_set_default_passwd_cb(profile->ctx,pem_passwd_cb);
	SSL_CTX_set_default_passwd_cb_userdata(profile->ctx, (void *)NULL);
#define SSL_OP_NO_TLSv1_1				0x10000000L
#define SSL_OP_NO_TLSv1_2				0x08000000L

	SSL_CTX_set_options(profile->ctx,  SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3);
	char cert_file[128];
	memset(cert_file,0x0,sizeof(cert_file));


	snprintf(cert_file,sizeof(cert_file),"%s/%s",profile_info->tarFilePath,NOVI_SEC_PRIVATE_PEM);
	ssl_ret=0;
	if(access(cert_file,F_OK) == 0 )
	{
		ssl_ret=SSL_CTX_use_PrivateKey_file(profile->ctx,cert_file,SSL_FILETYPE_PEM);
		if(ssl_ret != 1) 
		{ 
			BIO_printf(profile->outbio,"Failed in use private Ky file :%s\n",cert_file); 
			SSL_get_error(NULL,ssl_ret);
			ofchannel_print("SSL_get_error:%d\n",ssl_ret);
			ERR_print_errors(profile->outbio);
			ret=ERR_LOAD_CERT;
			goto Err;
		}
		else	
		{ 
			ofchannel_print("Private Key File loaded :%s\n",cert_file);
			profile->keyFile=1;
		}
	}

	memset(cert_file,0x0,sizeof(cert_file));
	snprintf(cert_file, sizeof(cert_file),"%s/%s",profile_info->tarFilePath,NOVI_SEC_PUBLIC_PEM);

	ssl_ret=0;
	if(access(cert_file,F_OK) == 0 )
	{
		ssl_ret=SSL_CTX_use_certificate_chain_file(profile->ctx,cert_file);
		if(ssl_ret != 1) 
		{ 
			BIO_printf(outbio,"Failed in Loading Certificate :%s\n",cert_file); 
			SSL_get_error(NULL,ssl_ret);
			ofchannel_print("SSL_get_error:%d\n",ssl_ret);
			ERR_print_errors(profile->outbio);
			ret=ERR_LOAD_CERT;
			goto Err;

		}
		profile->certFile=1;
		ofchannel_print("Certificate Loaded Sucessfully .. %s \n",cert_file);
	}

	else 
	{
		ofchannel_print("%s doesnt exists\n",cert_file);
		ret=ERR_CERT_NOT_FOUND;
		goto Err;
	}
	// profile_info->tarFilePath will contain 0.pem 1.pem etc..
	memset(cert_file,0x0,sizeof(cert_file));
	snprintf(cert_file,sizeof(cert_file),"%s/CA/",profile_info->tarFilePath);
	ofchannel_print("cert_file:%s\n",cert_file);
	d = opendir(cert_file);
	if (d)
	{
		while ((dir = readdir(d)) != NULL)
		{
			ofchannel_print("processing %s\n", dir->d_name);
			if (dir->d_type == DT_REG && strcmp(dir->d_name+strlen(dir->d_name) - 4,".pem") == 0)
			{
				memset(cert_file,0x0,sizeof(cert_file));
				snprintf(cert_file,sizeof(cert_file),"%s/CA/%s",profile_info->tarFilePath,dir->d_name);
				ofchannel_print("loading %s\n", cert_file);
				ssl_ret=SSL_CTX_use_certificate_chain_file(profile->ctx,cert_file);
				if(ssl_ret != 1) 
				{ 
					BIO_printf(outbio,"Failed in CA Loading Certificate :%s \n",cert_file); 
					SSL_get_error(NULL,ssl_ret);
					ofchannel_print("SSL_get_error:%d\n",ssl_ret);
					ERR_print_errors(profile->outbio);
					ret=ERR_LOAD_CHAIN_CERT;
					goto Err;
				}
				else ofchannel_print("CA Certificate Loaded Sucessfully .. %s \n",cert_file);
			}
		}

	}	
	controller_sec_profiles[profile_index]=profile;
	profile_index++;
	
	ret=0;
Err:
	if(d)
		closedir(d);
	if (profile)
		profile->errorCode=ret;
	return ret;
#endif
}
int create_profile(struct ConfigSecurity *profile)
{
	NOVI_SECURITY_PROFILE **prof=NULL;
	int ret=-1;
	if(strlen(profile->profile_name)) ret=get_sec_profile(profile->profile_name,&prof);
	else return ERR_BAD_SEC_PROFILE; 
	/* it shouldnt exists */
	if( ret == 0 || prof != NULL) return ERR_PROFILE_DUPLICATE; 
	return add_sec_profile(profile);
}

int ofc_plain_write(int socket, void *buff, int size)
{
	return nl_socket_write(socket,buff,size);
}

int ofc_write(CONTROLLER_TUPLE *client, void* buff, int size)
{
	int ret = 0;
	NOVI_SECURITY_PROFILE **security_profile=client->security_profile;
	if (client == NULL || client->fd < 0)
		return -1;
#ifdef NOVI_TLS
	if(client->mode == NOVI_PROTOCOL_TLS && security_profile && *(security_profile))
	{
		if( !client->ssl ) {
			ret = -1;
			ofchannel_print("NOVISSL_ERROR: SSL_write on uninitialized secure socket.\n");
		} else {
			ret = SSL_write(client->ssl, buff, size);
			ofchannel_print("SSL_write on %p\n",client->ssl);
		}
	}
	else {
		ret = ofc_plain_write(client->fd, buff, size);
	}
#else
	ret = ofc_plain_write(client->fd, buff, size);
#endif
	if (ret < 0)
	{
		ofc_close_controller(client);
	}
	return ret;
}


int ofc_read(CONTROLLER_TUPLE *client, void *buff, int size)
{
	int length = 0;
	NOVI_SECURITY_PROFILE **security_profile=client->security_profile;
#ifdef NOVI_TLS
	if(client->mode == NOVI_PROTOCOL_TLS && security_profile && *(security_profile)) {
		length=SSL_read(client->ssl,buff,size);
	} else {
		length=nl_socket_read(client->fd,buff,size, 1);
	}
#else
	length=nl_socket_read(client->fd,buff,size, 1);
#endif
	return length;
}

void updateTuple(CONTROLLER_TUPLE *client, int action,unsigned char val)
{
	if(client == NULL ) return ;
	if(action == ROLE)
		client->role=val;
	if(action == CTRL_STATUS)
		client->status=val;
	if(action == REASON)
		client->reason=val;
}
void updateStatus(CONTROLLER_TUPLE *client, unsigned char status)
{
	unsigned char old_status = client->status;
	updateTuple(client, CTRL_STATUS,status);
	if (old_status != status)
	{
		if (status == DISCONNECTED)
		{
			struct in_addr ip_addr;
			ip_addr.s_addr = htonl(client->ip);
			ofchannel_print("Disconnected from controller %s:%d\n", inet_ntoa(ip_addr), client->port);
		}

		ofc_ofconfig_controller_update(client);
	}
}

void updateReason(CONTROLLER_TUPLE *client, unsigned char reason) { updateTuple(client, REASON,reason); }
void updateRole(CONTROLLER_TUPLE *client, unsigned char role)
{
	unsigned char old_role = client->role;
	updateTuple(client->head, ROLE,role);
	if (old_role != role)
		ofc_ofconfig_controller_update(client);
}


signed char ofChannel_sendErrorToController(CONTROLLER_TUPLE *client, ofl_err error, struct ofp_header *message)
{
	uint8_t* outbuf=calloc(1,sizeof(struct ofl_msg_error));
	uint32_t size;
	int status = -1;
	char *type = NULL, *code = NULL;

	struct ofl_msg_error err =
	{
		{
			.version = message->version,
			.type = OFPT_ERROR
		},
		.type = ofl_error_type(error),
		.code = ofl_error_code(error),
		.data_length = ntohs(message->length),
		.data        = (uint8_t*) message,
	};

	error = ofl_msg_pack((struct ofl_msg_header*)&err,  ntohl(message->xid) , &outbuf, (size_t*) &size, NULL);
	if (error) goto Err;

	type = ofl_error_type_to_string(ofl_error_type(error));
	code = ofl_error_code_to_string(ofl_error_type(error), ofl_error_code(error));
	novi_ofl_errmsg("Error type: %s, code: %s, xid: 0x%"PRIx32"\n", type, code, ntohl(message->xid));

	ofc_write(client, outbuf, size);
	status = 0;
Err:
	free(outbuf);
	free(type);
	free(code);
	return status;
}

void ofc_log_msg(struct ofp_header* oh, const char* direction_str)
{
	char *type = NULL, *subtype = NULL;
	type = ofl_message_type_to_string(oh->type);
	switch(oh->type)
	{
		case OFPT_FLOW_MOD:
		{
			struct ofp_flow_mod *msg = (struct ofp_flow_mod *) oh;
			subtype = ofl_flow_mod_command_to_string(msg->command);
			break;
		}
		case OFPT_GROUP_MOD:
		{
			struct ofp_group_mod *msg = (struct ofp_group_mod *) oh;
			subtype = ofl_group_type_to_string(msg->type);
			break;
		}
		case OFPT_MULTIPART_REQUEST:
		{
			struct ofp_multipart_request *msg = (struct ofp_multipart_request *) oh;
			subtype = ofl_stats_type_to_string(ntohs(msg->type));
			break;
		}
		case OFPT_MULTIPART_REPLY:
		{
			struct ofp_multipart_reply *msg = (struct ofp_multipart_request *) oh;
			subtype = ofl_stats_type_to_string(ntohs(msg->type));
			break;
		}
		case OFPT_METER_MOD:
		{
			struct ofp_meter_mod *msg = (struct ofp_meter_mod *) oh;
			subtype = ofl_meter_mod_command_to_string(ntohs(msg->command));
			break;
		}
		default:
			break;
	}




	if (subtype != NULL)
	{
		novi_ofl_msg("%s: %s - %s, xid: 0x%"PRIx32" (%u bytes)\n", direction_str, type, subtype, ntohl(oh->xid), ntohs(oh->length));
	}
	else
	{
		novi_ofl_msg("%s: %s, xid: 0x%"PRIx32" (%u bytes)\n", direction_str, type, ntohl(oh->xid), ntohs(oh->length));
	}
	free(type);
	free(subtype);
}

/*
 * This function will apply provided tcpbuffer configuration
 * If the provided configurations fails to be applied,
 * It will apply the default one.
 *
 * Important global variables:
 *   buf_out_usr: This variable is untouched, it represents the desired value from user.
 *   buf_in_usr: This variable is untouched, it represents the desired value from user.
 *   buf_out: After a call to this function it will be equal to current running tcpbuffersout value
 *   buf_in: After a call to this function it will be equal to current running tcpbuffersout value
 *
 * Parameters:
 *  int fd: socket on which to apply the tcpbuffers configurations
 *  int sz: tcpbuffersin config to apply, typically should be buf_in_usr
 *  int outbuf_sz: tcpbuffersout config to apply, typically should be buf_out_usr
 */
int set_tcp_buff(int fd,int sz,int outbuf_sz)
{
	int ret=0,ret1=0;
	if(outbuf_sz)
		ret=set_snd_tcp_buf(fd,outbuf_sz);
	if(sz)
		ret1=set_rcv_tcp_buf(fd,sz);
	if(ret !=0 && ret1 != 0 ) ret = ERR_INVALID_SND_RCVBUF;
	else ret= ret | ret1;
	return ret;
}
int set_snd_tcp_buf(int fd,unsigned int sendbuff)
{
	int ret=0;
	if(fd <= 0)
		return 0;
	ret=setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sendbuff, sizeof(sendbuff));
	if(ret == 0 )
		buf_out=sendbuff;
	else
		buf_out = TCP_MEM_DEFAULT;
	return ret;
}
int set_rcv_tcp_buf(int fd,unsigned int rcvbuff)
{
	int ret=0;
	if(fd <= 0)
		return 0;
	ret=setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuff, sizeof(rcvbuff));
	if(ret == 0)
		buf_in=rcvbuff;
	else
		buf_in = TCP_MEM_DEFAULT;
	return ret;
}


int ofc_ctrl_version_ref_inc(enum ofp_version version)
{
	int ret = 0;
	struct shmdata_list* reference = NULL;
	uint32_t ref_count = 0;
	ret = novicib_get_data(NoviCIB_Major_ofChannel, NoviCIB_Minor_ofChannel_Versions, &reference, version);
	if (ret == 0 && reference != NULL)
	{
		ref_count = *(uint32_t*) reference->data;
		novicib_free_data(reference);
	}
	ref_count++;
	novicib_put_data(NoviCIB_Major_ofChannel, NoviCIB_Minor_ofChannel_Versions, &ref_count, sizeof(ref_count), version);
	return 0;
}
int ofc_ctrl_version_ref_dec(enum ofp_version version)
{
	int ret = 0;
	struct shmdata_list* reference = NULL;
	uint32_t ref_count = 0;
	ret = novicib_get_data(NoviCIB_Major_ofChannel, NoviCIB_Minor_ofChannel_Versions, &reference, version);
	if (ret == 0 && reference != NULL)
	{
		ref_count = *(uint32_t*) reference->data;
		novicib_free_data(reference);
	}
	if (ref_count > 0) ref_count--;

	novicib_put_data(NoviCIB_Major_ofChannel, NoviCIB_Minor_ofChannel_Versions, &ref_count, sizeof(ref_count), version);
	return 0;
}


int delSecurityProfile(char *profName)
{
	int i=0;
	char *ptr=NULL;
	if(strcmp(profName,"tls") == 0)
		return ERR_DEF_PROFILE;

	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(controller_sec_profiles[i] && strcmp(profName,controller_sec_profiles[i]->name) == 0 )
		{
			if(controller_sec_profiles[i]->refcount != 0) return ERR_PROFILE_REF_COUNT;
			ptr=controller_sec_profiles[i];
			free(ptr);
			controller_sec_profiles[i]=NULL;	
			profile_index--;
			return 0;
		}
	}
	return ERR_SEC_PROFILE_NO_FOUND;
}
int getSecurityProfiles(char **out,int *outlen)
{
	int i=0,j=0;
	NOVI_SECURITY_PROFILE *get_profile_ptr=NULL;
	*outlen=profile_index * sizeof(NOVI_SECURITY_PROFILE);
	*out=NULL;
	if(*outlen <= 0) return 0;
	*out=get_profile_ptr=malloc(*outlen);	
	memset(get_profile_ptr,0x0,*outlen);
	for(i=0;i<MAX_CLIENTS;i++)
	{
		if(controller_sec_profiles[i] && ((controller_sec_profiles[i]))->errorCode == 0)
		{
			memcpy(get_profile_ptr+j,controller_sec_profiles[i],sizeof(NOVI_SECURITY_PROFILE));
			j++;
		}	
	}
	return 0;
}


