#ifndef OFC_UTILS_H
#define OFC_UTILS_H

#include "ofl.h"

#ifdef NOVI_TLS
#	include <openssl/bio.h>
#	include <openssl/ssl.h>
#	include <openssl/err.h>
#	include <openssl/pem.h>
#	include <openssl/x509.h>
#	include <openssl/x509_vfy.h>
#endif

#include "c_config.h"

/* status */
#define DISCONNECTED 0x0
#define CONNECTED  0x1
#define NOT_CONNECTED 0x2

/* reason */
#define UNKOWN_REASON 0
#define ECHO_REPLIED_NOT_RECEIVD 0x1
#define CONNECT_FAILED 0x2

/* Direction of message (for logs) */
#define OUTGOING "Sent"
#define INCOMING "Received"

#define CONTROLLER_NONE 0
#define CONTROLLER_ADDED 1
#define CONTROLLER_DEL	2


#define MAX_BUNDLE  10
#define MAX_MESSAGE_PER_BUNDLE 5000
typedef struct
{
	int bid;
	int status;
	int error;
	int total_nodes;
	uint16_t flags;
	void *data;
	int data_len;
	void *next;
	int xid;
}BUNDLE_NODE;
typedef struct
{
	char name[32];
	char certificate_tar[128];	

	char certFile;
	char keyFile;
	char errorCode ; // errcode or sucesss as while creating profile we will load certificates
	char refcount;

	int ca_cert_bitmap;
#ifdef NOVI_TLS

	BIO              *certbio;
	BIO               *outbio;
	X509                *cert;
	X509_NAME       *certname;
	const SSL_METHOD *method;
	SSL_CTX *ctx;
#endif
}NOVI_SECURITY_PROFILE;
#define NOVI_SEC_PRIVATE_PEM "private_key.pem"
#define NOVI_SEC_PUBLIC_PEM "mycertificate.pem" 
typedef struct
{
	unsigned int ip;
	unsigned short port;  /* TCP port */
	unsigned char status; /* Connection state (disconnect/connected) */
	unsigned char role;   /* OpenFlow role master/equal/slave */
	unsigned char reason; /* Reason for last role/status change */
	unsigned char mode;   /* Protocol encryption (none or tls) */
	char profile_name[32];
	NOVI_SECURITY_PROFILE **security_profile;
	int fd;
	pthread_t connection_thread;
	int rcvd_bitmap;
	int not_rcvd;
	int sent_bitmap;
	int activity_bitmap;
	char res; /* Indicates (if set to 1) that controller is an "ofclient" (dpctl) */
	void *private_data; // data in case of spcecial cases
	int short_id;
#ifdef NOVI_TLS
	SSL *ssl;
#else
	void *padding;
#endif
	char groupname[CTRL_NAME_LEN+1];      /* Name of controller group this controller belongs to */
	char controllername[CTRL_NAME_LEN+1]; /* Id (name) of controller inside the group */
	char prio;        /* Priority of controller between its group members */
	char operation;
	void *next;       /* Pointer of next CONTROLLER_TUPLE in the group linked-list */
	void *prev;       /* Pointer of previous CONTROLLER_TUPLE in the group linked-list */
	void *current;    /* Pointer used by the head of the group to the active CONTROLLER_TUPLE in group */
	void *head;       /* Pointer to the head of the group (type CONTROLLER_TUPLE) */
	unsigned char  tot_aux_connections; /* Number of configured aux controllers */
	void *aux_head;
	unsigned char is_aux;               /* Boolean describing present CONTROLLER_TUPLE as aux entity or not */
	void *aux_clients[MAX_AUX_CTRLS];   /* Auxilary pointers of CONTROLLER_TUPLE type */
	pthread_mutex_t ctrl_lock;
	unsigned int con_id;                /* Auxiliary connection id */
	char used;
	char thread_started;
	void *bundle_heads[MAX_BUNDLE];

	char ofp_version; /* OpenFlow version currently used by controller */
	struct ofl_async_config async_config; /* OF 1.3 async config */
	size_t async_prop_count;              /* OF 1.4 async config */
	struct ofl_async_config_prop_header **async_props; /* OF 1.4 async config */
	int version_bitmap;
	int inband;
}CONTROLLER_TUPLE;

typedef struct
{
	uint32_t trans_id;
	int ref;
	CONTROLLER_TUPLE *client;
}OFC_TRANS_TABLE;


enum ofc_cmd_src
{
	OFC_CMD_CLI,
	OFC_CMD_NOVI,
};


#define TCP_MEM_DEFAULT (16*1024)


void ofc_close_controller(CONTROLLER_TUPLE *client);
int ofc_init_new_controller(CONTROLLER_TUPLE *client, int fd);
void ofc_ssl_init();
int ofc_write(CONTROLLER_TUPLE *client, void* buff, int size);
int ofc_read(CONTROLLER_TUPLE *client, void *buff, int size);

#define ROLE 1
#define CTRL_STATUS 2
#define REASON 3
void updateTuple(CONTROLLER_TUPLE *client, int action,unsigned char val);
void updateStatus(CONTROLLER_TUPLE *client, unsigned char status);
void updateReason(CONTROLLER_TUPLE *client, unsigned char reason);
void updateRole(CONTROLLER_TUPLE *client, unsigned char role);

int set_tcp_buff(int fd,int sz,int outbuf_sz);
int set_snd_tcp_buf(int fd,unsigned int sendbuff);
int set_rcv_tcp_buf(int fd,unsigned int rcvbuff);

signed char ofChannel_sendErrorToController(CONTROLLER_TUPLE *client, ofl_err error, struct ofp_header *message);

void ofc_log_msg(struct ofp_header* oh,const char* direction_str);

int ofc_ctrl_version_ref_inc(enum ofp_version version);
int ofc_ctrl_version_ref_dec(enum ofp_version version);

#endif /* OFC_UTILS_H */

