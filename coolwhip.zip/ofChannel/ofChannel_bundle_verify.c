#include "openflow.h"
#include <stdio.h>
#include <unistd.h>
#include "ofl.h"
#include "oxm-match.h"
#include "ofl-packets.h"
#include "ofc_legacy_bundle_structs.h"
#include "novi_port.h"

#include "noviIBSCommon.h"

static int bundle_port_exists(uint32_t port_id, int* index);
static int bundle_table_id_exists(uint8_t table_id);
static int bundle_flow_mod_validate_field(struct ofl_match_tlv *field);

typedef struct
{
	int type;
	void *funptr;
}BUNDLE_VERIFY_HOOKS;
BUNDLE_VERIFY_HOOKS verifyBundle[OFPT_END];
void AddBundleHook(int ofpt_type,void *hook)
{
	verifyBundle[ofpt_type].type=ofpt_type;
	verifyBundle[ofpt_type].funptr=hook;
}

static int bundle_logicalport_exists(uint32_t logicalport_id)
{
	struct shmdata_list *logicalport_nos = NULL;
	int ret = novicib_get_data(NoviCIB_Major_LogicalPort, NoviCIB_Minor_LogicalPort_No, &logicalport_nos, 0);
	while (ret == 0 && logicalport_nos != NULL)
	{
		uint8_t* logicalport_no = (uint8_t*) logicalport_nos->data;
		if (*logicalport_no == logicalport_id)
		{
			novicib_free_data(logicalport_nos);
			return 0;
		}
		logicalport_nos = logicalport_nos->next;
	}
	novicib_free_data(logicalport_nos);
	return -1;
}
static int bundle_validate_port(uint32_t port_id)
{
	switch (port_id & PORT_TYPE_MASK)
	{
		case (NOVI_PORTS_BASE):
			if ( bundle_port_exists(port_id, NULL) != 0 && bundle_logicalport_exists(port_id) != 0)
				return -1;
			break;
		case (OF_PORTS_BASE):
			if (port_id < OFPP_IN_PORT || port_id == OFPP_NORMAL)
				return -1;
			break;
		case (MULTICAST_BASE):
		default:
			return -1;
	}
	return 0;
}

/*************************
 *
 * Flow mod validation
 *
 *************************/

static ofl_err bundle_flow_mod_all(struct ofl_msg_flow_mod *msg)
{
	// ofl_err error = 0;
	switch (msg->command)
	{
		case OFPFC_DELETE:
		case OFPFC_DELETE_STRICT:
			/* At this point in the bundle process, this message is assumed to be valid */
			return 0;
		default:
			return ofl_error(OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_TABLE_ID);
	}
}
static ofl_err bundle_flow_mod_validate_action(enum ACTIONS_SOURCE act_source,
								struct ofl_action_header *action,
								struct write_apply_actions_fields* waf,
								size_t* act_size)
{
	/*
	 * Number of bytes to be inserted in the frame. PPE will support
	 * up to 102 bytes of data inserted in the header of the frame.
	 */
	uint32_t insertions = 0;
	bool has_group = false;
	size_t total_size = 0;

	uint64_t port_bitmap = 0;
	switch (action->type)
	{
		case (OFPAT_OUTPUT):
		{
			struct ofl_action_output *ao = (struct ofl_action_output *) action;
			if (act_source != ACTIONS_PACKET_OUT && ao->port == OFPP_TABLE)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_OUT_PORT);
			if (bundle_validate_port(ao->port) != 0)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_OUT_PORT);

			uint32_t port_type = ao->port & PORT_TYPE_MASK;
			switch (port_type)
			{
				case OF_PORTS_BASE:
					switch(ao->port)
					{
						case OFPP_ALL:
						case OFPP_FLOOD:
							#if defined(NOVIKIT) || defined(NSNP5)
									total_size += 6;
							#elif defined(NOVICORIANT)
									total_size += 8;
							#elif defined(NS1132) || defined(NS1248)
									break;
							#endif
							port_bitmap |= ao->port;
							break;
						case OFPP_IN_PORT:
							total_size += 2;
							break;
						case OFPP_CONTROLLER:
							total_size += 4;
							if (waf->out_ctrl_or_queue_8_present)
								return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_QUEUE);
							waf->out_ctrl_or_queue_8_present = 1;
							break;
						case OFPP_TABLE:
							total_size += 3;
							break;
					}
					break;
				case MULTICAST_BASE:
					break;
				case NOVI_PORTS_BASE:
					total_size += 2;
					#if defined(NOVIKITNP5)
						//TODO
						// total_size += 2;
					#endif
					break;
			}
			break;
		}
		case (OFPAT_GROUP): {
			total_size += sizeof(struct novi_hw_goto_group);
			/*
			 * We only allow one group action in an action
			 * list.
			 */
			if (has_group == true)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
			has_group = true;
			break;
		}

		case (OFPAT_SET_QUEUE): {
#if defined(NS1132) || defined(NS1248)
			total_size += 1;
			/*we should validate the queue id sent with set queue action*/
			struct ofl_action_set_queue *aq =
					(struct ofl_action_set_queue *) action;
			struct shmdata_list *port_queues = NULL;
			int ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_QueuesCount, &port_queues, 0);
			while (ret == 0 && port_queues != NULL)
			{
				uint8_t queues_count = *(uint8_t*) port_queues->data;
				if (aq->queue_id >= queues_count)
				{
					novicib_free_data(port_queues);
					return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_QUEUE);
				}
				port_queues = port_queues->next;
			}
			novicib_free_data(port_queues);
			/* validate controller queue*/
			// If there is an action set output to controller and aq->queue_id 0<>7 then error
			if (waf->out_ctrl_or_queue_8_present)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_QUEUE);
			waf->out_ctrl_or_queue_8_present = 1;
			break;
#else
			return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_TYPE);
#endif
		}
		case (OFPAT_PUSH_VLAN): {
			total_size += 2;
			/* add the size of a VLAN header to the total number of inserted bytes */
			insertions += (ETHERNET_TYPE_SIZE + VLAN_HDR_SIZE);
			break;
		}
		case (OFPAT_PUSH_MPLS): {
			total_size += 2;
			/* add the size of a MPLS header to the total number of inserted bytes */
			insertions += MPLS_HDR_SIZE;
			waf->mpls_present = 1;
			break;
		}
		case (OFPAT_PUSH_PBB): {
			total_size += 2;
			/* add the size of a PBB header to the total number of inserted bytes */
			insertions += (ETH_DST_SIZE + ETH_SRC_SIZE + ETHERNET_TYPE_SIZE
					+ PBB_HEADER_SIZE);
			waf->pbb_present = 1;
			break;
		}
		case (OFPAT_SET_FIELD): {
			struct ofl_action_set_field *asf =
					(struct ofl_action_set_field *) action;
			struct ofl_match_tlv tmp;
			tmp.header = asf->oxm_header;
			tmp.value = (uint8_t *)&asf->value;					
			/* SET_FIELD oxm_tlv cannot have a mask, from OF spec 1.3.2 */
			if (OXM_HASMASK(asf->oxm_header)) {
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_SET_ARGUMENT);
			}
			/*
			 * Check that we use only available OXM fields
			 * Should be between OXM_OF_IN_PORT and OFPXMT_OFB_PBB_UCA except 40
			 */
			if (OXM_FIELD(asf->oxm_header) < OXM_FIELD(OXM_OF_ETH_DST)
					|| OXM_FIELD(asf->oxm_header)
							> OXM_FIELD(OXM_OF_PBB_UCA)
					|| OXM_FIELD(asf->oxm_header) == RESERVED_MATCHFIELD)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_SET_TYPE);

			if (bundle_flow_mod_validate_field(&tmp) == -1)
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_BAD_SET_ARGUMENT);

			struct oxm_field *field = oxm_field_lookup(asf->oxm_header);
			if (field == NULL) return ofl_error(OFPET_BAD_ACTION, OFPBAC_TOO_MANY);
			total_size += OXM_LENGTH(field->header);
			break;
		}

		case (OFPAT_POP_MPLS): {
			total_size += 2;
			insertions += ETHERNET_TYPE_SIZE;
			struct ofl_action_pop_mpls *a =
					(struct ofl_action_pop_mpls *) action;
			break;
		}
		case (OFPAT_COPY_TTL_OUT):
		case (OFPAT_COPY_TTL_IN):
			break;
		case (OFPAT_SET_NW_TTL):
		case (OFPAT_SET_MPLS_TTL):
			total_size += 1;
			break;
		case (OFPAT_DEC_MPLS_TTL):
		case (OFPAT_POP_VLAN):
		case (OFPAT_DEC_NW_TTL):
		case (OFPAT_POP_PBB): {
			break;
		}
		case (OFPAT_COPY_FIELD):
            /* TODO: Add validation for copy-field action. Same validation as defined in novi_ofhandler */
		    break;
		case (OFPAT_EXPERIMENTER):
		{
			struct novi_exp_action_header* header = (struct novi_exp_action_header* ) action ;
			if (header->exp_header.customer_id == NOVIFLOW_C)
			{
				switch (header->exp_header.type)
				{
					case (SET_UDP_PAYLOAD_DATA) :
					{
						struct novi_exp_action_set_payload* a = (struct novi_exp_action_set_payload*) action ;
						total_size += sizeof(struct novi_hw_set_payload) + a->payload_size;
						break;
					}
					case (SET_IP_PAYLOAD_DATA) :
					{
						struct novi_exp_action_set_payload* a = (struct novi_exp_action_set_payload*) action ;
						total_size += sizeof(struct novi_hw_set_payload) + a->payload_size;
						break;
					}

				}
			}
			break;
		}
	}
	if (insertions > MAX_INSERTION_SIZE)
		return ofl_error(OFPET_BAD_ACTION, OFPBAC_TOO_MANY);
	*act_size = total_size;
	return 0;
}
static ofl_err bundle_flow_mod_validate_apply_actions_order(size_t actions_num,
	struct ofl_action_header **actions)
{
	uint32_t i = 0;
	bool vlan = false;
	bool mpls = false;
	bool pbb = false;

	for (i = 0; i < actions_num; i++)
	{
		if (actions[i]->type == OFPAT_PUSH_VLAN) {
			vlan = true;
		} else if (actions[i]->type == OFPAT_PUSH_PBB) {
			pbb = true;
		} else if (actions[i]->type == OFPAT_PUSH_MPLS) {
			mpls = true;
			struct ofl_action_push *ai = (struct ofl_action_push *) actions[i];
			if ((vlan || pbb) && ((ai->ethertype == ETH_TYPE_MPLS)
					|| (ai->ethertype == ETH_TYPE_MPLS_MCAST))) {
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
			}
		} else if (mpls || pbb) {
			// Once MPLS header is pushed , L3/4 Fileds should not be modified.
			if ((actions[i]->type == OFPAT_SET_NW_TTL) || (actions[i]->type
					== OFPAT_DEC_NW_TTL)) {
				return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
			} else if (actions[i]->type == OFPAT_SET_FIELD) {
				struct ofl_action_set_field* set_field =
						(struct ofl_action_set_field*) actions[i];

				if ((OXM_FIELD(set_field->oxm_header) != OXM_FIELD(OXM_OF_MPLS_TC))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_MPLS_LABEL))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_MPLS_TTL))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_ETH_DST))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_ETH_SRC))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_VLAN_VID))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_VLAN_PCP))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_PBB_ISID))
						&& (OXM_FIELD(set_field->oxm_header)
								!= OXM_FIELD(OXM_OF_PBB_UCA))) {
					return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
				}
			}
		}

	}
	return 0;
}
static ofl_err bundle_flow_mod_validate_output_bitmap(
	struct ofl_action_header **actions,
	int actions_num,
	int *act_size)
{
	int size = sizeof(struct novi_hw_action);

#if defined(NS1248) || defined(NS1132)
	*act_size = size+8;
#elif defined(NOVIKIT)
	*act_size = size+6;
#elif defined(NOVICORIANT)
	*act_size = size+8;
#endif
	return 0;
}
static ofl_err bundle_flow_mod_validate_instructions(struct ofl_msg_flow_mod *msg)
{
	ofl_err error = 0;
	struct write_apply_actions_fields write_fields;
	struct write_apply_actions_fields apply_fields;
	memset(&write_fields, 0, sizeof(struct write_apply_actions_fields));
	memset(&apply_fields, 0, sizeof(struct write_apply_actions_fields));
	int i = 0;
	size_t total_size = sizeof(struct novi_hw_instruction_list);
	for (i = 0; i<msg->instructions_num; i++)
	{
		if (total_size > MAX_INST_TOTAL_SIZE)
			return ofl_error(OFPET_BAD_ACTION, OFPBAC_TOO_MANY);
		switch(msg->instructions[i]->type)
		{
			case OFPIT_GOTO_TABLE:
			{
				total_size += sizeof(struct novi_hw_goto);
				struct ofl_instruction_goto_table *inst =
					(struct ofl_instruction_goto_table *) msg->instructions[i];
				/* Goto's destination must be greater than current table's id*/
				if (inst->table_id <= msg->table_id)
					return ofl_error(OFPET_BAD_INSTRUCTION, OFPBIC_BAD_TABLE_ID);
				else if (bundle_table_id_exists(inst->table_id) != 0)
					return ofl_error(OFPET_BAD_INSTRUCTION, OFPBIC_BAD_TABLE_ID);
				else
					break;
			}
			case OFPIT_WRITE_ACTIONS:
			{
				size_t act_size = 0;
				write_fields.write_present = 1;
				struct ofl_instruction_actions *inst =
					(struct ofl_instruction_actions *) msg->instructions[i];
				int j = 0;
				uint32_t act_bitmap = 0;
				for (j = inst->actions_num-1; j>=0; j--)
				{
					error = bundle_flow_mod_validate_action(ACTIONS_WRITE,
								inst->actions[j],
								&write_fields,
								&act_size);
					if (error) return error;
					if ((act_bitmap & (1<<inst->actions[j]->type)) == 0)
					{
						total_size += act_size;
					}
					act_bitmap |= (1<<inst->actions[j]->type);
				}

				if (write_fields.write_present &&
					apply_fields.apply_present &&
					write_fields.mpls_present  &&
					apply_fields.pbb_present)
					return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
				break;
			}
			case OFPIT_APPLY_ACTIONS:
			{
				size_t act_size = 0;
				apply_fields.apply_present = 1;
				struct ofl_instruction_actions *inst =
					(struct ofl_instruction_actions *) msg->instructions[i];
				int j = 0, k = 0;

				/*check if there is multiple outputs that can be translated to bitmap*/
				int bitmap_output_num=0;
				bool TranslateOutBmp = false;
				int first_port_index = 0;
				for(j=0; j<inst->actions_num; j++)
				{
					if(inst->actions[j]->type==OFPAT_OUTPUT)
					{
						if (TranslateOutBmp)
						{
							first_port_index=j;
						}
						else
						{
							for (k = first_port_index; k<j; k++)
							{
								struct ofl_action_output *cur = inst->actions[j];
								struct ofl_action_output *ao = inst->actions[k];
								if (ao->port == cur->port)
								{
									/* Duplicate outputs not allowed in bitmap, restart bitmap */
									bitmap_output_num = 0;
									first_port_index = j;
								}
							}
						}
						TranslateOutBmp = true;
						/* Append to bitmap */
						bitmap_output_num++;
					}
					else if (bitmap_output_num < MIN_BITAMP_OUTPUTS_NUM)
					{
						/* Not enough outputs for bitmap, look for more */
						bitmap_output_num = 0;
						TranslateOutBmp=false;
					}
					else
					{
						/* bitmap is over */
						break;
					}
				}

				for (j = 0; j<inst->actions_num; j++)
				{
					if(TranslateOutBmp && j == first_port_index){
						error = bundle_flow_mod_validate_output_bitmap(
							&inst->actions[j],
							inst->actions_num-j,
							&act_size);
						if (error) return error;
						total_size+=act_size;
						j += bitmap_output_num;
						continue;
					}

					error = bundle_flow_mod_validate_action(ACTIONS_APPLY,
								inst->actions[j],
								&write_fields,
								&act_size);
					if (error) return error;
					total_size += act_size;
				}

				error = bundle_flow_mod_validate_apply_actions_order(inst->actions_num, inst->actions);
				if (error) return error;

				if (write_fields.write_present &&
					apply_fields.apply_present &&
					write_fields.mpls_present  &&
					apply_fields.pbb_present)
					return ofl_error(OFPET_BAD_ACTION, OFPBAC_UNSUPPORTED_ORDER);
				break;
			}
			case OFPIT_WRITE_METADATA:
			{
				total_size += sizeof(struct novi_hw_write_metadata);
				struct ofl_instruction_write_metadata * inst =
					(struct ofl_instruction_write_metadata*) msg->instructions[i];
				uint64_t metadata_MSB = inst->metadata & 0xFFFFFFFF00000000ULL;
				if (metadata_MSB)
					return ofl_error(OFPET_BAD_INSTRUCTION, OFPBIC_UNSUP_METADATA_MASK);
				else
					break;
			}
			case OFPIT_EXPERIMENTER:
				return ofl_error(OFPET_BAD_INSTRUCTION, OFPBIC_UNSUP_INST);
			case OFPIT_METER:
				total_size += sizeof(struct novi_hw_goto_meter);
				break;
			case OFPIT_CLEAR_ACTIONS:
				total_size += 0;
				break;
		}
	}
	return 0;
}
/*
 * Validate that the value inside an oxm field is between minimum and maximum allowed segment.
 * Used both for set_field action and for match fields.
 *
 */
static int bundle_flow_mod_validate_field(struct ofl_match_tlv *field)
{
	/* no field is bigger than 32 bits */
	uint32_t temp_field = 0;
	unsigned int length = 0;
	bool has_mask = OXM_HASMASK(field->header);

	length = has_mask ? OXM_LENGTH(field->header) / 2
			: OXM_LENGTH(field->header);
	/* if field is bigger than this it does not apply */
	if (length > sizeof(temp_field))
		return 0;

	memcpy(&temp_field, field->value, length);
	temp_field = ntohl(temp_field);
	temp_field = temp_field >> (sizeof(temp_field) - length) * 8;

	switch (OXM_FIELD(field->header)) {
	case OXM_FIELD(OXM_OF_VLAN_VID):
		/* We ignore 13th bit here since some controllers use set field as if it were a match field */
        if ((0xEFFF & temp_field) > VLAN_VID_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_VLAN_PCP):
		/* vlan_pcp value is only 3 bits. */
		if (temp_field > OF_VLAN_PCP_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_IP_DSCP):
		/* IP DSCP is only 6 bits */
		if (temp_field > OF_IP_DSCP_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_IP_ECN):
		/* IP ECN is only 2 bits */
		if ((temp_field > OF_IP_ECN_MAX))
			return -1;
		break;
	case OXM_FIELD(OXM_OF_MPLS_LABEL):
		/* MPLS label is only 20 bits */
		if (temp_field > OF_MPLS_LABEL_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_MPLS_TC):
		/* MPLS TC is only 3 bits */
		if ((temp_field > OF_MPLS_TC_MAX))
			return -1;
		break;
	case OXM_FIELD(OXM_OF_MPLS_BOS):
		/* MPLS BOS is only 1 bit */
		if (temp_field > OF_MPLS_BOS_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_IPV6_FLABEL):
		/* IPV6 flow label is 20 bits */
		if (temp_field > OF_IPV6_FLOW_LABEL_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_IPV6_EXTHDR):
		/* IPV6 EXT Header is only 9 bits */
		if (temp_field > OF_IPV6_EXtHDR_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_PBB_ISID):
		/* PBB I-SID is only 24 bits */
		if (temp_field > OF_PBB_ISID_MAX)
			return -1;
		break;
	case OXM_FIELD(OXM_OF_PBB_UCA):
		/* PBB UCA is only 1 bit */
		if (temp_field > OF_PBB_UCA_MAX)
			return -1;
		break;
	default:
		/* other than those, no value is invalid */
		return 0;
	}
	return 0;
}
static ofl_err bundle_flow_mod_validate_match(struct ofl_msg_flow_mod *msg)
{
	struct ofl_match_tlv *tlv;
	struct ofl_match* match = (struct ofl_match*) msg->match;
	HMAP_FOR_EACH(tlv, struct ofl_match_tlv, hmap_node, &match->match_fields)
	{
		if (OXM_VENDOR(tlv->header) != OFPXMC_OPENFLOW_BASIC)
			continue;

		if ((OXM_FIELD(tlv->header) < OXM_FIELD(OXM_OF_IN_PORT)) ||
			(OXM_FIELD(tlv->header) > OXM_FIELD(OXM_OF_PBB_UCA)) ||
			(OXM_FIELD(tlv->header) == RESERVED_MATCHFIELD))
		{
			return ofl_error(OFPET_BAD_MATCH, OFPBMC_BAD_FIELD);
		}
		else if (OXM_FIELD(tlv->header) == OXM_FIELD(OXM_OF_IN_PORT))
		{
			uint32_t port_id = ntohl(*(uint32_t*) tlv->value);
			if (port_id != OFPP_CONTROLLER && bundle_port_exists(port_id, NULL) != 0)
				return ofl_error(OFPET_BAD_MATCH, OFPBMC_BAD_VALUE);
		}
		else if (bundle_flow_mod_validate_field(tlv) == -1)
			return ofl_error(OFPET_BAD_MATCH, OFPBMC_BAD_VALUE);

		if (OXM_HASMASK(tlv->header))
		{
			int i = 0;
			size_t field_len = 0;
			uint8_t *value, *mask;
			/* The length of tlv header accounts for both the value and mask */
			field_len = OXM_LENGTH(tlv->header) / 2;
			value = tlv->value;
			mask =  &tlv->value[field_len];
			for (i = 0; i < field_len; i++)
			{
				if ((value[i] & ~((uint8_t) mask[i])) != 0)
					return ofl_error(OFPET_BAD_MATCH, OFPBMC_BAD_WILDCARDS);
			}
		}
	}
	return 0;
}
static int bundle_table_id_exists(uint8_t table_id)
{
	struct shmdata_list *table_ids = NULL, *iterator = NULL;
	int ret = novicib_get_data(NoviCIB_Major_Table, NoviCIB_Minor_Table_Id, &table_ids, 0);
	iterator = table_ids;
	while(ret == 0 && iterator != NULL)
	{
		if (*(uint8_t*)iterator->data == table_id)
		{
			novicib_free_data(table_ids);
			return 0;
		}
		iterator = iterator->next;
	}
	novicib_free_data(table_ids);
	return -1;
}

static ofl_err bundle_flow_mod_single(struct ofl_msg_flow_mod *msg)
{
	ofl_err error = 0;
	int ret = 0;

	ret = bundle_table_id_exists(msg->table_id);
	if (ret != 0)
		return ofl_error(OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_TABLE_ID);

	error = bundle_flow_mod_validate_match(msg);
	if (error) return error;

	error = bundle_flow_mod_validate_instructions(msg);
	if (error) return error;

	switch(msg->command)
	{
		case OFPFC_ADD:
		case OFPFC_MODIFY:
		case OFPFC_MODIFY_STRICT:
		case OFPFC_DELETE:
		case OFPFC_DELETE_STRICT:
			break;
		default:
			return ofl_error(OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_COMMAND);
	}
	return 0;
}
static ofl_err bundle_flow_mod(struct ofl_msg_header *input)
{
	struct ofl_msg_flow_mod *msg = (struct ofl_msg_flow_mod *) input;
	switch(msg->table_id)
	{
		case OFPTT_ALL: /* all tables */
			return bundle_flow_mod_all(msg);
		default:
			return bundle_flow_mod_single(msg);
	}
}


/*************************
 *
 * Port mod validation
 *
 *************************/
static int bundle_port_exists(uint32_t port_id, int* index)
{
	struct shmdata_list *port_nos = NULL, *iterator = NULL;
	int ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_No, &port_nos, 0);
	iterator = port_nos;
	while (ret == 0 && iterator != NULL)
	{
		uint8_t* port_no = (uint8_t*) iterator->data;
		if (*port_no == port_id)
		{
			if (index) *index = iterator->index;
			novicib_free_data(port_nos);
			return 0;
		}
		iterator = iterator->next;
	}
	novicib_free_data(port_nos);
	return -1;
}
static ofl_err bundle_port_mod(struct ofl_msg_header *input)
{
	int ret = 0;
	struct ofl_msg_port_mod *src_msg = (struct ofl_msg_port_mod *) input;

	ret = bundle_port_exists(src_msg->port_no,NULL);
	if (ret != 0)
		return ofl_error(OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_PORT);

	struct shmdata_list *port_hw_addr = NULL;
	ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_HwAddr, &port_hw_addr, src_msg->port_no);
	if (ret != 0 || port_hw_addr == NULL)
	{
		return ofl_error(OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_PORT);
	}
	if (ret != 0 ||
		port_hw_addr == NULL ||
		memcmp((uint8_t*)port_hw_addr->data, src_msg->hw_addr, 6) != 0 )
	{
		return ofl_error(OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_HW_ADDR);
	}
	novicib_free_data(port_hw_addr);

	struct shmdata_list *port_config = NULL;
	ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_SupportedConfig, &port_config, src_msg->port_no);
	if (ret != 0 ||
		port_config == NULL ||
		~(*(uint32_t*)port_config->data) & src_msg->mask )
	{
		return ofl_error(OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_CONFIG);
	}
	novicib_free_data(port_config);

	struct shmdata_list *port_advertise = NULL;
	ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_SupportedAdvertised, &port_advertise, src_msg->port_no);
	if (ret != 0 ||
		port_advertise == NULL ||
		~(*(uint32_t*)port_advertise->data) & src_msg->advertise)
	{
		return ofl_error(OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_ADVERTISE);
	}

	novicib_free_data(port_advertise);
	return 0;
}
static ofl_err bundle_meter_mod_bands(struct ofl_meter_band_header* band, size_t *band_size)
{
	switch(band->type)
	{
		case OFPMBT_DROP:
			*band_size = 2;
			return 0;
		case OFPMBT_DSCP_REMARK:
		{
			*band_size = 3;
			struct ofl_meter_band_dscp_remark *dscp =
				(struct ofl_meter_band_dscp_remark *) band;
			if (dscp->prec_level > MAX_DSCP_PREC_LEVEL)
				return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_BAD_BAND_VALUE);
		}
		case OFPMBT_EXPERIMENTER:
			*band_size = 6;
		default:
			return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_BAD_BAND);
	}
}

static ofl_err bundle_meter_mod_add(struct ofl_msg_meter_mod *msg)
{
	int i = 0;
	ofl_err error = 0;

	/* Checking segment of Meter Id */
	if (msg->meter_id < NOVI_MIN_METER_ID || msg->meter_id > NOVI_MAX_METER_ID)
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_INVALID_METER);

    /* If KBPS and PKTPS both are set return error */
    if (((msg->flags & OFPMF_KBPS) && (msg->flags & OFPMF_PKTPS)) || (msg->flags == 0))
        return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_BAD_FLAGS);

    /* Return error in case Meter has more than NL_METER_MAX_BAND bands */
    if (NL_METER_MAX_BAND < msg->meter_bands_num)
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_OUT_OF_BANDS);

	if(msg->meter_bands_num == 0)
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_INVALID_METER);

	size_t total_size = 0;
	for (i = 0; i<msg->meter_bands_num; i++)
	{
		size_t band_size = 0;
		error = bundle_meter_mod_bands(msg->bands[i], &band_size);
		if (error) return error;
		total_size += band_size;
	}
	if(total_size > MAX_METER_ENTRY_BAND_DATA -3)
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_OUT_OF_BANDS);

	return 0;
}
static ofl_err bundle_meter_mod_modify(struct ofl_msg_meter_mod *msg)
{
	ofl_err error = 0;

	/* Checking segment of Meter Id */
	if (msg->meter_id < NOVI_MIN_METER_ID || msg->meter_id > NOVI_MAX_METER_ID)
			return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_INVALID_METER);

    /* If KBPS and PKTPS both are set return error */
    if (((msg->flags & OFPMF_KBPS) && (msg->flags & OFPMF_PKTPS)) || (msg->flags == 0))
        return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_BAD_FLAGS);

	/*
     *  Return error in case Meter has more than NL_METER_MAX_BAND bands
	 */
	if(msg->meter_bands_num > NL_METER_MAX_BAND || msg->meter_bands_num == 0 )
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_OUT_OF_BANDS);

	int i = 0;
	size_t total_size = 0;
	for (i = 0; i<msg->meter_bands_num; i++)
	{
		size_t band_size = 0;
		error = bundle_meter_mod_bands(msg->bands[i], &band_size);
		if (error) return error;
		total_size += band_size;
	}
	if(total_size > MAX_METER_ENTRY_BAND_DATA -3)
		return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_OUT_OF_BANDS);
	return 0;
}

/*****************************
 *
 * Multipart request validation
 *
 *****************************/
/*****************************
 * Table features validation
 *****************************/
 // function copied of validate_multipart_table_properties in novi_pipeline.c
uint32_t
bundle_multipart_table_feature_validate_table_properties(struct ofl_table_features *table_features)
{
	uint32_t ret=OK;
	int i,j=0;


	for (i=0;i < table_features->properties_num; i++)
	{
		switch (table_features->properties[i]->type)
		{
		case OFPTFPT_NEXT_TABLES:
		case OFPTFPT_NEXT_TABLES_MISS:
		{
			struct ofl_table_feature_prop_next_tables *tbl_reachable;
			tbl_reachable=(struct ofl_table_feature_prop_next_tables *)table_features->properties[i];
			for(j=0; j < tbl_reachable->table_num; j++)
			{
				if(table_features->table_id >= tbl_reachable->next_table_ids[j])
				{
					//noviengine_print("Invalid Goto Instruction in Multi-Part Message\n");
					ret=ofl_error(OFPET_TABLE_FEATURES_FAILED,OFPTFFC_BAD_ARGUMENT);
					break;
				}
			}
			tbl_reachable=NULL;
			break;
		}
		case OFPTFPT_INSTRUCTIONS:
		case OFPTFPT_INSTRUCTIONS_MISS:
			break;
		case OFPTFPT_APPLY_ACTIONS:
		case OFPTFPT_APPLY_ACTIONS_MISS:
		case OFPTFPT_WRITE_ACTIONS:
		case OFPTFPT_WRITE_ACTIONS_MISS:
		{
			#if defined(NS1248) || defined(NS1132)
				break;
			#endif

			struct ofl_table_feature_prop_actions *action_properties;
			action_properties=(struct ofl_table_feature_prop_actions *)table_features->properties[i];
			for(j=0; j< action_properties->actions_num; j++)
			{
			if(action_properties->action_ids[j].type== OFPAT_SET_QUEUE)
				{
					//noviengine_print("Unsupported OFPAT_SET_QUEUE Line=%d,File =%s\n",__LINE__,__FUNCTION__);
					ret=ofl_error(OFPET_TABLE_FEATURES_FAILED,OFPTFFC_BAD_ARGUMENT);
					break;
				}
			}
			break;
		}
		case OFPTFPT_WRITE_SETFIELD:
		case OFPTFPT_WRITE_SETFIELD_MISS:
		case OFPTFPT_APPLY_SETFIELD:
		case OFPTFPT_APPLY_SETFIELD_MISS:
		{
			struct ofl_table_feature_prop_oxm *oxm_capabilities=(struct ofl_table_feature_prop_oxm *)table_features->properties[i];
			for(j=0;j < oxm_capabilities->oxm_num;j++){
				if (OXM_VENDOR(oxm_capabilities->oxm_ids[j]) == OF_VENDOR_ID) {
					if( (OXM_FIELD(oxm_capabilities->oxm_ids[j]) == OXM_FIELD(OXM_OF_METADATA)) ||
							(OXM_FIELD(oxm_capabilities->oxm_ids[j]) == OXM_FIELD(OXM_OF_IPV6_EXTHDR)) ||
							(OXM_FIELD(oxm_capabilities->oxm_ids[j]) == OXM_FIELD(OXM_OF_IN_PORT)) ||
							(OXM_FIELD(oxm_capabilities->oxm_ids[j]) == OXM_FIELD(OXM_OF_IN_PHY_PORT)))
					{
						ret=ofl_error(OFPET_TABLE_FEATURES_FAILED,OFPTFFC_BAD_ARGUMENT);
						break;
					}
				}
			}
			break;
		}
		case OFPTFPT_EXPERIMENTER: {
		case OFPTFPT_EXPERIMENTER_MISS:
			break;
		}
		case OFPTFPT_WILDCARDS:
		{
			struct ofl_table_feature_prop_oxm *oxm_capabilities=(struct ofl_table_feature_prop_oxm *)table_features->properties[i];
			if(table_features->table_id == 0){
				for(j=0;j < oxm_capabilities->oxm_num;j++)
				{
					if ((OXM_VENDOR(oxm_capabilities->oxm_ids[j]) == OF_VENDOR_ID) &&
					    (OXM_FIELD(oxm_capabilities->oxm_ids[j]) == OXM_FIELD(OXM_OF_METADATA)))
					{
							ret=ofl_error(OFPET_TABLE_FEATURES_FAILED,OFPTFFC_BAD_ARGUMENT);
							break;

					}

				}
			}
			break;
		}
		case OFPTFPT_MATCH: {
			break;
		}
		default:
			break;
		}
	}
	return ret;
}
static ofl_err bundle_multipart_table_feature_validate_match(struct ofl_table_features *features, uint8_t table_id)
{
	uint8_t i,j;
	struct ofl_table_feature_prop_oxm *match = NULL;
	for(i = 0; i < features->properties_num; i++)
	{
		match = (struct ofl_table_feature_prop_oxm *) features->properties[i];
		if(match->header.type != OFPTFPT_MATCH)
			continue;
		if(match->oxm_num ==0){
			return 0;
		}
		for(j=0; j< match->oxm_num ; j++)
		{
			if(OXM_VENDOR(match->oxm_ids[j]) == OF_VENDOR_ID)
			{
				if(OXM_FIELD(match->oxm_ids[j]) == OXM_FIELD(OXM_OF_METADATA) &&
					table_id == 0){
					/* Table 0 can not match on metadata*/
					return ofl_error(OFPET_TABLE_FEATURES_FAILED, OFPTFFC_BAD_ARGUMENT );
				}
				else if (OXM_FIELD(match->oxm_ids[j]) == OXM_FIELD(OXM_OF_TUNNEL_ID) &&
					table_id != 0){
					/*Right now, Tunnel id is supported only in table 0*/
					return ofl_error(OFPET_TABLE_FEATURES_FAILED, OFPTFFC_BAD_ARGUMENT );
				}
			}
			else if(OXM_VENDOR(match->oxm_ids[j]) == EXP_VENDOR_ID)
			{
				continue;
			}
			else
				return ofl_error(OFPET_TABLE_FEATURES_FAILED, OFPTFFC_BAD_ARGUMENT );
		}
	}
	return 0;
}
static ofl_err bundle_multipart_request_table_features(struct ofl_msg_multipart_request_table_features *msg)
{
	ofl_err error = 0;
	uint8_t i =0;
	if(msg->table_features!=NULL)
	{
		for (i=0;i<msg->tables_num;i++)
		{
			error = bundle_multipart_table_feature_validate_table_properties(msg->table_features[i]);
			if(error) return error;
			/*
			 * The table specified in the message might not really exist, we
			 * need to check if it does.
			 */
			if(bundle_table_id_exists(msg->table_features[i]->table_id)!=0)
				return ofl_error(OFPET_TABLE_FEATURES_FAILED, OFPTFFC_BAD_TABLE);
			/*
			 * We only support metadata values on 32bits, from 0 to 0xFFFFFFFF,
			 * because of limitations in PPE's TCAM. Thefore, we send an error
			 * to the controller if the metadata fields are out of that segment.
			 */

			if ( (msg->table_features[i]->metadata_write & 0xFFFFFFFF00000000ULL) != 0 ||
				(msg->table_features[i]->metadata_match & 0xFFFFFFFF00000000ULL) != 0)
			{
				return ofl_error(OFPET_TABLE_FEATURES_FAILED, OFPTFFC_BAD_METADATA);
			}
			error = bundle_multipart_table_feature_validate_match(msg->table_features[i], msg->table_features[i]->table_id);
			if(error) return error;
		}
	}
	return 0;
}

/*****************************
 * port stats validation
 *****************************/
 static ofl_err bundle_multipart_request_port_stats(struct ofl_msg_multipart_request_port *msg)
{
	int ret =0;
	uint32_t port_id = msg->port_no;
	switch (port_id & PORT_TYPE_MASK)
	{
		case (NOVI_PORTS_BASE):
			if ( bundle_port_exists(port_id, NULL) != 0)
				ret= -1;
			break;
		case (OF_PORTS_BASE):
			if (( port_id != OFPP_ANY) && (port_id != OFPP_CONTROLLER))
				ret = -1;
			break;
		case (MULTICAST_BASE):
		default:
			ret = -1;
	}
	if( -1 == ret)
		return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_PORT);
	return 0;
}

static
ofl_err bundle_multipart_requests_queue(struct ofl_msg_multipart_request_queue *msg)
{
	struct novi_port* port;
	struct novi_port_queue* queue;
	int i=0,port_count,ret;
	struct shmdata_list *shm_portcount= NULL;
	struct shmdata_list *shm_queuecount = NULL;

	if (msg->port_no == OFPP_ANY) {
		if (msg->queue_id != OFPQ_ALL)
		{
			ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_Count,&shm_portcount,0);
			if (ret != 0 || shm_portcount == NULL)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
			port_count=*(uint8_t*)shm_portcount->data;
			novicib_free_data(shm_portcount);

			ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_QueuesCount, &shm_queuecount, 0);
			if (ret != 0 || shm_queuecount == NULL)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);

			uint8_t queue_count = *(uint8_t *)shm_queuecount->data;
			novicib_free_data(shm_queuecount);
			if (msg->queue_id > queue_count  - 1)
			{
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);
			}
		}

	}
	else if (msg->port_no == OFPP_CONTROLLER) {
		if (msg->queue_id != OFPQ_ALL)
		{
			ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_Controller_QueuesCount,&shm_queuecount,0);
			if (ret != 0 || shm_queuecount == NULL)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);

			uint8_t queue_count = *(uint8_t*) shm_queuecount->data;
			novicib_free_data(shm_queuecount);
			if (msg->queue_id > queue_count)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);
		}
	}
	else
	{
		if (bundle_port_exists(msg->port_no, NULL) != 0)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_PORT);
		if (msg->queue_id != OFPQ_ALL)
		{
			ret = novicib_get_data(NoviCIB_Major_Port, NoviCIB_Minor_Port_QueuesCount, &shm_queuecount, 0);
			if (ret != 0 || shm_queuecount == NULL)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
			uint8_t queue_count= *(uint8_t *)shm_queuecount->data;
			novicib_free_data(shm_queuecount);
			if (msg->queue_id > queue_count - 1)
				return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);
		}
	}
	return 0;
}

static
ofl_err bundle_multipart_request_port_queue_send_desc(void * input)
{
	struct ofl_msg_multipart_queue_desc_request *msg=input;
	int queue_num, size=0, ret = 0;
	struct shmdata_list *iterator = NULL;

	if(msg->port_no==OFPP_ANY){
		struct shmdata_list *port_queues = NULL;
		int list_index=0;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_QueuesCount,&port_queues,list_index);
		if (ret != 0 || port_queues == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);

		iterator = port_queues;
		while (iterator != NULL)
		{
			size+=*(uint8_t*)iterator->data;
			iterator=iterator->next;
		}
		novicib_free_data(port_queues);
		/*If there is no queue at all, send an error*/
		if(size == 0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}
	}
	else if(msg->port_no==OFPP_CONTROLLER){
		struct shmdata_list *port_queue = NULL;
		int list_index=0;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_Controller_QueuesCount,&port_queue,list_index);
		if (ret != 0 || port_queue == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		queue_num=*((uint8_t*)port_queue->data);
		novicib_free_data(port_queue);
		if(queue_num==0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}
	}
	else{
  		if (bundle_port_exists(msg->port_no, NULL) != 0)
			return ofl_error(OFPET_QUEUE_OP_FAILED, OFPQOFC_BAD_PORT);
		/*If there is no queue, send an error back*/
		struct shmdata_list *queue_num_list = NULL;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_QueuesCount,&queue_num_list,0);
		if (ret != 0 || queue_num_list == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		queue_num= *(uint8_t*)queue_num_list->data;
		novicib_free_data(queue_num_list);
		if (queue_num == 0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}

	}
	return 0;

}

static
ofl_err bundle_multipart_request(void *input)
{
	struct ofl_msg_multipart_request_header *msg=input;
	switch (msg->type){
		case (OFPMP_DESC):
		{
			break;
		}
		case (OFPMP_FLOW):
		{
			struct ofl_msg_multipart_request_flow *flow_msg = (struct ofl_msg_multipart_request_flow *)msg;
			if (flow_msg->table_id != OFPTT_ALL)
				if(bundle_table_id_exists(flow_msg->table_id)!=0)
					return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TABLE_ID);
			break;
		}
		case (OFPMP_AGGREGATE):
		{
			struct ofl_msg_multipart_request_flow *flow_msg = (struct ofl_msg_multipart_request_flow *)msg;
			if (flow_msg->table_id != OFPTT_ALL)
				if(bundle_table_id_exists(flow_msg->table_id)!=0)
					return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TABLE_ID);
			break;
		}
		case (OFPMP_TABLE):
		{
			break;
		}
		case (OFPMP_TABLE_FEATURES):
		{
			return bundle_multipart_request_table_features((struct ofl_msg_multipart_request_table_features *) msg);
		}
		case (OFPMP_PORT_STATS):
		{
			return bundle_multipart_request_port_stats((struct ofl_msg_multipart_request_port *) msg);
		}
		case (OFPMP_GROUP):
		{
			break;
		}
		case (OFPMP_GROUP_DESC):
		{
			break;
		}
		case (OFPMP_GROUP_FEATURES):
		{
			break;
		}
		case (OFPMP_PORT_DESC):
		{
			break;
		}
		case (OFPMP_QUEUE_DESC): {
			return bundle_multipart_request_port_queue_send_desc(msg);
		}
		case (OFPMP_EXPERIMENTER): {
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);
		}
		case (OFPMP_METER_FEATURES):
		case (OFPMP_METER_CONFIG):
		case (OFPMP_METER):
		{
			break;
		}
		case OFPMP_QUEUE:{
			return bundle_multipart_requests_queue((struct ofl_msg_multipart_request_queue*)msg);
		}
		case (OFPMP_TABLE_DESC):
		{
			break;
		}
		default: {
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_MULTIPART);
		}

	}
	return 0;
}
static ofl_err bundle_meter_mod(void  *input)
{
	struct ofl_msg_meter_mod *msg = (struct ofl_msg_meter_mod *) input;
	switch(msg->command)
	{
		case OFPMC_ADD:
			return bundle_meter_mod_add(msg);
		case OFPMC_MODIFY:
			return bundle_meter_mod_modify(msg);
		case OFPMC_DELETE:
			return 0;
		default:
			return ofl_error(OFPET_METER_MOD_FAILED, OFPMMFC_BAD_COMMAND);
	}
}
static ofl_err
bundle_group_mod(struct ofl_msg_group_mod *input)
{
		struct ofl_msg_group_mod *msg = input;
		ofl_err error=0;
		size_t i;

		struct novi_group_table *table;
		struct write_apply_actions_fields waf;
		memset(&waf, 0, sizeof(struct write_apply_actions_fields));
		if(msg->type > OFPGT_FF){
			error= ofl_error(OFPET_GROUP_MOD_FAILED, OFPGMFC_BAD_TYPE);
			goto Err;
		}
		switch (msg->command)
		{
			case (OFPGC_ADD):
			case (OFPGC_MODIFY): {
				for (i = 0; i < msg->buckets_num; i++) {
					error = bundle_flow_mod_validate_action(ACTIONS_GROUP,
							msg->buckets[i]->actions, &waf, &msg->buckets[i]->actions_num);
					if (error) break;
				}
				break;
			}
			case (OFPGC_DELETE): {
				break;
			}
			default: {
				error=ofl_error(OFPET_GROUP_MOD_FAILED, OFPGMFC_BAD_COMMAND);
			}
		}
Err:
		return error;
}
static ofl_err bundle_barrier_request(void  *input)
{
	return 0;
}

static ofl_err bundle_features_request(void  *input)
{
	return 0;
}

static ofl_err bundle_config_request(void  *input)
{
	return 0;
}

static ofl_err bundle_set_config(void  *input)
{
	struct ofl_msg_set_config *msg = (struct ofl_msg_set_config *) input;
	if (msg->config->flags != 0)
		return ofl_error(OFPET_SWITCH_CONFIG_FAILED, OFPSCFC_BAD_FLAGS);

	if ((msg->config->miss_send_len != OFPCML_NO_BUFFER)
			&& (msg->config->miss_send_len > MAX_DATAPLANE_PKT_SIZE))
		return ofl_error(OFPET_SWITCH_CONFIG_FAILED, OFPSCFC_BAD_LEN);
	return 0;
}

static ofl_err bundle_table_mod(void *input)
{
	int i = 0;
	struct ofl_msg_table_mod *msg = (struct ofl_msg_table_mod *)input;
	if (msg->table_id!= OFPTT_ALL)
		if (bundle_table_id_exists(msg->table_id)!=0)
			return ofl_error(OFPET_TABLE_MOD_FAILED, OFPTMFC_BAD_TABLE);

	for(i=0; i<msg->mod_properties_num; i++){
		switch(msg->mod_properties[i]->type){
			case OFPTMPT_EVICTION :{
				struct ofl_table_mod_prop_eviction*  eviction = msg->mod_properties[i];
				//Later we will support the two eviction methods and remove the following check
				if((eviction->flags & OFPTMPEF_LIFETIME) || (eviction->flags & OFPTMPEF_OTHER) ) {
					return ofl_error(OFPET_BAD_PROPERTY, OFPBPC_BAD_VALUE);
				}
				break;
			}
			case OFPTMPT_VACANCY :{
				struct ofl_table_mod_prop_vacancy* vacancy = msg->mod_properties[i];
				if( (vacancy->vacancy_up > 100) || (vacancy->vacancy_down > 99) || (vacancy->vacancy_down >= vacancy->vacancy_up) ){
					return ofl_error(OFPET_BAD_PROPERTY, OFPBPC_BAD_VALUE);
				}

				break;
			}
			default : {
				return ofl_error(OFPET_BAD_PROPERTY, OFPBPC_BAD_TYPE);
			}
		}
	}
	return 0;
}

static ofl_err bundle_packet_out(struct ofl_msg_packet_out *msg) {

	ofl_err error;
	struct write_apply_actions_fields dummy_waf;
	memset(&dummy_waf, 0x00, sizeof(struct write_apply_actions_fields));
	error = bundle_flow_mod_validate_action(ACTIONS_PACKET_OUT,msg->actions,&dummy_waf, &msg->actions_num);
	if (error)
		return error;
	if (msg->in_port != OFPP_CONTROLLER && bundle_port_exists(msg->in_port, NULL) != 0)
		return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_PORT);
	return 0;
}

uint16_t
bundle_error(uint8_t type, uint8_t code) {
    uint16_t val = type;
    return  val << 8 | code;
}

static ofl_err bundle_experimenter(void  *input)
{
	return 0;
}

static
ofl_err bundle_get_port_queue_config(void * input)
{
	struct ofl_msg_queue_get_config_request *msg = (struct ofl_msg_queue_get_config_request *)input;
	int queue_num, size=0, ret = 0;

	if(msg->port==OFPP_ANY){
		struct shmdata_list *iterator = NULL, *shm_head = NULL;

		uint8_t port_count = 0, queues_count = 0;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_Count,&shm_head,0);
		if (ret != 0 || shm_head == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);

		port_count = *(uint8_t*) shm_head->data;
		novicib_free_data(shm_head);

		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_QueuesCount,&shm_head,0);
		if (ret != 0 || shm_head == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		queues_count = *(uint8_t*) shm_head->data;
		novicib_free_data(shm_head);

		int i = 0;
		for(i = 0; i<port_count; i++)
			size+=queues_count;

		/*If there is no queue at all, send an error*/
		if(size == 0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}
	}
	else if(msg->port==OFPP_CONTROLLER){
		struct shmdata_list *port_queue = NULL;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_Controller_QueuesCount,&port_queue,0);
		if (ret != 0 || port_queue == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		queue_num=*((uint8_t*)port_queue->data);
		novicib_free_data(port_queue);
		if(queue_num==0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}
	}
	else{
		int ret = bundle_port_exists(msg->port, NULL);
		if (ret != 0)
			return ofl_error(OFPET_QUEUE_OP_FAILED, OFPQOFC_BAD_PORT);
		/*If there is no queue, send an error back*/
		struct shmdata_list *queue_num_list = NULL;
		ret = novicib_get_data(NoviCIB_Major_Port,NoviCIB_Minor_Port_QueuesCount,&queue_num_list,0);
		if (ret != 0 || queue_num_list == NULL)
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		queue_num= *(uint8_t*)queue_num_list->data;
		novicib_free_data(queue_num_list);
		if (queue_num == 0){
			return ofl_error(OFPET_BAD_REQUEST, OFPBRC_BAD_TYPE);
		}

	}
	return 0;

}
void initBundleHooks()
{
	memset(verifyBundle,0x0,sizeof(verifyBundle));
	AddBundleHook(OFPT_FLOW_MOD,bundle_flow_mod);
	AddBundleHook(OFPT_PORT_MOD,bundle_port_mod);
	AddBundleHook(OFPT_MULTIPART_REQUEST,bundle_multipart_request);
	AddBundleHook(OFPT_METER_MOD,bundle_meter_mod);
	AddBundleHook(OFPT_GROUP_MOD,bundle_group_mod);
	AddBundleHook(OFPT_FEATURES_REQUEST, bundle_features_request);
	AddBundleHook(OFPT_GET_CONFIG_REQUEST, bundle_config_request);
	AddBundleHook(OFPT_BARRIER_REQUEST, bundle_barrier_request);
	AddBundleHook(OFPT_SET_CONFIG, bundle_set_config);
	AddBundleHook(OFPT_TABLE_MOD,bundle_table_mod);
	AddBundleHook(OFPT_PACKET_OUT,bundle_packet_out);
	AddBundleHook(OFPT_EXPERIMENTER,bundle_experimenter);
	AddBundleHook(OFPT_QUEUE_GET_CONFIG_REQUEST, bundle_get_port_queue_config);
}

/*
 * Validate as much of the message as possible before it is added to the bundle.
 * That way, we can catch many errors early in the process without invalidating whole bundle.
 *
 * Remaining more complex errors will be caught at commit time by noviengine.
 */

ofl_err ofc_verify_bundle_msg(struct ofl_msg_header *ofl_msg)
{
	ofl_err (*fun)(struct ofl_msg_header *);
	fun=verifyBundle[ofl_msg->type].funptr;
	if(fun == NULL) return ofl_error(OFPET_BUNDLE_FAILED, OFPBFC_MSG_UNSUP);
	return fun(ofl_msg);
}
